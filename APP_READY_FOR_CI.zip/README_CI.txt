MyStoryFoot - CI Help

What I added:
- ios/exportOptions.plist (App Store distribution; TeamID=7B535ZNRSR; Profile=MyStoryFoot_appstore; BundleID=com.terencedesrues.mystoryfootball)
- codemagic.yaml (Node 20, CocoaPods install, build & export, TestFlight publishing via API key)

Before running on Codemagic, set these environment variables in App settings → Environment variables:
- APP_STORE_CONNECT_KEY_IDENTIFIER : your ASC API Key ID (e.g. 2X9R4HXF34)
- APP_STORE_CONNECT_ISSUER_ID     : your ASC Issuer ID (UUID-like)
- APP_STORE_CONNECT_PRIVATE_KEY   : paste the content of the .p8 file

Codemagic will run:
- npm install
- npx cap sync ios
- pod install (ios/App)
- xcodebuild archive & export IPA

Artifacts are saved to $CM_BUILD_DIR/ios_output/*.ipa .
