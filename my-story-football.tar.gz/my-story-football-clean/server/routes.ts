import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { ObjectPermission } from "./objectAcl";
import { 
  insertPlayerProfileSchema, 
  insertPlayerStatsSchema, 
  insertCareerHistorySchema, 
  insertAchievementSchema,
  insertMediaFileSchema,
  insertCoachProfileSchema,
  insertCoachStatsSchema,
  insertClubProfileSchema,
  insertClubAchievementSchema,
  insertClubMediaFileSchema,
  insertCoachMediaFileSchema
} from "@shared/schema";

// Stripe initialization with optional check
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2025-08-27.basil" as any,
    })
  : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve PWA files first (before auth middleware)
  app.use('/manifest.json', (_req, res) => {
    res.sendFile(path.resolve(process.cwd(), 'client/public/manifest.json'));
  });
  
  app.use('/service-worker.js', (_req, res) => {
    res.sendFile(path.resolve(process.cwd(), 'client/public/service-worker.js'));
  });
  
  app.use('/offline.html', (_req, res) => {
    res.sendFile(path.resolve(process.cwd(), 'client/public/offline.html'));
  });
  
  // Serve icon files
  app.use('/icon-*.svg', (req, res) => {
    const filename = req.path.substring(1);
    res.sendFile(path.resolve(process.cwd(), 'client/public', filename));
  });
  
  app.use('/favicon-*.svg', (req, res) => {
    const filename = req.path.substring(1);
    res.sendFile(path.resolve(process.cwd(), 'client/public', filename));
  });
  
  app.use('/apple-touch-icon.svg', (_req, res) => {
    res.sendFile(path.resolve(process.cwd(), 'client/public/apple-touch-icon.svg'));
  });

  // PWA Advanced Features Routes
  app.post('/share', (req, res) => {
    // Handle shared content from other apps
    console.log('📤 Contenu partagé reçu:', req.body);
    res.redirect('/?shared=true');
  });

  app.get('/open-file', (req, res) => {
    // Handle file opening from file explorer
    console.log('📁 Fichier ouvert:', req.query);
    res.redirect('/?fileOpened=true');
  });

  app.get('/handle-protocol', (req, res) => {
    // Handle mystory:// protocol links
    console.log('🔗 Lien protocol reçu:', req.query.url);
    res.redirect('/?protocolHandled=true');
  });

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Stripe subscription routes
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    if (!stripe) {
      return res.status(503).json({ error: "Payment processing not configured. Please add Stripe API keys." });
    }
    const user = req.user.claims;
    
    if (!user.email) {
      return res.status(400).json({ error: "No user email on file" });
    }

    try {
      let dbUser = await storage.getUser(user.sub);
      
      if (dbUser?.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(dbUser.stripeSubscriptionId);
        
        if (subscription.status === 'active') {
          return res.json({
            subscriptionId: subscription.id,
            clientSecret: typeof subscription.latest_invoice === 'object' && subscription.latest_invoice?.payment_intent ? (subscription.latest_invoice.payment_intent as any).client_secret : undefined,
          });
        }
      }

      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.first_name} ${user.last_name}`,
      });

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: process.env.STRIPE_PRICE_ID!,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(user.sub, customer.id, subscription.id);

      res.json({
        subscriptionId: subscription.id,
        clientSecret: typeof subscription.latest_invoice === 'object' && subscription.latest_invoice?.payment_intent ? (subscription.latest_invoice.payment_intent as any).client_secret : undefined,
      });
    } catch (error: any) {
      console.error("Stripe error:", error);
      res.status(400).json({ error: error.message });
    }
  });

  // Player profile routes
  app.get('/api/player-profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getPlayerProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching player profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post('/api/player-profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertPlayerProfileSchema.parse({ ...req.body, userId });
      
      const profile = await storage.createPlayerProfile(profileData);
      res.json(profile);
    } catch (error: any) {
      console.error("Error creating player profile:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.put('/api/player-profile/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const profileData = req.body;
      
      const profile = await storage.updatePlayerProfile(id, profileData);
      res.json(profile);
    } catch (error: any) {
      console.error("Error updating player profile:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Player stats routes
  app.get('/api/player-stats/:playerId', isAuthenticated, async (req, res) => {
    try {
      const { playerId } = req.params;
      const stats = await storage.getPlayerStats(playerId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching player stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.post('/api/player-stats', isAuthenticated, async (req, res) => {
    try {
      const statsData = insertPlayerStatsSchema.parse(req.body);
      const stats = await storage.upsertPlayerStats(statsData);
      res.json(stats);
    } catch (error: any) {
      console.error("Error updating player stats:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Career history routes
  app.get('/api/career-history/:playerId', isAuthenticated, async (req, res) => {
    try {
      const { playerId } = req.params;
      const history = await storage.getCareerHistory(playerId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching career history:", error);
      res.status(500).json({ message: "Failed to fetch career history" });
    }
  });

  app.post('/api/career-history', isAuthenticated, async (req, res) => {
    try {
      const historyData = insertCareerHistorySchema.parse(req.body);
      const history = await storage.addCareerHistory(historyData);
      res.json(history);
    } catch (error: any) {
      console.error("Error adding career history:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.delete('/api/career-history/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCareerHistory(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting career history:", error);
      res.status(500).json({ message: "Failed to delete career history" });
    }
  });

  // Achievements routes
  app.get('/api/achievements/:playerId', isAuthenticated, async (req, res) => {
    try {
      const { playerId } = req.params;
      const achievements = await storage.getAchievements(playerId);
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  app.post('/api/achievements', isAuthenticated, async (req, res) => {
    try {
      const achievementData = insertAchievementSchema.parse(req.body);
      const achievement = await storage.addAchievement(achievementData);
      res.json(achievement);
    } catch (error: any) {
      console.error("Error adding achievement:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Media routes
  app.get('/api/media/:playerId', isAuthenticated, async (req, res) => {
    try {
      const { playerId } = req.params;
      const media = await storage.getMediaFiles(playerId);
      res.json(media);
    } catch (error) {
      console.error("Error fetching media:", error);
      res.status(500).json({ message: "Failed to fetch media" });
    }
  });

  app.post('/api/media', isAuthenticated, async (req, res) => {
    try {
      const mediaData = insertMediaFileSchema.parse(req.body);
      const media = await storage.addMediaFile(mediaData);
      res.json(media);
    } catch (error: any) {
      console.error("Error adding media:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Object storage routes
  app.get("/objects/:objectPath(*)", isAuthenticated, async (req: any, res) => {
    const userId = req.user?.claims?.sub;
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      const canAccess = await objectStorageService.canAccessObjectEntity({
        objectFile,
        userId: userId,
        requestedPermission: ObjectPermission.READ,
      });
      if (!canAccess) {
        return res.sendStatus(401);
      }
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error checking object access:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  app.post("/api/objects/upload", isAuthenticated, async (req, res) => {
    const objectStorageService = new ObjectStorageService();
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    res.json({ uploadURL });
  });

  app.put("/api/media-files", isAuthenticated, async (req: any, res) => {
    if (!req.body.fileURL) {
      return res.status(400).json({ error: "fileURL is required" });
    }

    const userId = req.user?.claims?.sub;

    try {
      const objectStorageService = new ObjectStorageService();
      const objectPath = await objectStorageService.trySetObjectEntityAclPolicy(
        req.body.fileURL,
        {
          owner: userId,
          visibility: "public",
        },
      );

      res.status(200).json({ objectPath });
    } catch (error) {
      console.error("Error setting media file:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Social routes - likes
  app.post('/api/like-player/:playerId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { playerId } = req.params;
      
      const hasLiked = await storage.hasLikedPlayer(userId, playerId);
      if (hasLiked) {
        await storage.unlikePlayer(userId, playerId);
        res.json({ liked: false });
      } else {
        await storage.likePlayer(userId, playerId);
        res.json({ liked: true });
      }
    } catch (error) {
      console.error("Error toggling player like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  app.post('/api/like-media/:mediaId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { mediaId } = req.params;
      
      const hasLiked = await storage.hasLikedMedia(userId, mediaId);
      if (hasLiked) {
        await storage.unlikeMedia(userId, mediaId);
        res.json({ liked: false });
      } else {
        await storage.likeMedia(userId, mediaId);
        res.json({ liked: true });
      }
    } catch (error) {
      console.error("Error toggling media like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  // Profile type selection route (temporarily without auth for demo)
  app.post('/api/profile-type', async (req: any, res) => {
    try {
      // For demo purposes, use a demo user ID or create a session ID
      const userId = req.user?.claims?.sub || 'demo-user-' + Date.now();
      const { profileType } = req.body;
      
      if (!['player', 'coach', 'club'].includes(profileType)) {
        return res.status(400).json({ message: "Invalid profile type" });
      }
      
      // For demo, just return success without updating storage
      res.json({ success: true, profileType });
    } catch (error: any) {
      console.error("Error setting profile type:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // UNIFIED API endpoints for all profile types
  app.post('/api/player', async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'demo-user-' + Date.now();
      const { stats, achievements, mediaFiles, ...profileData } = req.body;
      
      // Create player profile
      const profile = await storage.createPlayerProfile({ ...profileData, userId });
      
      // Create stats if provided
      if (stats) {
        await storage.upsertPlayerStats({ ...stats, playerId: profile.id });
      }
      
      // Create achievements if provided
      if (achievements && achievements.length > 0) {
        for (const achievement of achievements) {
          if (achievement.title) {
            await storage.addAchievement({ ...achievement, playerId: profile.id });
          }
        }
      }
      
      // Create media files if provided
      if (mediaFiles && mediaFiles.length > 0) {
        for (const media of mediaFiles) {
          if (media.title) {
            await storage.addMediaFile({ 
              ...media, 
              playerId: profile.id,
              filePath: '/placeholder', // placeholder until file upload is implemented
              fileType: media.type || 'image'
            });
          }
        }
      }
      
      res.json(profile);
    } catch (error: any) {
      console.error("Error creating player:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/coach', async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'demo-user-' + Date.now();
      const { stats, achievements, mediaFiles, ...profileData } = req.body;
      
      // Create coach profile
      const profile = await storage.createCoachProfile({ ...profileData, userId });
      
      // Create stats if provided
      if (stats) {
        await storage.upsertCoachStats({ ...stats, coachId: profile.id });
      }
      
      res.json(profile);
    } catch (error: any) {
      console.error("Error creating coach:", error);
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/club', async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'demo-user-' + Date.now();
      const { stats, achievements, mediaFiles, ...profileData } = req.body;
      
      // Create club profile
      const profile = await storage.createClubProfile({ ...profileData, userId });
      
      // Create stats if provided
      if (stats) {
        await storage.upsertClubStats({ ...stats, clubId: profile.id });
      }
      
      res.json(profile);
    } catch (error: any) {
      console.error("Error creating club:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Rankings routes
  app.get('/api/rankings/players', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topPlayers = await storage.getTopPlayers(limit);
      res.json(topPlayers);
    } catch (error) {
      console.error("Error fetching top players:", error);
      res.status(500).json({ message: "Failed to fetch rankings" });
    }
  });

  app.get('/api/rankings/media', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const topMedia = await storage.getTopMedia(limit);
      res.json(topMedia);
    } catch (error) {
      console.error("Error fetching top media:", error);
      res.status(500).json({ message: "Failed to fetch media rankings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
