import {
  users,
  playerProfiles,
  playerStats,
  careerHistory,
  achievements,
  mediaFiles,
  playerLikes,
  mediaLikes,
  coachProfiles,
  coachStats,
  clubProfiles,
  clubStats,
  type User,
  type UpsertUser,
  type PlayerProfile,
  type InsertPlayerProfile,
  type PlayerStats,
  type InsertPlayerStats,
  type CareerHistory,
  type InsertCareerHistory,
  type Achievement,
  type InsertAchievement,
  type MediaFile,
  type InsertMediaFile,
  type PlayerLike,
  type MediaLike,
  type CoachProfile,
  type InsertCoachProfile,
  type CoachStats,
  type InsertCoachStats,
  type ClubProfile,
  type InsertClubProfile,
  type ClubStats,
  type InsertClubStats,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User>;
  updateUserProfileType(userId: string, profileType: string): Promise<User>;
  
  // Player profile operations
  getPlayerProfile(userId: string): Promise<PlayerProfile | undefined>;
  createPlayerProfile(profile: InsertPlayerProfile): Promise<PlayerProfile>;
  updatePlayerProfile(id: string, profile: Partial<InsertPlayerProfile>): Promise<PlayerProfile>;
  
  // Player stats operations
  getPlayerStats(playerId: string): Promise<PlayerStats | undefined>;
  upsertPlayerStats(stats: InsertPlayerStats): Promise<PlayerStats>;
  
  // Career history operations
  getCareerHistory(playerId: string): Promise<CareerHistory[]>;
  addCareerHistory(history: InsertCareerHistory): Promise<CareerHistory>;
  updateCareerHistory(id: string, history: Partial<InsertCareerHistory>): Promise<CareerHistory>;
  deleteCareerHistory(id: string): Promise<void>;
  
  // Achievement operations
  getAchievements(playerId: string): Promise<Achievement[]>;
  addAchievement(achievement: InsertAchievement): Promise<Achievement>;
  deleteAchievement(id: string): Promise<void>;
  
  // Media operations
  getMediaFiles(playerId: string): Promise<MediaFile[]>;
  addMediaFile(media: InsertMediaFile): Promise<MediaFile>;
  updateMediaFile(id: string, media: Partial<InsertMediaFile>): Promise<MediaFile>;
  deleteMediaFile(id: string): Promise<void>;
  
  // Coach profile operations
  getCoachProfile(userId: string): Promise<CoachProfile | undefined>;
  createCoachProfile(profile: InsertCoachProfile): Promise<CoachProfile>;
  updateCoachProfile(id: string, profile: Partial<InsertCoachProfile>): Promise<CoachProfile>;
  
  // Coach stats operations
  getCoachStats(coachId: string): Promise<CoachStats | undefined>;
  upsertCoachStats(stats: InsertCoachStats): Promise<CoachStats>;
  
  // Club profile operations
  getClubProfile(userId: string): Promise<ClubProfile | undefined>;
  createClubProfile(profile: InsertClubProfile): Promise<ClubProfile>;
  updateClubProfile(id: string, profile: Partial<InsertClubProfile>): Promise<ClubProfile>;
  
  // Club stats operations
  getClubStats(clubId: string): Promise<ClubStats | undefined>;
  upsertClubStats(stats: InsertClubStats): Promise<ClubStats>;
  
  // Social operations
  likePlayer(userId: string, playerId: string): Promise<PlayerLike>;
  unlikePlayer(userId: string, playerId: string): Promise<void>;
  hasLikedPlayer(userId: string, playerId: string): Promise<boolean>;
  
  likeMedia(userId: string, mediaId: string): Promise<MediaLike>;
  unlikeMedia(userId: string, mediaId: string): Promise<void>;
  hasLikedMedia(userId: string, mediaId: string): Promise<boolean>;
  
  // Rankings
  getTopPlayers(limit?: number): Promise<(PlayerProfile & { totalLikes: number })[]>;
  getTopMedia(limit?: number): Promise<(MediaFile & { likes: number })[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        isSubscribed: true,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserProfileType(userId: string, profileType: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        profileType,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Player profile operations
  async getPlayerProfile(userId: string): Promise<PlayerProfile | undefined> {
    const [profile] = await db
      .select()
      .from(playerProfiles)
      .where(eq(playerProfiles.userId, userId));
    return profile;
  }

  async createPlayerProfile(profile: InsertPlayerProfile): Promise<PlayerProfile> {
    const [newProfile] = await db
      .insert(playerProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updatePlayerProfile(id: string, profile: Partial<InsertPlayerProfile>): Promise<PlayerProfile> {
    const [updatedProfile] = await db
      .update(playerProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(playerProfiles.id, id))
      .returning();
    return updatedProfile;
  }

  // Player stats operations
  async getPlayerStats(playerId: string): Promise<PlayerStats | undefined> {
    const [stats] = await db
      .select()
      .from(playerStats)
      .where(eq(playerStats.playerId, playerId));
    return stats;
  }

  async upsertPlayerStats(stats: InsertPlayerStats): Promise<PlayerStats> {
    const [upsertedStats] = await db
      .insert(playerStats)
      .values(stats)
      .onConflictDoUpdate({
        target: playerStats.playerId,
        set: { ...stats, updatedAt: new Date() },
      })
      .returning();
    return upsertedStats;
  }

  // Career history operations
  async getCareerHistory(playerId: string): Promise<CareerHistory[]> {
    return await db
      .select()
      .from(careerHistory)
      .where(eq(careerHistory.playerId, playerId))
      .orderBy(desc(careerHistory.season));
  }

  async addCareerHistory(history: InsertCareerHistory): Promise<CareerHistory> {
    const [newHistory] = await db
      .insert(careerHistory)
      .values(history)
      .returning();
    return newHistory;
  }

  async updateCareerHistory(id: string, history: Partial<InsertCareerHistory>): Promise<CareerHistory> {
    const [updatedHistory] = await db
      .update(careerHistory)
      .set(history)
      .where(eq(careerHistory.id, id))
      .returning();
    return updatedHistory;
  }

  async deleteCareerHistory(id: string): Promise<void> {
    await db.delete(careerHistory).where(eq(careerHistory.id, id));
  }

  // Achievement operations
  async getAchievements(playerId: string): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.playerId, playerId))
      .orderBy(desc(achievements.year));
  }

  async addAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [newAchievement] = await db
      .insert(achievements)
      .values(achievement)
      .returning();
    return newAchievement;
  }

  async deleteAchievement(id: string): Promise<void> {
    await db.delete(achievements).where(eq(achievements.id, id));
  }

  // Media operations
  async getMediaFiles(playerId: string): Promise<MediaFile[]> {
    return await db
      .select()
      .from(mediaFiles)
      .where(eq(mediaFiles.playerId, playerId))
      .orderBy(desc(mediaFiles.createdAt));
  }

  async addMediaFile(media: InsertMediaFile): Promise<MediaFile> {
    const [newMedia] = await db
      .insert(mediaFiles)
      .values(media)
      .returning();
    return newMedia;
  }

  async updateMediaFile(id: string, media: Partial<InsertMediaFile>): Promise<MediaFile> {
    const [updatedMedia] = await db
      .update(mediaFiles)
      .set(media)
      .where(eq(mediaFiles.id, id))
      .returning();
    return updatedMedia;
  }

  async deleteMediaFile(id: string): Promise<void> {
    await db.delete(mediaFiles).where(eq(mediaFiles.id, id));
  }

  // Coach profile operations
  async getCoachProfile(userId: string): Promise<CoachProfile | undefined> {
    const [profile] = await db
      .select()
      .from(coachProfiles)
      .where(eq(coachProfiles.userId, userId));
    return profile;
  }

  async createCoachProfile(profile: InsertCoachProfile): Promise<CoachProfile> {
    const [newProfile] = await db
      .insert(coachProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateCoachProfile(id: string, profile: Partial<InsertCoachProfile>): Promise<CoachProfile> {
    const [updatedProfile] = await db
      .update(coachProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(coachProfiles.id, id))
      .returning();
    return updatedProfile;
  }

  // Coach stats operations
  async getCoachStats(coachId: string): Promise<CoachStats | undefined> {
    const [stats] = await db
      .select()
      .from(coachStats)
      .where(eq(coachStats.coachId, coachId));
    return stats;
  }

  async upsertCoachStats(stats: InsertCoachStats): Promise<CoachStats> {
    const [upsertedStats] = await db
      .insert(coachStats)
      .values(stats)
      .onConflictDoUpdate({
        target: coachStats.coachId,
        set: { ...stats, updatedAt: new Date() },
      })
      .returning();
    return upsertedStats;
  }

  // Club profile operations
  async getClubProfile(userId: string): Promise<ClubProfile | undefined> {
    const [profile] = await db
      .select()
      .from(clubProfiles)
      .where(eq(clubProfiles.userId, userId));
    return profile;
  }

  async createClubProfile(profile: InsertClubProfile): Promise<ClubProfile> {
    const [newProfile] = await db
      .insert(clubProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateClubProfile(id: string, profile: Partial<InsertClubProfile>): Promise<ClubProfile> {
    const [updatedProfile] = await db
      .update(clubProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(clubProfiles.id, id))
      .returning();
    return updatedProfile;
  }

  // Club stats operations
  async getClubStats(clubId: string): Promise<ClubStats | undefined> {
    const [stats] = await db
      .select()
      .from(clubStats)
      .where(eq(clubStats.clubId, clubId));
    return stats;
  }

  async upsertClubStats(stats: InsertClubStats): Promise<ClubStats> {
    const [upsertedStats] = await db
      .insert(clubStats)
      .values(stats)
      .onConflictDoUpdate({
        target: clubStats.clubId,
        set: { ...stats, updatedAt: new Date() },
      })
      .returning();
    return upsertedStats;
  }

  // Social operations
  async likePlayer(userId: string, playerId: string): Promise<PlayerLike> {
    // Add like and increment counter
    const [like] = await db
      .insert(playerLikes)
      .values({ userId, playerId })
      .returning();
    
    await db
      .update(playerProfiles)
      .set({ totalLikes: sql`${playerProfiles.totalLikes} + 1` })
      .where(eq(playerProfiles.id, playerId));
    
    return like;
  }

  async unlikePlayer(userId: string, playerId: string): Promise<void> {
    await db
      .delete(playerLikes)
      .where(and(
        eq(playerLikes.userId, userId),
        eq(playerLikes.playerId, playerId)
      ));
    
    await db
      .update(playerProfiles)
      .set({ totalLikes: sql`${playerProfiles.totalLikes} - 1` })
      .where(eq(playerProfiles.id, playerId));
  }

  async hasLikedPlayer(userId: string, playerId: string): Promise<boolean> {
    const [like] = await db
      .select()
      .from(playerLikes)
      .where(and(
        eq(playerLikes.userId, userId),
        eq(playerLikes.playerId, playerId)
      ));
    return !!like;
  }

  async likeMedia(userId: string, mediaId: string): Promise<MediaLike> {
    const [like] = await db
      .insert(mediaLikes)
      .values({ userId, mediaId })
      .returning();
    
    await db
      .update(mediaFiles)
      .set({ likes: sql`${mediaFiles.likes} + 1` })
      .where(eq(mediaFiles.id, mediaId));
    
    return like;
  }

  async unlikeMedia(userId: string, mediaId: string): Promise<void> {
    await db
      .delete(mediaLikes)
      .where(and(
        eq(mediaLikes.userId, userId),
        eq(mediaLikes.mediaId, mediaId)
      ));
    
    await db
      .update(mediaFiles)
      .set({ likes: sql`${mediaFiles.likes} - 1` })
      .where(eq(mediaFiles.id, mediaId));
  }

  async hasLikedMedia(userId: string, mediaId: string): Promise<boolean> {
    const [like] = await db
      .select()
      .from(mediaLikes)
      .where(and(
        eq(mediaLikes.userId, userId),
        eq(mediaLikes.mediaId, mediaId)
      ));
    return !!like;
  }

  // Rankings
  async getTopPlayers(limit: number = 10): Promise<(PlayerProfile & { totalLikes: number })[]> {
    return await db
      .select()
      .from(playerProfiles)
      .where(eq(playerProfiles.isPublic, true))
      .orderBy(desc(playerProfiles.totalLikes))
      .limit(limit);
  }

  async getTopMedia(limit: number = 10): Promise<(MediaFile & { likes: number })[]> {
    return await db
      .select()
      .from(mediaFiles)
      .orderBy(desc(mediaFiles.likes))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
