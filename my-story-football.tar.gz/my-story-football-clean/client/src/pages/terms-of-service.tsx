import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">CONDITIONS D'UTILISATION</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. INFORMATIONS LÉGALES</h2>
              <p className="mb-4">
                <strong>My Story Football</strong> est une application mobile éditée par :
              </p>
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <p><strong>Terence Desrues</strong></p>
                <p>Micro-entrepreneur</p>
                <p>Email : contact@mystoryfootball.com</p>
                <p>Devise : "De l'amateur au pro, Montre qui tu es"</p>
              </div>
              <p>
                En utilisant l'application My Story Football, vous acceptez d'être lié par les présentes 
                conditions d'utilisation. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser l'application.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. DESCRIPTION DU SERVICE</h2>
              <p className="mb-4">
                My Story Football est une plateforme communautaire dédiée au football permettant de :
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>Créer et gérer des profils de joueurs, entraîneurs et clubs</li>
                <li>Partager des statistiques sportives style Football Manager</li>
                <li>Documenter l'historique de carrière</li>
                <li>Partager des médias (photos, vidéos)</li>
                <li>Interagir avec la communauté football</li>
                <li>Consulter des classements et comparaisons</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. INSCRIPTION ET COMPTES</h2>
              <h3 className="text-xl font-semibold mb-3">3.1 Conditions d'inscription</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Vous devez être âgé de 13 ans minimum</li>
                <li>Pour les mineurs : autorisation parentale requise</li>
                <li>Une seule compte par personne</li>
                <li>Informations exactes et à jour obligatoires</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">3.2 Responsabilités du compte</h3>
              <ul className="list-disc list-inside space-y-2">
                <li>Vous êtes responsable de la confidentialité de vos identifiants</li>
                <li>Vous êtes responsable de toutes les activités sous votre compte</li>
                <li>Signalement immédiat requis en cas d'utilisation non autorisée</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. UTILISATION ACCEPTABLE</h2>
              <h3 className="text-xl font-semibold mb-3">4.1 Usages autorisés</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Utilisation personnelle et non commerciale</li>
                <li>Partage de contenu footballistique authentique</li>
                <li>Interactions respectueuses avec la communauté</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">4.2 Usages interdits</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Contenu illégal :</strong> Contenu violant les lois applicables</li>
                <li><strong>Harcèlement :</strong> Intimidation, menaces, discrimination</li>
                <li><strong>Spam :</strong> Messages non sollicités, publicité excessive</li>
                <li><strong>Fausses informations :</strong> Profils fictifs, statistiques mensongères</li>
                <li><strong>Violation de droits :</strong> Contenu sous copyright sans autorisation</li>
                <li><strong>Activités malveillantes :</strong> Virus, piratage, ingénierie sociale</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. CONTENU UTILISATEUR</h2>
              <h3 className="text-xl font-semibold mb-3">5.1 Propriété du contenu</h3>
              <p className="mb-4">
                Vous conservez la propriété de votre contenu (photos, vidéos, textes). 
                En publiant du contenu, vous nous accordez une licence pour l'afficher, 
                le distribuer et le promouvoir dans le cadre du service.
              </p>

              <h3 className="text-xl font-semibold mb-3">5.2 Responsabilité du contenu</h3>
              <ul className="list-disc list-inside space-y-2">
                <li>Vous êtes seul responsable du contenu que vous publiez</li>
                <li>Vous garantissez détenir tous les droits nécessaires</li>
                <li>Vous nous indemnisez contre toute réclamation liée à votre contenu</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. ABONNEMENTS ET PAIEMENTS</h2>
              <h3 className="text-xl font-semibold mb-3">6.1 Modèle économique</h3>
              <p className="mb-4">
                My Story Football est une application payante proposant différents niveaux d'abonnement 
                pour accéder aux fonctionnalités premium.
              </p>

              <h3 className="text-xl font-semibold mb-3">6.2 Paiements</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Paiements sécurisés via Stripe</li>
                <li>Facturation mensuelle ou annuelle selon votre choix</li>
                <li>Prix affichés TTC en euros</li>
                <li>Renouvellement automatique sauf résiliation</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">6.3 Résiliation et remboursements</h3>
              <ul className="list-disc list-inside space-y-2">
                <li>Résiliation possible à tout moment depuis votre compte</li>
                <li>Accès maintenu jusqu'à la fin de la période payée</li>
                <li>Pas de remboursement au prorata sauf exceptions légales</li>
                <li>Droit de rétractation de 14 jours pour les nouveaux abonnements</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. PROPRIÉTÉ INTELLECTUELLE</h2>
              <p className="mb-4">
                L'application, son design, ses fonctionnalités et son code sont protégés par les droits 
                de propriété intellectuelle de Terence Desrues. Toute reproduction, distribution ou 
                modification non autorisée est interdite.
              </p>
              <p>
                <strong>Marques :</strong> "My Story Football" et le slogan "De l'amateur au pro, Montre qui tu es" 
                sont des marques de Terence Desrues.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. MODÉRATION ET SANCTIONS</h2>
              <h3 className="text-xl font-semibold mb-3">8.1 Signalement</h3>
              <p className="mb-4">
                Tout utilisateur peut signaler un contenu ou comportement inapproprié. 
                Nous nous réservons le droit de modérer le contenu et de prendre les mesures appropriées.
              </p>

              <h3 className="text-xl font-semibold mb-3">8.2 Sanctions</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Avertissement :</strong> Pour les violations mineures</li>
                <li><strong>Suppression de contenu :</strong> Contenu non conforme</li>
                <li><strong>Suspension temporaire :</strong> Violations répétées</li>
                <li><strong>Exclusion définitive :</strong> Violations graves ou récidive</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. LIMITATION DE RESPONSABILITÉ</h2>
              <p className="mb-4">
                L'application est fournie "en l'état". Nous ne garantissons pas :
              </p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>La disponibilité continue du service</li>
                <li>L'exactitude des informations utilisateurs</li>
                <li>L'absence d'erreurs ou de bugs</li>
              </ul>
              <p>
                Notre responsabilité est limitée au montant des sommes versées 
                par l'utilisateur au cours des 12 derniers mois.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. FORCE MAJEURE</h2>
              <p>
                Nous ne saurions être tenus responsables de tout retard ou manquement 
                résultant de circonstances indépendantes de notre volonté (catastrophes naturelles, 
                guerres, pandémies, défaillances d'infrastructure, etc.).
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">11. MODIFICATIONS DES CONDITIONS</h2>
              <p>
                Nous nous réservons le droit de modifier ces conditions d'utilisation. 
                Les modifications substantielles vous seront notifiées au moins 30 jours 
                à l'avance par email ou via l'application. L'utilisation continue de 
                l'application après modification vaut acceptation des nouvelles conditions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">12. DROIT APPLICABLE ET JURIDICTIONS</h2>
              <p className="mb-4">
                Les présentes conditions sont régies par le droit français. 
                En cas de litige, les tribunaux français seront seuls compétents.
              </p>
              <p>
                <strong>Médiation :</strong> En cas de litige, vous pouvez recourir à la médiation 
                de la consommation auprès de la plateforme européenne de règlement des litiges en ligne : 
                https://ec.europa.eu/consumers/odr/
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">13. CONTACT</h2>
              <p className="mb-4">
                Pour toute question relative aux présentes conditions d'utilisation :
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Terence Desrues</strong></p>
                <p>Email : <strong>contact@mystoryfootball.com</strong></p>
                <p>Délai de réponse : 72 heures maximum</p>
              </div>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-white/40 mt-2">
                My Story Football - "De l'amateur au pro, Montre qui tu es"
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}