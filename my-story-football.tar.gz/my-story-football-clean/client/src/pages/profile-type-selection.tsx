import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  Users,
  Building2,
  Trophy,
  History,
  Target
} from "lucide-react";

export default function ProfileTypeSelection() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleProfileSelection = async (profileType: string) => {
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/profile-type", { profileType });
      
      toast({
        title: "Profil sélectionné",
        description: `Profil ${profileType === 'player' ? 'Joueur' : profileType === 'coach' ? 'Entraîneur' : 'Club'} créé avec succès`,
      });
      
      // Rediriger vers la page de création appropriée
      if (profileType === 'player') {
        window.location.href = "/create-player";
      } else if (profileType === 'coach') {
        window.location.href = "/create-coach";
      } else if (profileType === 'club') {
        window.location.href = "/create-club";
      }
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: "Impossible de définir le type de profil",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-fm-darker px-4 py-8 pb-24 overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <h1 className="font-bebas text-3xl md:text-4xl text-center text-white mb-2">
          Choisissez votre type de profil
        </h1>
        <p className="text-center text-gray-400 mb-4 text-sm md:text-base">
          Sélectionnez le type de profil qui vous correspond
        </p>
        
        {/* Instructions claires */}
        <div className="bg-fm-gold/10 border border-fm-gold/30 rounded-lg p-4 mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-full bg-fm-gold/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-fm-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4V2a1 1 0 011-1h8a1 1 0 011 1v2m-9 0h10l.94 1.06A2 2 0 0120 7.06V19a2 2 0 01-2 2H6a2 2 0 01-2-2V7.06a2 2 0 011.06-1.94L6 4z" />
              </svg>
            </div>
            <h3 className="font-semibold text-white text-sm md:text-base">Comment procéder ?</h3>
          </div>
          <p className="text-white/80 text-xs md:text-sm leading-relaxed">
            👆 <span className="font-semibold text-fm-gold">Cliquez sur une carte</span> ci-dessous pour sélectionner votre profil. Chaque exemple vous montre à quoi ressemblera votre profil une fois créé.
          </p>
        </div>

        <div className="space-y-8">
          {/* Player Profile with Example */}
          <div>
            <Card 
              className="bg-gradient-to-r from-fm-gold/20 to-transparent border-fm-gold/30 hover:border-fm-gold/60 transition-all cursor-pointer mb-4 hover:shadow-lg hover:shadow-fm-gold/20 active:scale-[0.98]"
              onClick={() => handleProfileSelection('player')}
              data-testid="select-player-profile"
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-center gap-3 md:gap-4 mb-3 md:mb-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-fm-gold/20 flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 md:w-6 md:h-6 text-fm-gold" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg md:text-xl text-white truncate">⚽ Profil Joueur</h3>
                    <p className="text-xs md:text-sm text-white/60 leading-tight">Pour les footballeurs amateurs et professionnels</p>
                  </div>
                  <div className="text-fm-gold text-sm font-semibold hidden md:block">
                    CLIQUER
                  </div>
                </div>
                <div className="space-y-1.5 md:space-y-2 text-xs md:text-sm text-white/70">
                  <div className="flex items-center gap-2">
                    <User className="w-3 h-3 md:w-4 md:h-4 text-fm-gold flex-shrink-0" />
                    <span className="leading-tight">Statistiques Football Manager (1-20)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-3 h-3 md:w-4 md:h-4 text-fm-gold flex-shrink-0" />
                    <span className="leading-tight">Palmarès et récompenses</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <History className="w-3 h-3 md:w-4 md:h-4 text-fm-gold flex-shrink-0" />
                    <span className="leading-tight">Historique de carrière par saison</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Player Example - Responsive */}
            <Card className="bg-card/50 border-fm-gold/20 text-xs md:block hidden">
              <div className="p-2 md:p-3 border-b border-fm-gold/20">
                <div className="flex items-center gap-2 md:gap-3">
                  <img 
                    src="https://images.unsplash.com/photo-1553778263-73a83bab9b0c?w=48&h=48&fit=crop&crop=faces" 
                    alt="Exemple joueur" 
                    className="w-8 h-8 md:w-12 md:h-12 rounded-full border border-fm-gold flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-white text-xs md:text-sm truncate">Antoine Dubois</div>
                    <div className="text-gray-400 text-[10px] md:text-xs truncate">Milieu Centre • 24 ans • FC Toulouse</div>
                  </div>
                  <div className="text-center flex-shrink-0">
                    <div className="text-sm md:text-lg font-bold text-fm-gold">1,247</div>
                    <div className="text-[8px] md:text-[10px] text-gray-400">Likes</div>
                  </div>
                </div>
              </div>
              <div className="p-2 md:p-3">
                <div className="text-[8px] md:text-[10px] font-semibold text-fm-gold mb-1 md:mb-2">STATS TECHNIQUES</div>
                <div className="grid grid-cols-3 gap-1 md:gap-2 text-[10px] md:text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Passes</span>
                    <span className="text-fm-gold font-bold">16</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Technique</span>
                    <span className="text-fm-gold font-bold">14</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Centres</span>
                    <span className="text-fm-gold font-bold">12</span>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Mobile simple preview */}
            <div className="md:hidden bg-fm-gold/5 border border-fm-gold/20 rounded-lg p-3 text-center">
              <p className="text-fm-gold text-xs font-semibold">💫 Exemple : Antoine Dubois • Milieu Centre • 1,247 likes</p>
            </div>
          </div>

          {/* Coach Profile with Example */}
          <div>
            <Card 
              className="bg-gradient-to-r from-purple-500/20 to-transparent border-purple-500/30 hover:border-purple-500/60 transition-all cursor-pointer mb-4 hover:shadow-lg hover:shadow-purple-500/20 active:scale-[0.98]"
              onClick={() => handleProfileSelection('coach')}
              data-testid="select-coach-profile"
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-center gap-3 md:gap-4 mb-3 md:mb-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                    <Users className="w-5 h-5 md:w-6 md:h-6 text-purple-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg md:text-xl text-white truncate">🎯 Profil Entraîneur</h3>
                    <p className="text-xs md:text-sm text-white/60 leading-tight">Pour les coachs et staff technique</p>
                  </div>
                  <div className="text-purple-500 text-sm font-semibold hidden md:block">
                    CLIQUER
                  </div>
                </div>
                <div className="space-y-1.5 md:space-y-2 text-xs md:text-sm text-white/70">
                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 md:w-4 md:h-4 text-purple-500 flex-shrink-0" />
                    <span className="leading-tight">Compétences coaching (1-20)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="w-3 h-3 md:w-4 md:h-4 text-purple-500 flex-shrink-0" />
                    <span className="leading-tight">Philosophie et style de jeu</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-3 h-3 md:w-4 md:h-4 text-purple-500 flex-shrink-0" />
                    <span className="leading-tight">Carrière avec statistiques victoires/défaites</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Coach Example - Responsive */}
            <Card className="bg-card/50 border-purple-500/20 text-xs md:block hidden">
              <div className="p-2 md:p-3 border-b border-purple-500/20">
                <div className="flex items-center gap-2 md:gap-3">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=48&h=48&fit=crop&crop=faces" 
                    alt="Exemple entraîneur" 
                    className="w-8 h-8 md:w-12 md:h-12 rounded-full border border-purple-500 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-white text-xs md:text-sm truncate">Philippe Moreau</div>
                    <div className="text-gray-400 text-[10px] md:text-xs truncate">Entraîneur Principal • AS Montpellier</div>
                  </div>
                  <div className="text-center flex-shrink-0">
                    <div className="text-sm md:text-lg font-bold text-purple-500">892</div>
                    <div className="text-[8px] md:text-[10px] text-gray-400">Likes</div>
                  </div>
                </div>
              </div>
              <div className="p-2 md:p-3">
                <div className="text-[8px] md:text-[10px] font-semibold text-purple-500 mb-1 md:mb-2">COMPÉTENCES</div>
                <div className="grid grid-cols-3 gap-1 md:gap-2 text-[10px] md:text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Tactique</span>
                    <span className="text-purple-500 font-bold">17</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Motivation</span>
                    <span className="text-purple-500 font-bold">19</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400 truncate">Jeunes</span>
                    <span className="text-purple-500 font-bold">15</span>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Mobile simple preview */}
            <div className="md:hidden bg-purple-500/5 border border-purple-500/20 rounded-lg p-3 text-center">
              <p className="text-purple-500 text-xs font-semibold">🎯 Exemple : Philippe Moreau • Entraîneur Principal • 892 likes</p>
            </div>
          </div>

          {/* Club Profile with Example */}
          <div>
            <Card 
              className="bg-gradient-to-r from-blue-500/20 to-transparent border-blue-500/30 hover:border-blue-500/60 transition-all cursor-pointer mb-4 hover:shadow-lg hover:shadow-blue-500/20 active:scale-[0.98]"
              onClick={() => handleProfileSelection('club')}
              data-testid="select-club-profile"
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-center gap-3 md:gap-4 mb-3 md:mb-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-5 h-5 md:w-6 md:h-6 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg md:text-xl text-white truncate">🏟️ Profil Club</h3>
                    <p className="text-xs md:text-sm text-white/60 leading-tight">Pour les clubs amateurs et professionnels</p>
                  </div>
                  <div className="text-blue-500 text-sm font-semibold hidden md:block">
                    CLIQUER
                  </div>
                </div>
                <div className="space-y-1.5 md:space-y-2 text-xs md:text-sm text-white/70">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-3 h-3 md:w-4 md:h-4 text-blue-500 flex-shrink-0" />
                    <span className="leading-tight">Stade et capacité d'accueil</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-3 h-3 md:w-4 md:h-4 text-blue-500 flex-shrink-0" />
                    <span className="leading-tight">Nombre d'équipes et catégories</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-3 h-3 md:w-4 md:h-4 text-blue-500 flex-shrink-0" />
                    <span className="leading-tight">Palmarès et histoire du club</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Club Example - Responsive */}
            <Card className="bg-card/50 border-blue-500/20 text-xs md:block hidden">
              <div className="p-2 md:p-3 border-b border-blue-500/20">
                <div className="flex items-center gap-2 md:gap-3">
                  <div className="w-8 h-8 md:w-12 md:h-12 rounded-full border border-blue-500 bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-4 h-4 md:w-6 md:h-6 text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-white text-xs md:text-sm truncate">Olympique Saint-Étienne</div>
                    <div className="text-gray-400 text-[10px] md:text-xs truncate">National 2 • Fondé en 1947</div>
                  </div>
                  <div className="text-center flex-shrink-0">
                    <div className="text-sm md:text-lg font-bold text-blue-500">1,543</div>
                    <div className="text-[8px] md:text-[10px] text-gray-400">Likes</div>
                  </div>
                </div>
              </div>
              <div className="p-2 md:p-3">
                <div className="grid grid-cols-2 gap-2 md:gap-3">
                  <div>
                    <div className="text-[8px] md:text-[10px] font-semibold text-blue-500 mb-1">INFRASTRUCTURE</div>
                    <div className="space-y-0.5 md:space-y-1">
                      <div className="flex justify-between text-[9px] md:text-[10px]">
                        <span className="text-gray-400 truncate">Stade</span>
                        <span className="text-white">3,500</span>
                      </div>
                      <div className="flex justify-between text-[9px] md:text-[10px]">
                        <span className="text-gray-400 truncate">Équipes</span>
                        <span className="text-white">5</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="text-[8px] md:text-[10px] font-semibold text-blue-500 mb-1">PALMARÈS</div>
                    <div className="space-y-0.5 md:space-y-1">
                      <div className="flex items-center gap-1">
                        <Trophy className="w-2 h-2 md:w-3 md:h-3 text-blue-500 flex-shrink-0" />
                        <span className="text-white text-[9px] md:text-[10px] truncate">Champion N3</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Trophy className="w-2 h-2 md:w-3 md:h-3 text-blue-500 flex-shrink-0" />
                        <span className="text-white text-[9px] md:text-[10px] truncate">Coupe 2019</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Mobile simple preview */}
            <div className="md:hidden bg-blue-500/5 border border-blue-500/20 rounded-lg p-3 text-center">
              <p className="text-blue-500 text-xs font-semibold">🏟️ Exemple : Olympique Saint-Étienne • National 2 • 1,543 likes</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}