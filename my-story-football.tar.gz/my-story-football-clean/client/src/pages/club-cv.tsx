import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Building2, Trophy, Users, MapPin, 
  Calendar, Home, Target, Heart,
  Star, Award, ChevronLeft,
  Shield, Shirt, Clock, TrendingUp,
  CheckCircle, AlertCircle, Camera, Play
} from "lucide-react";

export default function ClubCV() {
  const clubData = {
    name: "Olympique Saint-Étienne",
    founded: 1947,
    league: "National 2",
    division: "Groupe A",
    city: "Saint-Étienne",
    region: "Auvergne-Rhône-Alpes",
    colors: ["Bleu", "Blanc"],
    president: "Jean-Claude Dupont",
    coach: "Michel Bernard",
    likes: 1543,
    rank: 15,
    
    // Infrastructure
    infrastructure: {
      stadium: "Stade Marcel Michelin",
      capacity: 3500,
      training: "Centre de formation Les Pins",
      pitches: 4,
      academy: true,
      facilities: ["Gymnase", "Salle de musculation", "Vestiaires modernes", "Salle vidéo"]
    },
    
    // Équipes
    teams: [
      { category: "Seniors A", league: "National 2", players: 26 },
      { category: "Seniors B", league: "Régional 1", players: 22 },
      { category: "U19", league: "National U19", players: 24 },
      { category: "U17", league: "Régional U17", players: 22 },
      { category: "U15", league: "Régional U15", players: 20 }
    ],
    
    // Statistiques saison actuelle
    currentSeason: {
      played: 18,
      wins: 10,
      draws: 4,
      losses: 4,
      goalsFor: 32,
      goalsAgainst: 18,
      points: 34,
      position: "3ème"
    },
    
    // Historique récent
    history: [
      { season: "2023-24", league: "National 2", position: "3ème (en cours)" },
      { season: "2022-23", league: "National 2", position: "7ème" },
      { season: "2021-22", league: "National 3", position: "1er (Champion)" },
      { season: "2020-21", league: "National 3", position: "4ème" },
      { season: "2019-20", league: "National 3", position: "5ème" }
    ],
    
    // Palmarès
    trophies: [
      { year: 2022, title: "Champion National 3" },
      { year: 2019, title: "Coupe de la Région AURA" },
      { year: 2017, title: "Champion Régional 1" },
      { year: 2015, title: "Vainqueur Coupe du District" },
      { year: 2012, title: "Champion DH" },
      { year: 2008, title: "Coupe de France (32e de finale)" }
    ],
    
    // Joueurs notables formés
    notablePlayers: [
      { name: "Antoine Griezmann", period: "2005-2009", currentClub: "Atlético Madrid" },
      { name: "Lucas Hernandez", period: "2007-2011", currentClub: "PSG" },
      { name: "Théo Dupont", period: "2010-2015", currentClub: "OGC Nice" }
    ],
    
    // Partenaires
    sponsors: [
      "Crédit Agricole Loire",
      "Super U Saint-Étienne",
      "Garage Renault Michelin",
      "Restaurant Le Sporting"
    ],
    
    // Description du club
    description: "Club historique de la région stéphanoise, l'Olympique Saint-Étienne est reconnu pour sa formation de jeunes talents et son ancrage local fort. Avec plus de 75 ans d'histoire, le club a formé de nombreux joueurs professionnels et continue d'être un acteur majeur du football régional.",
    
    // Points forts du club
    strengths: [
      "Centre de formation reconnu nationalement",
      "Infrastructure moderne et bien entretenue",
      "Support inconditionnel des supporters locaux",
      "Stabilité financière et gestion saine",
      "Réseau de scouts efficace dans la région"
    ],
    
    // Axes d'amélioration
    improvements: [
      "Extension de la capacité du stade",
      "Développement du secteur féminin",
      "Modernisation des installations vidéo",
      "Recrutement d'entraîneurs spécialisés"
    ],
    
    // Compétences clés
    competencies: {
      formation: 18,
      infrastructure: 15,
      gestionFinanciere: 17,
      marketing: 12,
      recrutement: 14,
      medical: 16
    },
    
    // Section Média
    media: [
      {
        type: "photo",
        title: "Inauguration nouveau terrain",
        date: "15 septembre 2023",
        likes: 567,
        image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=400&h=300&fit=crop"
      },
      {
        type: "video",
        title: "Reportage centre de formation",
        date: "2 septembre 2023",
        views: 3421,
        duration: "5:12",
        image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=300&fit=crop"
      },
      {
        type: "photo",
        title: "Célébration montée National 2",
        date: "28 mai 2022",
        likes: 892,
        image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=400&h=300&fit=crop"
      }
    ],
    
    // Images du club (logo et stade)
    clubLogo: "https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=400&h=400&fit=crop", // Placeholder - remplacer par upload
    stadiumPhoto: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&h=400&fit=crop" // Placeholder - remplacer par upload
  };

  return (
    <div className="min-h-screen bg-fm-darker">
      {/* Header Navigation */}
      <div className="sticky top-0 z-50 bg-fm-darker/95 backdrop-blur-xl border-b border-blue-500/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              className="text-white hover:text-blue-500"
              onClick={() => window.history.back()}
            >
              <ChevronLeft className="w-5 h-5 mr-1" />
              Retour
            </Button>
            <span className="font-bebas text-xl text-blue-500">Profil Club</span>
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Club Header */}
        <Card className="bg-gradient-to-r from-blue-500/20 to-transparent border-blue-500/30 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="relative w-32 h-32 rounded-full border-4 border-blue-500 bg-blue-500/10 overflow-hidden group">
                {clubData.clubLogo ? (
                  <img 
                    src={clubData.clubLogo} 
                    alt="Logo du club"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Shield className="w-16 h-16 text-blue-500" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                  <Camera className="w-8 h-8 text-white" />
                </div>
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h1 className="font-bebas text-4xl text-white mb-2">{clubData.name}</h1>
                <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-white/80">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    Fondé en {clubData.founded}
                  </div>
                  <div className="flex items-center gap-1">
                    <Trophy className="w-4 h-4 text-blue-500" />
                    {clubData.league}
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4 text-blue-500" />
                    {clubData.city}
                  </div>
                </div>
                
                <div className="mt-4 flex flex-wrap justify-center md:justify-start gap-2">
                  {clubData.colors.map((color, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-500/20 text-white rounded-full text-sm">
                      {color}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-500/20 p-4 rounded-xl">
                  <div className="text-3xl font-bold text-blue-500">{clubData.likes}</div>
                  <div className="text-sm text-white/60">Likes</div>
                </div>
                <div className="mt-3">
                  <div className="text-2xl font-bold text-white">#{clubData.rank}</div>
                  <div className="text-sm text-white/60">Classement</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Club Description */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-4">Présentation</h2>
            <p className="text-white/80 leading-relaxed">
              {clubData.description}
            </p>
          </CardContent>
        </Card>

        {/* Mon Projet */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-4">Notre Projet</h2>
            <p className="text-white/80 leading-relaxed">
              Notre ambition est de développer la meilleure académie de jeunes de la région et de les intégrer progressivement en équipe première. 
              Nous visons la montée en Ligue 2 dans les 3 prochaines années tout en conservant notre identité de club formateur. 
              L'objectif à long terme est d'établir le FC Annecy comme une référence du football français pour la formation et le développement des talents.
            </p>
          </CardContent>
        </Card>

        {/* Infrastructure */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Infrastructure</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Home className="w-5 h-5 text-blue-500" />
                  Stade
                </h3>
                {clubData.stadiumPhoto && (
                  <div className="mb-3 relative group cursor-pointer">
                    <img 
                      src={clubData.stadiumPhoto} 
                      alt="Photo du stade"
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                      <Camera className="w-8 h-8 text-white" />
                    </div>
                  </div>
                )}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Nom</span>
                    <span className="text-white">{clubData.infrastructure.stadium}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Capacité</span>
                    <span className="text-white">{clubData.infrastructure.capacity} places</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Home className="w-5 h-5 text-blue-500" />
                  Centre d'entraînement
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/60">Nom</span>
                    <span className="text-white">{clubData.infrastructure.training}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Terrains</span>
                    <span className="text-white">{clubData.infrastructure.pitches}</span>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-2">
                <h3 className="font-bold text-white mb-4">Équipements</h3>
                <div className="flex flex-wrap gap-2">
                  {clubData.infrastructure.facilities.map((facility, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-500/10 text-white/80 rounded-lg text-sm">
                      {facility}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Season Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-4 text-center">
              <Trophy className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{clubData.currentSeason.position}</div>
              <div className="text-sm text-white/60">Position</div>
              <div className="text-xs text-blue-500 mt-1">{clubData.currentSeason.points} pts</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{clubData.currentSeason.wins}</div>
              <div className="text-sm text-white/60">Victoires</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{clubData.currentSeason.goalsFor}</div>
              <div className="text-sm text-white/60">Buts pour</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{clubData.teams.length}</div>
              <div className="text-sm text-white/60">Équipes</div>
            </CardContent>
          </Card>
        </div>

        {/* Club Competencies */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Compétences du Club</h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Formation</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.formation}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.formation / 20) * 100}%` }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Infrastructure</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.infrastructure}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.infrastructure / 20) * 100}%` }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Gestion Financière</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.gestionFinanciere}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.gestionFinanciere / 20) * 100}%` }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Marketing</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.marketing}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.marketing / 20) * 100}%` }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Recrutement</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.recrutement}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.recrutement / 20) * 100}%` }}
                  />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/80">Médical</span>
                  <span className="font-bold text-blue-500">{clubData.competencies.medical}/20</span>
                </div>
                <div className="w-full bg-fm-dark/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full"
                    style={{ width: `${(clubData.competencies.medical / 20) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Strengths and Improvements */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-6">
              <h3 className="font-bebas text-xl text-blue-500 mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Points Forts
              </h3>
              <div className="space-y-3">
                {clubData.strengths.map((strength, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-white/80">{strength}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-blue-500/20">
            <CardContent className="p-6">
              <h3 className="font-bebas text-xl text-blue-500 mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Axes d'Amélioration
              </h3>
              <div className="space-y-3">
                {clubData.improvements.map((improvement, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-white/80">{improvement}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Teams */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Équipes</h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {clubData.teams.map((team, index) => (
                <Card key={index} className="bg-fm-dark/50 border-blue-500/10">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold text-white">{team.category}</div>
                        <div className="text-sm text-white/60">{team.league}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-blue-500">{team.players}</div>
                        <div className="text-xs text-white/50">Joueurs</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* History */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Historique Récent</h2>
            
            <div className="space-y-3">
              {clubData.history.map((season, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-fm-dark/50 rounded-lg">
                  <div>
                    <span className="font-bold text-white">{season.season}</span>
                    <span className="text-white/60 ml-2">• {season.league}</span>
                  </div>
                  <span className={`font-bold ${season.position.includes('1er') || season.position.includes('Champion') ? 'text-green-500' : 'text-white'}`}>
                    {season.position}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Trophies */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Palmarès</h2>
            
            <div className="grid md:grid-cols-2 gap-4">
              {clubData.trophies.map((trophy, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-fm-dark/50 rounded-lg">
                  <Trophy className="w-6 h-6 text-blue-500 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-white">{trophy.title}</div>
                    <div className="text-sm text-white/60">{trophy.year}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Notable Players */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Joueurs Formés au Club</h2>
            
            <div className="grid md:grid-cols-3 gap-4">
              {clubData.notablePlayers.map((player, index) => (
                <Card key={index} className="bg-fm-dark/50 border-blue-500/10">
                  <CardContent className="p-4">
                    <div className="font-bold text-white mb-1">{player.name}</div>
                    <div className="text-sm text-white/60">{player.period}</div>
                    <div className="text-xs text-blue-500 mt-2">Actuellement: {player.currentClub}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Sponsors */}
        <Card className="bg-card border-blue-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Partenaires</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {clubData.sponsors.map((sponsor, index) => (
                <div key={index} className="p-3 bg-fm-dark/50 rounded-lg text-center">
                  <div className="text-sm text-white/80">{sponsor}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Media Section */}
        <Card className="bg-card border-blue-500/20">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-blue-500 mb-6">Médias</h2>
            
            <div className="grid md:grid-cols-3 gap-4">
              {clubData.media.map((item, index) => (
                <Card key={index} className="bg-fm-dark/50 border-blue-500/10 overflow-hidden cursor-pointer hover:scale-105 transition-transform">
                  <div className="relative">
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-40 object-cover"
                    />
                    {item.type === 'video' && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Play className="w-12 h-12 text-white" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-3">
                    <h4 className="font-bold text-white text-sm mb-1">{item.title}</h4>
                    <p className="text-xs text-white/60 mb-2">{item.date}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1">
                        {item.type === 'video' ? (
                          <>
                            <Play className="w-3 h-3 text-blue-500" />
                            <span className="text-xs text-white/60">{item.views} vues</span>
                          </>
                        ) : (
                          <>
                            <Heart className="w-3 h-3 text-blue-500" />
                            <span className="text-xs text-white/60">{item.likes} likes</span>
                          </>
                        )}
                      </div>
                      {item.type === 'video' && (
                        <span className="text-xs text-blue-500">{item.duration}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
        {/* CTA Final */}
        <Card className="bg-card border-2 border-blue-500 text-center p-8 mb-24">
          <div className="mb-6">
            <Trophy className="w-16 h-16 text-blue-500 mx-auto mb-4" />
            <h2 className="font-bebas text-4xl text-white mb-2">
              CRÉEZ VOTRE PROFIL CLUB
            </h2>
            <p className="text-xl text-gray-400">
              Rejoignez Profil Pro et gérez votre club comme un professionnel
            </p>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Button
              size="lg"
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold"
              onClick={() => window.location.href = '/create-club'}
              data-testid="button-create-club"
            >
              Commencer maintenant
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-blue-500 text-blue-500 hover:bg-blue-500/20"
              onClick={() => window.location.href = '/'}
            >
              Retour à l'accueil
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}