import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">POLITIQUE DES COOKIES</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. QU'EST-CE QU'UN COOKIE ?</h2>
              <p className="mb-4">
                Un cookie est un petit fichier texte stocké sur votre appareil (ordinateur, smartphone, tablette) 
                lors de votre visite sur My Story Football. Ces fichiers permettent de reconnaître votre navigateur 
                et d'améliorer votre expérience utilisateur.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. TYPES DE COOKIES UTILISÉS</h2>
              
              <h3 className="text-xl font-semibold mb-3">2.1 Cookies strictement nécessaires</h3>
              <p className="mb-4">Ces cookies sont indispensables au fonctionnement de l'application :</p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Cookies de session :</strong> Maintien de votre connexion</li>
                <li><strong>Cookies d'authentification :</strong> Vérification de votre identité</li>
                <li><strong>Cookies de sécurité :</strong> Protection contre les attaques (CSRF)</li>
                <li><strong>Cookies de préférences :</strong> Langue, thème, paramètres d'affichage</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">2.2 Cookies de performance</h3>
              <p className="mb-4">Ces cookies nous aident à comprendre l'utilisation de l'app :</p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Cookies d'analytics :</strong> Mesure d'audience anonyme</li>
                <li><strong>Cookies de performance :</strong> Temps de chargement, erreurs</li>
                <li><strong>Cookies d'usage :</strong> Fonctionnalités les plus utilisées</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">2.3 Cookies fonctionnels</h3>
              <p className="mb-4">Ces cookies améliorent votre expérience :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Cookies de personnalisation :</strong> Thème sombre/clair</li>
                <li><strong>Cookies de géolocalisation :</strong> Clubs près de chez vous</li>
                <li><strong>Cookies de partage :</strong> Réseaux sociaux</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. COOKIES TIERS</h2>
              <p className="mb-4">Certains de nos partenaires peuvent déposer des cookies :</p>
              
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <h4 className="font-semibold mb-2">🔒 Replit (Hébergement)</h4>
                <p className="text-sm">Cookies de sécurité et de performance de la plateforme</p>
              </div>

              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <h4 className="font-semibold mb-2">💳 Stripe (Paiements)</h4>
                <p className="text-sm">Cookies de sécurisation des transactions</p>
              </div>

              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <h4 className="font-semibold mb-2">☁️ Google Cloud (Stockage)</h4>
                <p className="text-sm">Cookies pour l'upload et l'affichage des médias</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. DURÉE DE CONSERVATION</h2>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Cookies de session :</strong> Supprimés à la fermeture du navigateur</li>
                <li><strong>Cookies de connexion :</strong> 7 jours maximum</li>
                <li><strong>Cookies de préférences :</strong> 1 an</li>
                <li><strong>Cookies d'analytics :</strong> 24 mois maximum</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. GESTION DE VOS COOKIES</h2>
              
              <h3 className="text-xl font-semibold mb-3">5.1 Paramètres de l'application</h3>
              <p className="mb-4">
                Vous pouvez gérer vos préférences cookies directement dans les paramètres 
                de votre profil My Story Football.
              </p>

              <h3 className="text-xl font-semibold mb-3">5.2 Paramètres du navigateur</h3>
              <p className="mb-4">Vous pouvez configurer votre navigateur pour :</p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Refuser tous les cookies</li>
                <li>Accepter seulement certains cookies</li>
                <li>Supprimer les cookies existants</li>
                <li>Être alerté avant l'acceptation de cookies</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">5.3 Instructions par navigateur</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🌐 Chrome</h4>
                  <p className="text-sm">Paramètres → Confidentialité et sécurité → Cookies</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🦊 Firefox</h4>
                  <p className="text-sm">Paramètres → Vie privée et sécurité → Cookies</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🌍 Safari</h4>
                  <p className="text-sm">Préférences → Confidentialité → Cookies</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">📱 Mobile</h4>
                  <p className="text-sm">Paramètres du navigateur → Confidentialité</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. CONSÉQUENCES DU REFUS</h2>
              <p className="mb-4">
                Si vous refusez certains cookies, certaines fonctionnalités peuvent être limitées :
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Cookies nécessaires :</strong> L'application peut ne pas fonctionner correctement</li>
                <li><strong>Cookies de performance :</strong> Nous ne pourrons pas améliorer l'expérience</li>
                <li><strong>Cookies fonctionnels :</strong> Perte de personnalisation</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. COOKIES ET DONNÉES PERSONNELLES</h2>
              <p className="mb-4">
                Certains cookies peuvent contenir des données personnelles. Le traitement de ces données 
                est détaillé dans notre <Link href="/privacy-policy" className="text-fm-gold underline">
                Politique de Confidentialité</Link>.
              </p>
              <p>
                Vous disposez des mêmes droits (accès, rectification, suppression) sur les données 
                contenues dans les cookies.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. ÉVOLUTION DE CETTE POLITIQUE</h2>
              <p>
                Cette politique des cookies peut évoluer. Les modifications importantes vous seront 
                notifiées par email ou via l'application avant leur mise en application.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. CONTACT</h2>
              <p className="mb-4">
                Pour toute question sur notre utilisation des cookies :
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Terence Desrues</strong></p>
                <p>Email : <strong>contact@mystoryfootball.com</strong></p>
                <p>Objet : "Cookies - My Story Football"</p>
              </div>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}