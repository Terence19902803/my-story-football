import CoachOnboarding from "@/components/CoachOnboarding";

export default function CreateCoach() {
  const handleComplete = () => {
    window.location.href = "/home";
  };

  return (
    <CoachOnboarding onComplete={handleComplete} />
  );
}