import { useState } from "react";
import { Search, User, MapPin, Shield, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function SearchPlayers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPosition, setSelectedPosition] = useState("all");

  const positions = [
    { value: "all", label: "Tous" },
    { value: "GK", label: "Gardien" },
    { value: "DEF", label: "Défenseur" },
    { value: "MID", label: "Milieu" },
    { value: "ATT", label: "Attaquant" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header avec recherche */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-white mb-4">Joueurs</h1>
          
          {/* Barre de recherche */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Nom, club, ville..."
              className="w-full pl-10 pr-4 py-3 bg-black/50 border border-fm-gold/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-fm-gold/40 transition-colors"
              autoFocus
              data-testid="player-search-input"
            />
          </div>

          {/* Filtres par position */}
          <div className="flex gap-2 mt-4 overflow-x-auto">
            {positions.map((pos) => (
              <button
                key={pos.value}
                onClick={() => setSelectedPosition(pos.value)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-colors ${
                  selectedPosition === pos.value
                    ? "bg-fm-gold/20 text-fm-gold"
                    : "bg-black/40 text-white/70 hover:bg-black/60"
                }`}
              >
                {pos.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Résultats de recherche */}
      <div className="px-4 py-6">
        <p className="text-sm text-gray-400 mb-4">
          {searchQuery ? "Résultats de recherche" : "Joueurs populaires"}
        </p>

        <div className="space-y-3">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
            <Card key={index} className="bg-black/40 border-fm-gold/20 hover:border-fm-gold/40 transition-all duration-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="relative">
                    <div className="w-14 h-14 bg-gradient-to-r from-fm-gold to-yellow-500 rounded-full flex items-center justify-center">
                      <User className="w-7 h-7 text-fm-darker" />
                    </div>
                    {index <= 3 && (
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-fm-darker" />
                    )}
                  </div>

                  {/* Infos joueur */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white truncate">Joueur Pro #{index}</h3>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-400">
                      <div className="flex items-center gap-1">
                        <Shield className="w-3 h-3" />
                        <span>{["ATT", "MID", "DEF", "GK"][index % 4]}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        <span>Paris, FR</span>
                      </div>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-fm-gold">
                      <TrendingUp className="w-4 h-4" />
                      <span className="font-bold text-sm">{85 + index}</span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Niveau</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}