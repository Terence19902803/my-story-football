import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Terms() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-fm-card border-blue-500/20 p-6">
        <Button
          onClick={() => navigate("/")}
          variant="ghost"
          className="mb-6 text-white/70 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour
        </Button>
        
        <h1 className="text-3xl font-bold text-white mb-6">Conditions d'Utilisation</h1>
        
        <div className="space-y-4 text-white/80">
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">1. Acceptation des conditions</h2>
            <p>En utilisant My Story Football, vous acceptez nos conditions d'utilisation.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">2. Utilisation de la plateforme</h2>
            <p>La plateforme est destinée aux joueurs, entraîneurs et clubs de football.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">3. Propriété intellectuelle</h2>
            <p>Tout le contenu que vous créez reste votre propriété.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">4. Confidentialité</h2>
            <p>Nous protégeons vos données conformément au RGPD.</p>
          </section>
          
          <section>
            <h2 className="text-xl font-semibold text-white mb-2">5. Contact</h2>
            <p>Pour toute question : contact@mystoryfootball.com</p>
            <p className="mt-2">Terence Desrues - SIRET : 837 814 151 00010</p>
          </section>
        </div>
      </Card>
    </div>
  );
}