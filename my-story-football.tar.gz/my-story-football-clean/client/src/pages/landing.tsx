import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  User, 
  Users,
  BarChart3, 
  History, 
  Trophy, 
  Camera, 
  TrendingUp,
  Heart,
  Play,
  Star,
  CheckCircle,
  MessageCircle,
  Building2,
  GraduationCap
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: User,
      title: "Profil Complet",
      description: "Photo, informations personnelles, club actuel, biographie complète"
    },
    {
      icon: MessageCircle,
      title: "Messagerie Privée",
      description: "Suivez des joueurs et échangez en privé après acceptation mutuelle"
    },
    {
      icon: BarChart3,
      title: "Stats sur 20",
      description: "Système de notation Football Manager avec toutes les caractéristiques"
    },
    {
      icon: History,
      title: "Historique Carrière",
      description: "Suivi saison par saison, clubs, statistiques et performances"
    },
    {
      icon: Trophy,
      title: "Palmarès",
      description: "Trophées, distinctions, récompenses et accomplissements"
    },
    {
      icon: Camera,
      title: "Galerie Multimédia",
      description: "Vidéos highlights, photos de matchs, moments forts"
    },
    {
      icon: TrendingUp,
      title: "Classements",
      description: "Système de likes et classements dynamiques de la communauté"
    }
  ];

  const pricingFeatures = [
    "Profil joueur complet",
    "Messagerie entre joueurs",
    "Stats style professionnel",
    "Historique carrière détaillé",
    "Galerie vidéos et photos",
    "Classements communautaires"
  ];

  const topPlayers = [
    {
      rank: 1,
      name: "Lucas Martin",
      club: "Paris FC",
      overall: 89,
      likes: 2847,
      image: "https://images.unsplash.com/photo-1553778263-73a83bab9b0c?w=80&h=80&fit=crop&crop=faces"
    },
    {
      rank: 2,
      name: "Kevin Dubois", 
      club: "Montpellier HSC",
      overall: 87,
      likes: 2156,
      image: "https://images.unsplash.com/photo-1607013251379-e6eecfffe234?w=80&h=80&fit=crop&crop=faces"
    },
    {
      rank: 3,
      name: "Thomas Leroy",
      club: "OGC Nice", 
      overall: 85,
      likes: 1943,
      image: "https://images.unsplash.com/photo-1546961329-78bef0414d7c?w=80&h=80&fit=crop&crop=faces"
    }
  ];

  const mediaItems = [
    {
      title: "But décisif vs Marseille",
      date: "15 mars 2024",
      likes: 342,
      duration: "2:15",
      type: "video",
      image: "https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=400&h=300&fit=crop"
    },
    {
      title: "Entraînement technique",
      date: "12 mars 2024", 
      likes: 156,
      type: "image",
      image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=300&fit=crop"
    },
    {
      title: "Victoire en finale",
      date: "8 mars 2024",
      likes: 891,
      duration: "1:32",
      type: "video",
      image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=400&h=300&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen min-h-dvh bg-fm-darker overflow-x-hidden">
      
      {/* Hero Section Mobile-First */}
      <div className="relative bg-gradient-to-br from-fm-darker via-fm-dark to-fm-card overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-fm-gold/10 to-transparent animate-pulse" />
        <div className="absolute top-0 right-0 w-32 h-32 sm:w-72 sm:h-72 bg-gradient-to-br from-fm-gold/20 to-transparent rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 left-0 w-48 h-48 sm:w-96 sm:h-96 bg-gradient-to-tr from-fm-blue/20 to-transparent rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
        
        <div className="relative px-4 py-6 safe-area-top">
          {/* Logo intégré dans le contenu */}
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-2 mb-4">
              <img 
                src="/logo-msf.png" 
                alt="My Story Football" 
                className="h-12 sm:h-16 w-auto brightness-0 invert"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:text-fm-gold text-xs"
                onClick={() => window.location.href = "/profile-type-selection"}
              >
                Se connecter
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-fm-green text-fm-green hover:bg-fm-green/20 text-xs"
                onClick={() => window.location.href = "/player-cv"}
              >
                Voir un exemple
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="pb-20">
        {/* Hero Section Mobile-First */}
        <section className="px-0 py-6" data-testid="hero-section">
          <div className="text-center">
            <h1 className="font-bebas text-3xl text-white mb-3 leading-tight font-bold">
              De l'amateur au pro
              <span className="text-fm-gold block font-extrabold">Montre qui tu es</span>
            </h1>
            <p className="text-sm text-white/90 mb-4 px-2 font-medium">
              Crée ton profil, affiche tes stats, partage tes vidéos et grimpe dans le classement
            </p>
            <div className="px-2 w-full">
              <Button
                size="lg"
                className="w-full px-4 py-3 bg-gradient-to-r from-fm-gold to-purple-500 hover:from-purple-500 hover:to-fm-gold text-white font-bold text-sm rounded-full transform hover:scale-105 transition-all shadow-2xl fm-touch-target animate-pulse"
                onClick={() => window.location.href = "/profile-type-selection"}
                data-testid="button-subscribe-hero"
                style={{ animationDuration: '3s' }}
              >
                Créer mon profil
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section Mobile-First */}
        <section className="py-6 px-0" data-testid="features-section">
          <div className="w-full px-2">
            <h2 className="font-bebas text-2xl text-fm-gold text-center mb-6">
              Fonctionnalités
            </h2>
            
            <div className="grid grid-cols-2 gap-2">
              {features.map((feature, index) => (
                <Card key={index} className="bg-card border-border hover:border-fm-gold/50 transition-all hover:scale-105 hover:shadow-lg hover:shadow-fm-gold/30" data-testid={`card-feature-${index}`} style={{ animationDelay: `${index * 0.1}s` }}>
                  <CardContent className="p-3 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-fm-gold/10 to-transparent rounded-full blur-xl" />
                    <feature.icon className="w-6 h-6 text-fm-gold mb-2" />
                    <h3 className="font-bold text-sm text-white mb-1">{feature.title}</h3>
                    <p className="text-xs text-white/70 line-clamp-2 font-medium">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Three Profile Types Section */}
        <section className="py-8 px-0 bg-gradient-to-r from-fm-gold/10 via-purple-500/10 to-fm-gold/10" data-testid="profile-types-section">
          <div className="px-2">
            <h2 className="font-bebas text-2xl text-fm-gold text-center mb-2">
              3 Types de Profils Disponibles
            </h2>
            <p className="text-center text-sm text-white/80 mb-6 px-2">
              Joueurs, Entraîneurs et Clubs peuvent créer leur profil
            </p>
            
            <div className="grid gap-4 mb-8">
              {/* Joueur Profile Card */}
              <Card className="bg-card border-fm-gold/30 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-fm-gold/20 flex items-center justify-center">
                      <User className="w-6 h-6 text-fm-gold" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white">Profil Joueur</h3>
                      <p className="text-xs text-white/60">Pour footballeurs actifs et anciens</p>
                    </div>
                  </div>
                  <div className="space-y-1 text-xs text-white/70">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-3 h-3 text-fm-gold" />
                      <span>Stats sur 20 (technique, physique, mental)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="w-3 h-3 text-fm-gold" />
                      <span>Historique carrière et palmarès</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Camera className="w-3 h-3 text-fm-gold" />
                      <span>Vidéos highlights et photos</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Coach Profile Card */}
              <Card className="bg-card border-purple-500/30 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                      <GraduationCap className="w-6 h-6 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white">Profil Entraîneur</h3>
                      <p className="text-xs text-white/60">Pour coachs et formateurs</p>
                    </div>
                  </div>
                  <div className="space-y-1 text-xs text-white/70">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-3 h-3 text-purple-500" />
                      <span>Compétences coaching sur 20</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="w-3 h-3 text-purple-500" />
                      <span>Philosophie et méthodes de jeu</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-3 h-3 text-purple-500" />
                      <span>Points forts et axes de progression</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Club Profile Card */}
              <Card className="bg-card border-blue-500/30 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white">Profil Club</h3>
                      <p className="text-xs text-white/60">Pour clubs amateurs et professionnels</p>
                    </div>
                  </div>
                  <div className="space-y-1 text-xs text-white/70">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-3 h-3 text-blue-500" />
                      <span>Stade et capacité d'accueil</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-3 h-3 text-blue-500" />
                      <span>Nombre d'équipes et catégories</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="w-3 h-3 text-blue-500" />
                      <span>Palmarès et histoire du club</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Top Players Section - Moved up */}
        <section className="py-8 px-2" data-testid="rankings-section">
          <div className="container mx-auto">
            <h2 className="font-bebas text-2xl text-fm-gold text-center mb-4">
              Top Joueurs
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {topPlayers.map((player, index) => (
                <Card key={index} className="bg-card border-border hover:border-fm-gold/50 transition-all" data-testid={`card-top-player-${index}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className={`text-xl font-bold ${player.rank === 1 ? 'text-fm-gold' : 'text-muted-foreground'}`}>
                        #{player.rank}
                      </div>
                      <img 
                        src={player.image} 
                        alt={`Photo joueur #${player.rank}`} 
                        className={`w-10 h-10 rounded-full object-cover border ${player.rank === 1 ? 'border-fm-gold' : 'border-muted'}`}
                      />
                      <div className="flex-1">
                        <div className="font-semibold text-white text-sm">{player.name}</div>
                        <div className="text-xs text-muted-foreground">{player.club}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold text-fm-gold">{player.likes}</div>
                        <div className="text-xs text-muted-foreground">Likes</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Top Coaches Section - Moved up */}
        <section className="py-8 px-2 bg-gradient-to-r from-purple-500/10 to-transparent" data-testid="top-coaches-section">
          <div className="container mx-auto">
            <h2 className="font-bebas text-2xl text-purple-500 text-center mb-4">
              Top Coachs
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { name: "Jean-Marc Dubois", club: "FC Lyon", wins: 142, draws: 87, losses: 45, philosophy: "Jeu offensif", likes: 2341 },
                { name: "Thierry Martin", club: "AS Monaco B", wins: 98, draws: 52, losses: 31, philosophy: "Possession", likes: 1876 },
                { name: "Laurent Petit", club: "RC Strasbourg", wins: 87, draws: 43, losses: 29, philosophy: "Contre-attaque", likes: 1543 }
              ].map((coach, index) => (
                <Card key={index} className="bg-card border-purple-500/30 hover:border-purple-500 transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="text-xl font-bold text-purple-500">#{index + 1}</div>
                      <img 
                        src={`https://images.unsplash.com/photo-${index % 2 === 0 ? '1507003211169-0a1dd7228f2d' : '1500648767791-1163a6c8163c'}?w=64&h=64&fit=crop&crop=faces`}
                        alt={coach.name}
                        className="w-10 h-10 rounded-full border border-purple-500 object-cover"
                      />
                      <div className="flex-1">
                        <h3 className="font-bold text-white text-sm">{coach.name}</h3>
                        <p className="text-xs text-gray-400">{coach.club}</p>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold text-white">{coach.likes}</div>
                        <div className="text-xs text-muted-foreground">Likes</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Top Clubs Section - Moved up */}
        <section className="py-8 px-2 bg-gradient-to-r from-blue-500/10 to-transparent" data-testid="top-clubs-section">
          <div className="container mx-auto">
            <h2 className="font-bebas text-2xl text-blue-500 text-center mb-4">
              Top Clubs
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { name: "FC Rouen", league: "National 2", founded: "1899", stadium: "Stade Diochon", capacity: "12,500", teams: 8, trophies: 12, likes: 3456 },
                { name: "US Avranches", league: "National 3", founded: "1925", stadium: "Stade René Fenouillère", capacity: "5,000", teams: 6, trophies: 8, likes: 2987 },
                { name: "AS Poissy", league: "National 2", founded: "1904", stadium: "Stade Léo Lagrange", capacity: "3,500", teams: 5, trophies: 6, likes: 2341 }
              ].map((club, index) => (
                <Card key={index} className="bg-card border-blue-500/30 hover:border-blue-500 transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="text-xl font-bold text-blue-500">#{index + 1}</div>
                      <div className="w-10 h-10 rounded-full border border-blue-500 bg-blue-500/10 flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-blue-500" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-white text-sm">{club.name}</h3>
                        <p className="text-xs text-gray-400">{club.league}</p>
                      </div>
                      <div className="text-center">
                        <div className="text-sm font-bold text-white">{club.likes}</div>
                        <div className="text-xs text-muted-foreground">Likes</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Player Profile Demo */}
        <section className="py-8 px-0 bg-card/30" data-testid="profile-demo-section">
          <div className="px-2">
            <h2 className="font-bebas text-2xl text-fm-gold text-center mb-2">
              Exemple de Profil Joueur
            </h2>
            <p className="text-center text-sm text-gray-400 mb-4 px-2">
              Découvrez comment votre profil apparaîtra dans My Story Football
            </p>
            
            {/* Bouton pour voir profil complet */}
            <div className="px-2 mb-6">
              <Button
                className="w-full fm-button fm-button-gold text-sm py-3"
                onClick={() => window.location.href = "/player-cv"}
              >
                <Trophy className="w-4 h-4 mr-1" />
                Voir un exemple complet
              </Button>
            </div>
            
            <Card className="bg-card border-border overflow-hidden mx-2" data-testid="card-profile-demo">
              {/* Player Header */}
              <div className="p-4 border-b border-border">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                  <img 
                    src="https://images.unsplash.com/photo-1553778263-73a83bab9b0c?w=96&h=96&fit=crop&crop=faces" 
                    alt="Photo de profil joueur" 
                    className="w-20 h-20 rounded-full border-2 border-fm-gold object-cover"
                    data-testid="img-player-profile"
                  />
                  
                  <div className="flex-1">
                    <h1 className="font-bebas text-2xl text-white mb-2" data-testid="text-player-name">Antoine Dubois</h1>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Âge:</span>
                        <span className="text-foreground ml-2" data-testid="text-player-age">24 ans</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Poste:</span>
                        <span className="text-foreground ml-2" data-testid="text-player-position">Milieu Centre</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Club:</span>
                        <span className="text-foreground ml-2" data-testid="text-player-club">FC Toulouse</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Nationalité:</span>
                        <span className="text-foreground ml-2" data-testid="text-player-nationality">🇫🇷 France</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-fm-gold" data-testid="text-player-likes">1,247</div>
                    <div className="text-sm text-muted-foreground">Likes</div>
                    <div className="text-lg font-semibold text-white mt-2" data-testid="text-player-rank">#12</div>
                    <div className="text-xs text-muted-foreground">Classement</div>
                  </div>
                </div>
              </div>
              
              {/* Stats Section */}
              <div className="p-8">
                <h3 className="font-montserrat font-bold text-xl text-fm-gold mb-6">Caractéristiques (Style FM)</h3>
                
                <div className="grid md:grid-cols-3 gap-8">
                  {/* Technical Stats */}
                  <div>
                    <h4 className="font-semibold text-white mb-4 text-lg">Techniques</h4>
                    <div className="space-y-3">
                      {[
                        { name: "Dribble", value: 17, percentage: 85 },
                        { name: "Finition", value: 14, percentage: 70 },
                        { name: "Passes", value: 18, percentage: 90 }
                      ].map((stat, index) => (
                        <div key={index} className="flex items-center justify-between" data-testid={`stat-technical-${index}`}>
                          <span className="text-muted-foreground">{stat.name}</span>
                          <div className="flex items-center gap-2">
                            <div className="stat-bar w-20">
                              <div className="stat-bar-fill" style={{ width: `${stat.percentage}%` }}></div>
                            </div>
                            <span className="text-fm-gold font-semibold w-6" data-testid={`text-stat-value-${index}`}>{stat.value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Physical Stats */}
                  <div>
                    <h4 className="font-semibold text-white mb-4 text-lg">Physiques</h4>
                    <div className="space-y-3">
                      {[
                        { name: "Vitesse", value: 15, percentage: 75 },
                        { name: "Endurance", value: 16, percentage: 80 },
                        { name: "Puissance", value: 13, percentage: 65 }
                      ].map((stat, index) => (
                        <div key={index} className="flex items-center justify-between" data-testid={`stat-physical-${index}`}>
                          <span className="text-muted-foreground">{stat.name}</span>
                          <div className="flex items-center gap-2">
                            <div className="stat-bar w-20">
                              <div className="stat-bar-fill" style={{ width: `${stat.percentage}%` }}></div>
                            </div>
                            <span className="text-fm-gold font-semibold w-6" data-testid={`text-stat-value-physical-${index}`}>{stat.value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Mental Stats */}
                  <div>
                    <h4 className="font-semibold text-white mb-4 text-lg">Mentales</h4>
                    <div className="space-y-3">
                      {[
                        { name: "Vision", value: 19, percentage: 95 },
                        { name: "Leadership", value: 12, percentage: 60 },
                        { name: "Détermination", value: 17, percentage: 85 }
                      ].map((stat, index) => (
                        <div key={index} className="flex items-center justify-between" data-testid={`stat-mental-${index}`}>
                          <span className="text-muted-foreground">{stat.name}</span>
                          <div className="flex items-center gap-2">
                            <div className="stat-bar w-20">
                              <div className="stat-bar-fill" style={{ width: `${stat.percentage}%` }}></div>
                            </div>
                            <span className="text-fm-gold font-semibold w-6" data-testid={`text-stat-value-mental-${index}`}>{stat.value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Career History */}
              <div className="p-8 border-t border-border">
                <h3 className="font-montserrat font-bold text-xl text-fm-gold mb-6">Historique de Carrière</h3>
                <div className="overflow-x-auto">
                  <table className="fm-table w-full" data-testid="table-career-history">
                    <thead>
                      <tr>
                        <th className="text-left">Saison</th>
                        <th className="text-left">Club</th>
                        <th className="text-center">Matchs</th>
                        <th className="text-center">Buts</th>
                        <th className="text-center">Passes D.</th>
                        <th className="text-center">Note Moy.</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { season: "2023-24", club: "FC Toulouse", matches: 28, goals: 7, assists: 12, rating: 7.8 },
                        { season: "2022-23", club: "RC Lens (Prêt)", matches: 22, goals: 3, assists: 8, rating: 7.2 },
                        { season: "2021-22", club: "Toulouse FC (Centre Formation)", matches: 15, goals: 5, assists: 4, rating: 6.9 }
                      ].map((season, index) => (
                        <tr key={index} className="hover:bg-muted/30 transition-colors" data-testid={`row-career-${index}`}>
                          <td className="font-semibold text-white" data-testid={`text-season-${index}`}>{season.season}</td>
                          <td className="text-foreground" data-testid={`text-club-${index}`}>{season.club}</td>
                          <td className="text-center text-foreground" data-testid={`text-matches-${index}`}>{season.matches}</td>
                          <td className="text-center text-foreground" data-testid={`text-goals-${index}`}>{season.goals}</td>
                          <td className="text-center text-foreground" data-testid={`text-assists-${index}`}>{season.assists}</td>
                          <td className="text-center text-fm-gold font-semibold" data-testid={`text-rating-${index}`}>{season.rating}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Coach Profile Demo */}
        <section className="py-8 px-0 bg-gradient-to-r from-purple-500/10 to-transparent" data-testid="coach-profile-demo-section">
          <div className="px-2">
            <h2 className="font-bebas text-2xl text-purple-500 text-center mb-2">
              Exemple de Profil Entraîneur
            </h2>
            <p className="text-center text-sm text-gray-400 mb-4 px-2">
              Les compétences de coaching sur le système Football Manager
            </p>
            
            {/* Bouton pour voir profil Coach complet */}
            <div className="px-2 mb-6">
              <Button
                className="w-full fm-button bg-purple-500 hover:bg-purple-600 text-white text-sm py-3"
                onClick={() => window.location.href = "/coach-cv"}
              >
                <Users className="w-4 h-4 mr-1" />
                Voir un exemple Coach complet
              </Button>
            </div>
            
            <Card className="bg-card border-purple-500/30 overflow-hidden mx-2">
              <div className="p-4 border-b border-purple-500/30">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=96&h=96&fit=crop&crop=faces" 
                    alt="Photo de profil entraîneur" 
                    className="w-20 h-20 rounded-full border-2 border-purple-500 object-cover"
                  />
                  
                  <div className="flex-1">
                    <h1 className="font-bebas text-2xl text-white mb-2">Philippe Moreau</h1>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Âge:</span>
                        <span className="text-foreground ml-2">42 ans</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Poste:</span>
                        <span className="text-foreground ml-2">Entraîneur Principal</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Club:</span>
                        <span className="text-foreground ml-2">AS Montpellier</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Expérience:</span>
                        <span className="text-foreground ml-2">12 ans</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-500">892</div>
                    <div className="text-sm text-muted-foreground">Likes</div>
                    <div className="text-lg font-semibold text-white mt-2">#5</div>
                    <div className="text-xs text-muted-foreground">Classement</div>
                  </div>
                </div>
              </div>
              
              {/* Coach Stats */}
              <div className="p-4">
                <h3 className="font-montserrat font-bold text-lg text-purple-500 mb-4">Compétences Coaching</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-white mb-3">Tactique</h4>
                    <div className="space-y-2">
                      {[
                        { name: "Travail offensif", value: 18 },
                        { name: "Travail défensif", value: 16 },
                        { name: "Connaissances tactiques", value: 17 }
                      ].map((stat, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-muted-foreground text-sm">{stat.name}</span>
                          <div className="flex items-center gap-2">
                            <div className="stat-bar w-20">
                              <div className="bg-purple-500 h-full rounded-full" style={{ width: `${(stat.value / 20) * 100}%` }}></div>
                            </div>
                            <span className="text-purple-500 font-semibold w-6">{stat.value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-white mb-3">Management</h4>
                    <div className="space-y-2">
                      {[
                        { name: "Gestion des hommes", value: 19 },
                        { name: "Motivation", value: 17 },
                        { name: "Travail avec les jeunes", value: 15 }
                      ].map((stat, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-muted-foreground text-sm">{stat.name}</span>
                          <div className="flex items-center gap-2">
                            <div className="stat-bar w-20">
                              <div className="bg-purple-500 h-full rounded-full" style={{ width: `${(stat.value / 20) * 100}%` }}></div>
                            </div>
                            <span className="text-purple-500 font-semibold w-6">{stat.value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Club Profile Demo */}
        <section className="py-8 px-0 bg-gradient-to-r from-blue-500/10 to-transparent" data-testid="club-profile-demo-section">
          <div className="px-2">
            <h2 className="font-bebas text-2xl text-blue-500 text-center mb-2">
              Exemple de Profil Club
            </h2>
            <p className="text-center text-sm text-gray-400 mb-4 px-2">
              Infrastructure et informations complètes du club
            </p>
            
            {/* Bouton pour voir profil Club complet */}
            <div className="px-2 mb-6">
              <Button
                className="w-full fm-button bg-blue-500 hover:bg-blue-600 text-white text-sm py-3"
                onClick={() => window.location.href = "/club-cv"}
              >
                <Building2 className="w-4 h-4 mr-1" />
                Voir un exemple Club complet
              </Button>
            </div>
            
            <Card className="bg-card border-blue-500/30 overflow-hidden mx-2">
              <div className="p-4 border-b border-blue-500/30">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                  <div className="w-20 h-20 rounded-full border-2 border-blue-500 bg-blue-500/10 flex items-center justify-center">
                    <Building2 className="w-10 h-10 text-blue-500" />
                  </div>
                  
                  <div className="flex-1">
                    <h1 className="font-bebas text-2xl text-white mb-2">Olympique Saint-Étienne</h1>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Fondé:</span>
                        <span className="text-foreground ml-2">1947</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Ligue:</span>
                        <span className="text-foreground ml-2">National 2</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Ville:</span>
                        <span className="text-foreground ml-2">Saint-Étienne</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Équipes:</span>
                        <span className="text-foreground ml-2">5</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-500">1,543</div>
                    <div className="text-sm text-muted-foreground">Likes</div>
                    <div className="text-lg font-semibold text-white mt-2">#8</div>
                    <div className="text-xs text-muted-foreground">Classement</div>
                  </div>
                </div>
              </div>
              
              {/* Club Infrastructure */}
              <div className="p-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-montserrat font-bold text-lg text-blue-500 mb-4">Infrastructure</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Stade:</span>
                        <span className="text-white font-semibold">Stade Municipal</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Capacité:</span>
                        <span className="text-white font-semibold">3,500 places</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Centre Formation:</span>
                        <span className="text-white font-semibold">Oui</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Terrains:</span>
                        <span className="text-white font-semibold">4</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-montserrat font-bold text-lg text-blue-500 mb-4">Palmarès</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-blue-500" />
                        <span className="text-white text-sm">Champion National 3 (2021)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-blue-500" />
                        <span className="text-white text-sm">Vainqueur Coupe Régionale (2019)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-blue-500" />
                        <span className="text-white text-sm">Montée en National 2 (2022)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Sections supprimées pour éviter la duplication - déjà affichées plus haut */}

        {/* Media Gallery Section - Supprimée pour alléger la page */}

        {/* Call to Action Section */}
        <section className="py-8 px-2 bg-card/30" data-testid="cta-section">
          <div className="text-center">
            <h2 className="font-bebas text-2xl text-fm-gold mb-4">
              Rejoignez la communauté
            </h2>
            <p className="text-sm text-muted-foreground mb-6 px-2">
              Créez votre profil et gérez votre carrière comme un professionnel
            </p>
            
            <Card className="bg-card border-2 border-fm-gold p-4 mx-2 relative overflow-hidden" data-testid="card-cta">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fm-gold to-emerald-500"></div>
              
              <div className="text-2xl font-bold text-fm-gold mb-2" data-testid="text-pro">VERSION PROFESSIONNELLE</div>
              <div className="text-sm text-muted-foreground mb-4">Gérez votre carrière comme un pro</div>
              
              <ul className="space-y-2 text-left mb-6">
                {pricingFeatures.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3" data-testid={`feature-${index}`}>
                    <CheckCircle className="w-5 h-5 text-emerald-500" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-bold text-sm rounded-xl transform hover:scale-105 transition-all shadow-lg"
                onClick={() => window.location.href = "/profile-type-selection"}
                data-testid="button-start-free"
              >
                Commencer maintenant
              </Button>
              
              <p className="text-sm text-muted-foreground mt-4">
                Inscription rapide
              </p>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-6 px-2" data-testid="footer">
        <div className="w-full">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-fm-gold rounded-full flex items-center justify-center">
                  <Star className="w-5 h-5 text-fm-dark" />
                </div>
                <span className="font-bebas text-lg text-fm-gold">MY STORY</span>
              </div>
              <p className="text-muted-foreground">
                La plateforme professionnelle pour gérer ta carrière footballistique
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4">Produit</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#features" className="hover:text-fm-gold transition-colors" data-testid="link-features">Fonctionnalités</a></li>
                <li><a href="#pricing" className="hover:text-fm-gold transition-colors" data-testid="link-pricing">Tarifs</a></li>
                <li><a href="#rankings" className="hover:text-fm-gold transition-colors" data-testid="link-rankings">Classements</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#contact" className="hover:text-fm-gold transition-colors" data-testid="link-contact">Contact</a></li>
                <li><a href="#help" className="hover:text-fm-gold transition-colors" data-testid="link-help">Aide</a></li>
                <li><a href="#tutorials" className="hover:text-fm-gold transition-colors" data-testid="link-tutorials">Tutoriels</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-4">Légal</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="/legal" className="hover:text-fm-gold transition-colors" data-testid="link-legal">Mentions légales</a></li>
                <li><a href="/privacy" className="hover:text-fm-gold transition-colors" data-testid="link-privacy">Confidentialité</a></li>
                <li><a href="/legal" className="hover:text-fm-gold transition-colors" data-testid="link-terms">CGU</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-6 pt-4 text-center">
            <p className="text-xs text-muted-foreground">
              © 2024 My Story Football. Tous droits réservés.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
