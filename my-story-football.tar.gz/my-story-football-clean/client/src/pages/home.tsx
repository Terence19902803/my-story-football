import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  User, BarChart3, Trophy, Camera, Users, TrendingUp, 
  Star, Activity, Shield, Target, Zap, Medal,
  ChevronRight, Globe, Clock, Award, Sparkles
} from "lucide-react";
import Onboarding from "@/components/Onboarding";
import type { PlayerProfile, User as UserType } from "@shared/schema";
import type { RankedPlayer } from "@/lib/types";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState(false);
  
  // Check if user is new (no profile yet)
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (isAuthenticated && !hasSeenOnboarding) {
      setShowOnboarding(true);
    }
  }, [isAuthenticated]);
  
  const handleOnboardingComplete = () => {
    localStorage.setItem('hasSeenOnboarding', 'true');
    setShowOnboarding(false);
  };

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: playerProfile, isLoading: isProfileLoading } = useQuery<PlayerProfile>({
    queryKey: ["/api/player-profile"],
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: topPlayers } = useQuery<RankedPlayer[]>({
    queryKey: ["/api/rankings/players"],
    retry: false,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-fm-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  const quickStats = [
    { label: "CLASSEMENT", value: "Top 100", icon: Trophy, color: "fm-gold" },
    { label: "POPULARITÉ", value: `${playerProfile?.totalLikes || 0} likes`, icon: Star, color: "fm-green" },
    { label: "MÉDIAS", value: "12 fichiers", icon: Camera, color: "fm-blue" },
    { label: "SAISON", value: "2024-25", icon: Clock, color: "fm-orange" },
  ];

  const menuCards = [
    {
      title: "MON PROFIL",
      subtitle: "Gérer mes informations",
      icon: User,
      href: "/profile",
      gradient: "fm-gradient-gold",
      stats: ["Profil complet", "Stats FM", "Biographie"]
    },
    {
      title: "STATISTIQUES",
      subtitle: "Voir mes attributs FM",
      icon: BarChart3,
      href: "/profile#stats",
      gradient: "fm-gradient-green",
      stats: ["Technique", "Physique", "Mental"]
    },
    {
      title: "MES SAISONS",
      subtitle: "Track record & palmarès",
      icon: Target,
      href: "/profile#career",
      gradient: "fm-gradient-blue",
      stats: ["Clubs", "Stats", "Trophées"]
    },
    {
      title: "MÉDIAS",
      subtitle: "Photos et vidéos",
      icon: Camera,
      href: "/profile#media",
      gradient: "fm-gradient-mixed",
      stats: ["Photos", "Vidéos", "Highlights"]
    },
    {
      title: "CLASSEMENTS",
      subtitle: "Meilleurs joueurs",
      icon: TrendingUp,
      href: "/rankings",
      gradient: "fm-gradient-gold",
      stats: ["Top joueurs", "Top médias", "Tendances"]
    },
    {
      title: "COMMUNAUTÉ",
      subtitle: "Réseau de joueurs",
      icon: Users,
      href: "/rankings",
      gradient: "fm-gradient-green",
      stats: ["Découvrir", "Interagir", "Partager"]
    }
  ];

  return (
    <div className="min-h-screen">
      {showOnboarding && <Onboarding onComplete={handleOnboardingComplete} />}
      <Header />
      
      {/* Hero Section with Horizontal Layout */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-fm-darker via-fm-dark to-fm-card opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-fm-gold/5 to-transparent animate-pulse" />
        
        <div className="relative px-2 py-4">
          {/* Welcome Banner */}
          <div className="mb-4">
            <h1 className="text-3xl font-bebas tracking-wider mb-1">
              <span className="text-white">BIENVENUE,</span>{" "}
              <span className="text-fm-gold fm-glow">
                {(user as UserType)?.firstName?.toUpperCase() || "JOUEUR"}
              </span>
            </h1>
            <p className="text-sm text-gray-300 font-condensed">
              Gérez votre carrière comme un professionnel
            </p>
          </div>

          {/* Quick Stats Bar */}
          <div className="fm-horizontal-scroll mb-4">
            {quickStats.map((stat, index) => (
              <div
                key={index}
                className="fm-card fm-card-hover min-w-[140px] p-2 flex items-center gap-2"
                data-testid={`stat-card-${index}`}
              >
                <div className={`p-2 rounded bg-${stat.color}/20`}>
                  <stat.icon className={`w-4 h-4 text-${stat.color}`} />
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-condensed">{stat.label}</p>
                  <p className="text-sm font-bold text-white">{stat.value}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Create Profile Alert */}
          {!playerProfile && !isProfileLoading && (
            <div className="fm-card border border-fm-gold p-3 mb-4 fm-pulse">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-fm-gold" />
                  <div>
                    <h3 className="text-base font-bebas text-fm-gold">
                      CRÉEZ VOTRE PROFIL
                    </h3>
                    <p className="text-xs text-gray-400">
                      Pour apparaître dans les classements
                    </p>
                  </div>
                </div>
                <Button
                  className="fm-button fm-button-gold text-xs px-3 py-2"
                  onClick={() => window.location.href = "/profile"}
                  data-testid="button-create-profile"
                >
                  CRÉER
                  <ChevronRight className="w-3 h-3 ml-1" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content - Horizontal Cards Layout */}
      <div className="px-2 py-2">
        {/* Menu Cards Grid - Horizontal Focus */}
        <div className="mb-4">
          <h2 className="text-lg font-bebas text-fm-gold mb-3 flex items-center gap-2">
            <Zap className="w-5 h-5" />
            ACTIONS RAPIDES
          </h2>
          <div className="grid grid-cols-3 gap-1">
            {menuCards.map((card, index) => (
              <div
                key={index}
                className="fm-card fm-card-hover glass-dark cursor-pointer group relative overflow-hidden hover:scale-105 transition-all duration-300"
                onClick={() => window.location.href = card.href}
                data-testid={`menu-card-${index}`}
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className={`absolute inset-0 ${card.gradient} opacity-10 group-hover:opacity-20 transition-opacity`} />
                <div className="relative p-2">
                  <div className="flex flex-col items-center text-center">
                    <card.icon className="w-6 h-6 text-fm-gold mb-1" />
                    <h3 className="font-bebas text-xs text-white font-bold">{card.title}</h3>
                    <p className="text-xs text-white/80 line-clamp-1 font-medium">{card.subtitle}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dashboard Stats - Horizontal Layout */}
        <div className="grid grid-cols-1 gap-2 mb-4">
          {/* Profile Completion */}
          <div className="fm-card glass p-6 hover:scale-[1.02] transition-transform duration-300" data-testid="profile-completion">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bebas text-2xl text-fm-gold">PROFIL</h3>
              <Activity className="w-6 h-6 text-fm-green" />
            </div>
            {isProfileLoading ? (
              <div className="space-y-2">
                <div className="h-4 bg-gray-700 rounded animate-pulse w-3/4" />
                <div className="h-4 bg-gray-700 rounded animate-pulse w-1/2" />
              </div>
            ) : playerProfile ? (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Statut</span>
                  <span className="text-fm-green font-bold">ACTIF</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Position</span>
                  <span className="text-white">{playerProfile.position || "Non défini"}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Club</span>
                  <span className="text-white">{playerProfile.currentClub || "Sans club"}</span>
                </div>
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-400">Complétion</span>
                    <span className="text-fm-gold">85%</span>
                  </div>
                  <div className="fm-stat-bar">
                    <div className="fm-stat-fill fm-stat-fill-high" style={{ width: "85%" }} />
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <Medal className="w-12 h-12 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">Créez votre profil pour commencer</p>
              </div>
            )}
          </div>

          {/* Top Players */}
          <div className="fm-card glass p-6 hover:scale-[1.02] transition-transform duration-300" data-testid="top-players">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bebas text-2xl text-fm-gold">TOP JOUEURS</h3>
              <Trophy className="w-6 h-6 text-fm-gold" />
            </div>
            {topPlayers && topPlayers.length > 0 ? (
              <div className="space-y-3">
                {topPlayers.slice(0, 5).map((player: RankedPlayer, index: number) => (
                  <div key={index} className="flex items-center justify-between group hover:bg-fm-gold/5 p-2 -mx-2 rounded transition-colors">
                    <div className="flex items-center gap-3">
                      <span className={`font-bebas text-lg ${index === 0 ? 'text-fm-gold' : index === 1 ? 'text-gray-300' : index === 2 ? 'text-orange-600' : 'text-gray-500'}`}>
                        #{index + 1}
                      </span>
                      <span className="text-white group-hover:text-fm-gold transition-colors">
                        {player.name}
                      </span>
                    </div>
                    <span className="text-xs text-gray-400">
                      {player.totalLikes} likes
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <Globe className="w-12 h-12 text-gray-600 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">Aucun joueur disponible</p>
              </div>
            )}
          </div>

          {/* Recent Activity */}
          <div className="fm-card p-6" data-testid="recent-activity">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bebas text-2xl text-fm-gold">ACTIVITÉ</h3>
              <Clock className="w-6 h-6 text-fm-blue" />
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 bg-fm-green rounded-full animate-pulse" />
                <span className="text-gray-400">Profil mis à jour</span>
                <span className="text-gray-600 ml-auto">Il y a 2h</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 bg-fm-blue rounded-full" />
                <span className="text-gray-400">Nouvelle photo ajoutée</span>
                <span className="text-gray-600 ml-auto">Hier</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 bg-fm-gold rounded-full" />
                <span className="text-gray-400">Stats mises à jour</span>
                <span className="text-gray-600 ml-auto">3 jours</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-2 h-2 bg-fm-orange rounded-full" />
                <span className="text-gray-400">Nouveau trophée</span>
                <span className="text-gray-600 ml-auto">1 semaine</span>
              </div>
            </div>
          </div>
        </div>

        {/* Join Community */}
        <div className="fm-card border-2 border-fm-gold p-8 text-center">
          <Award className="w-16 h-16 text-fm-gold mx-auto mb-4 fm-glow" />
          <h2 className="text-3xl font-bebas text-white mb-2">REJOIGNEZ LA COMMUNAUTÉ</h2>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Créez votre profil complet et rejoignez des milliers de joueurs : 
            statistiques détaillées, galerie média, classements et bien plus !
          </p>
          <Button 
            className="fm-button fm-button-gold text-lg px-8 py-3"
            onClick={() => window.location.href = "/profile"}
          >
            CRÉER MON PROFIL MAINTENANT
            <Zap className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}