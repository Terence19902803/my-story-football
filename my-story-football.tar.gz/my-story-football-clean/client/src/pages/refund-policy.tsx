import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function RefundPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">POLITIQUE DE REMBOURSEMENT</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. PRINCIPE GÉNÉRAL</h2>
              <p className="mb-4">
                <strong>My Story Football</strong> s'engage à offrir un service de qualité à tous ses utilisateurs. 
                Cette politique de remboursement détaille les conditions dans lesquelles vous pouvez 
                demander un remboursement pour votre abonnement.
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>💳 Traitement des paiements :</strong> Tous les paiements sont sécurisés par Stripe</p>
                <p><strong>🏦 Devises acceptées :</strong> EUR (Euro) - Prix TTC affichés</p>
                <p><strong>⏱️ Délai de traitement :</strong> 5-10 jours ouvrés selon votre banque</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. DROIT DE RÉTRACTATION (14 JOURS)</h2>
              
              <h3 className="text-xl font-semibold mb-3 text-green-400">✅ Nouveaux abonnements</h3>
              <p className="mb-4">
                Conformément à la législation européenne, vous disposez d'un délai de <strong>14 jours</strong> 
                pour vous rétracter après votre premier abonnement, sans avoir à justifier de motifs.
              </p>
              
              <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30 mb-4">
                <h4 className="font-semibold mb-2">🕐 Période de rétractation</h4>
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li><strong>Début :</strong> Date de souscription de votre premier abonnement</li>
                  <li><strong>Fin :</strong> 14 jours calendaires (minuit le 14ème jour)</li>
                  <li><strong>Week-ends et jours fériés :</strong> Inclus dans le décompte</li>
                  <li><strong>Remboursement :</strong> 100% du montant payé</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-3">📝 Procédure de rétractation</h3>
              <ol className="list-decimal list-inside space-y-2 mb-4">
                <li>Envoyez un email à <strong>contact@mystoryfootball.com</strong></li>
                <li>Objet : "Rétractation - [Votre nom]"</li>
                <li>Indiquez votre nom, email, et date de souscription</li>
                <li>Confirmation de réception sous 24h</li>
                <li>Remboursement traité sous 7 jours</li>
              </ol>

              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <h4 className="font-semibold mb-2">ℹ️ Important</h4>
                <p className="text-sm">
                  Le droit de rétractation s'applique uniquement aux <strong>nouveaux clients</strong>. 
                  Les renouvellements d'abonnement ne bénéficient pas de ce droit.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. REMBOURSEMENTS EXCEPTIONNELS</h2>
              
              <h3 className="text-xl font-semibold mb-3">🛠️ Problèmes techniques majeurs</h3>
              <p className="mb-4">
                Nous accordons des remboursements partiels en cas de dysfonctionnements graves :
              </p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Indisponibilité prolongée :</strong> Service inaccessible + de 72h</li>
                <li><strong>Perte de données :</strong> Bug causant la perte de votre profil</li>
                <li><strong>Fonctionnalités défaillantes :</strong> Impossibilité d'utiliser l'app</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">🎭 Circonstances exceptionnelles</h3>
              <div className="bg-yellow-900/20 p-4 rounded-lg border border-yellow-500/30 mb-4">
                <h4 className="font-semibold mb-2">⚠️ Situations étudiées au cas par cas</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Problèmes de santé graves (avec justificatif médical)</li>
                  <li>Difficultés financières exceptionnelles</li>
                  <li>Erreurs de facturation de notre part</li>
                  <li>Force majeure (guerre, pandémie, catastrophe naturelle)</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-3">💔 Décès ou incapacité</h3>
              <p className="mb-4">
                En cas de décès ou d'incapacité totale de l'abonné, les ayants droit peuvent 
                demander la résiliation et le remboursement au prorata sur présentation des justificatifs.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. CAS DE NON-REMBOURSEMENT</h2>
              
              <h3 className="text-xl font-semibold mb-3 text-red-400">❌ Situations non remboursables</h3>
              <div className="space-y-4">
                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Utilisation normale du service</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Changement d'avis après la période de rétractation</li>
                    <li>Utilisation insuffisante de l'application</li>
                    <li>Préférence pour une application concurrente</li>
                    <li>Fonctionnalités qui ne correspondent pas aux attentes</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">⚠️ Violations des conditions</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Suspension ou exclusion pour non-respect des règles</li>
                    <li>Utilisation frauduleuse du service</li>
                    <li>Partage de compte avec des tiers</li>
                    <li>Tentative de piratage ou d'intrusion</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🔄 Renouvellements automatiques</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Oubli d'annulation avant le renouvellement</li>
                    <li>Renouvellements après le premier abonnement</li>
                    <li>Période déjà entamée (pas de remboursement au prorata)</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. PROCÉDURE DE DEMANDE</h2>
              
              <h3 className="text-xl font-semibold mb-3">📧 Comment demander un remboursement</h3>
              <div className="bg-white/5 p-6 rounded-lg">
                <ol className="list-decimal list-inside space-y-3">
                  <li>
                    <strong>Envoyez un email à :</strong> contact@mystoryfootball.com
                    <p className="text-sm text-white/60 mt-1">Objet : "Demande de remboursement - [Votre nom]"</p>
                  </li>
                  <li>
                    <strong>Informations obligatoires :</strong>
                    <ul className="list-disc list-inside ml-6 mt-2 space-y-1 text-sm">
                      <li>Nom et prénom complets</li>
                      <li>Adresse email de votre compte</li>
                      <li>Date de souscription</li>
                      <li>Montant payé</li>
                      <li>Motif détaillé de la demande</li>
                    </ul>
                  </li>
                  <li>
                    <strong>Pièces justificatives :</strong>
                    <p className="text-sm text-white/60 mt-1">Si applicable : reçu de paiement, justificatifs médicaux, etc.</p>
                  </li>
                  <li>
                    <strong>Délai de réponse :</strong>
                    <p className="text-sm text-white/60 mt-1">Accusé de réception sous 24h, décision sous 7 jours ouvrés</p>
                  </li>
                </ol>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. MODALITÉS DE REMBOURSEMENT</h2>
              
              <h3 className="text-xl font-semibold mb-3">💳 Méthodes de remboursement</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🔄 Remboursement automatique</h4>
                  <p className="text-sm">Sur le moyen de paiement utilisé (carte bancaire, PayPal)</p>
                </div>
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🏦 Virement bancaire</h4>
                  <p className="text-sm">Si le moyen original n'est plus disponible</p>
                </div>
              </div>

              <h3 className="text-xl font-semibold mb-3">⏰ Délais de traitement</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Carte bancaire :</strong> 5-10 jours ouvrés</li>
                <li><strong>PayPal :</strong> 3-5 jours ouvrés</li>
                <li><strong>Virement SEPA :</strong> 1-3 jours ouvrés</li>
                <li><strong>Virement international :</strong> 5-15 jours ouvrés</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. FRAIS DE REMBOURSEMENT</h2>
              <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
                <h4 className="font-semibold mb-2">✅ Aucun frais à votre charge</h4>
                <p className="text-sm mb-2">
                  My Story Football prend en charge tous les frais de remboursement, y compris :
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Frais de transaction Stripe</li>
                  <li>Frais de change (si applicable)</li>
                  <li>Frais de virement bancaire</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. PRÉVENTION DES ABUS</h2>
              <p className="mb-4">
                Pour préserver l'équité envers tous nos utilisateurs, nous nous réservons le droit de :
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>Limiter les demandes de remboursement répétées du même utilisateur</li>
                <li>Demander des justificatifs supplémentaires en cas de doute</li>
                <li>Refuser les demandes manifestement abusives</li>
                <li>Suspendre définitivement les comptes frauduleux</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. RECOURS ET MÉDIATION</h2>
              <p className="mb-4">
                Si vous n'êtes pas satisfait de notre décision concernant votre demande de remboursement :
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">🏛️ Médiation de la consommation</h4>
                <p className="text-sm mb-2">
                  Vous pouvez recourir gratuitement à un médiateur de la consommation :
                </p>
                <p className="text-sm">
                  <strong>Plateforme européenne ODR :</strong> 
                  <br />https://ec.europa.eu/consumers/odr/
                </p>
                <p className="text-sm mt-2">
                  <strong>Délai :</strong> Dans l'année suivant votre réclamation écrite
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. ÉVOLUTION DE CETTE POLITIQUE</h2>
              <p>
                Cette politique de remboursement peut être modifiée pour s'adapter à l'évolution 
                de nos services ou de la réglementation. Toute modification sera communiquée 
                30 jours avant son entrée en vigueur.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">11. CONTACT</h2>
              <div className="bg-white/5 p-6 rounded-lg">
                <h4 className="font-semibold mb-4">💬 Service client</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p><strong>Email :</strong> contact@mystoryfootball.com</p>
                    <p><strong>Objet :</strong> "Remboursement - [Votre demande]"</p>
                  </div>
                  <div>
                    <p><strong>Délai de réponse :</strong> 24h (accusé de réception)</p>
                    <p><strong>Traitement :</strong> 7 jours ouvrés maximum</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-white/60">
                  <strong>⚽ Notre engagement :</strong> "De l'amateur au pro, Montre qui tu es" - 
                  Nous restons à votre écoute pour résoudre toute situation !
                </p>
              </div>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-white/40 mt-2">
                My Story Football - Politique de remboursement équitable et transparente
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}