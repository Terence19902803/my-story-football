import PlayerOnboarding from "@/components/PlayerOnboarding";

export default function CreatePlayer() {
  const handleComplete = () => {
    window.location.href = "/home";
  };

  return (
    <PlayerOnboarding onComplete={handleComplete} />
  );
}