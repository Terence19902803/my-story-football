import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Star, Trophy, Users, Camera, TrendingUp } from "lucide-react";

// Stripe is optional - show info message if not configured
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : null;

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Erreur de paiement",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Paiement réussi",
        description: "Bienvenue dans FM IRL Premium !",
      });
    }
  };

  return (
    <Card className="bg-card border-border max-w-md mx-auto" data-testid="card-payment-form">
      <CardHeader>
        <CardTitle className="text-fm-gold text-center">Finaliser l'abonnement</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} data-testid="form-payment">
          <div className="mb-6">
            <PaymentElement />
          </div>
          <Button 
            type="submit"
            disabled={!stripe}
            className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-bold py-3"
            data-testid="button-confirm-payment"
          >
            Confirmer l'abonnement
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [clientSecret, setClientSecret] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Vous devez être connecté pour vous abonner",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (isAuthenticated) {
      apiRequest("POST", "/api/create-subscription")
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
        })
        .catch((error) => {
          if (isUnauthorizedError(error)) {
            toast({
              title: "Session expirée",
              description: "Reconnexion en cours...",
              variant: "destructive",
            });
            setTimeout(() => {
              window.location.href = "/api/login";
            }, 500);
            return;
          }
          toast({
            title: "Erreur",
            description: "Impossible de créer l'abonnement",
            variant: "destructive",
          });
        });
    }
  }, [isAuthenticated, toast]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const features = [
    {
      icon: Users,
      title: "Profil joueur complet",
      description: "Toutes vos informations professionnelles"
    },
    {
      icon: Trophy,
      title: "Stats style Football Manager",
      description: "Système de notation sur 20 comme dans FM"
    },
    {
      icon: TrendingUp,
      title: "Historique carrière détaillé",
      description: "Suivi saison par saison de votre parcours"
    },
    {
      icon: Camera,
      title: "Galerie vidéos et photos",
      description: "Partagez vos meilleurs moments"
    },
    {
      icon: Star,
      title: "Classements communautaires",
      description: "Participez aux rankings et gagnez en visibilité"
    },
    {
      icon: CheckCircle,
      title: "Support premium",
      description: "Assistance prioritaire et nouvelles fonctionnalités"
    }
  ];

  // Show info message if Stripe is not configured
  if (!stripePromise) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="container mx-auto max-w-4xl px-4 py-8">
          <Card className="fm-card border-2 border-fm-gold p-8 text-center">
            <CardHeader>
              <CardTitle className="text-3xl font-bebas text-fm-gold">CONFIGURATION STRIPE REQUISE</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 mb-6">
                Les clés Stripe doivent être configurées pour activer les paiements.
                En attendant, vous pouvez explorer l'application.
              </p>
              <Button 
                className="fm-button fm-button-gold"
                onClick={() => window.location.href = "/"}
              >
                Retour à l'accueil
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="container mx-auto max-w-4xl px-4 py-8" data-testid="subscribe-loading">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
            <h2 className="text-xl text-white">Préparation de votre abonnement...</h2>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto max-w-6xl px-4 py-8" data-testid="subscribe-content">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-montserrat font-extrabold text-4xl md:text-5xl text-white mb-4">
            Rejoignez <span className="text-fm-gold">FM IRL Premium</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Débloquez toutes les fonctionnalités pour gérer votre carrière comme un professionnel
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Features */}
          <div>
            <Card className="bg-card border-2 border-fm-gold relative overflow-hidden mb-8" data-testid="card-pricing-info">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-fm-gold to-emerald-500"></div>
              <CardHeader className="text-center">
                <div className="text-6xl font-bold text-fm-gold mb-2" data-testid="text-price">6,99€</div>
                <div className="text-lg text-muted-foreground">par mois</div>
                <div className="text-sm text-muted-foreground mt-2">
                  Paiement sécurisé par Stripe • Annulation à tout moment
                </div>
              </CardHeader>
            </Card>

            <div className="space-y-4">
              <h3 className="font-montserrat font-bold text-2xl text-white mb-6">
                Tout ce dont vous avez besoin :
              </h3>
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-card/50" data-testid={`feature-item-${index}`}>
                  <div className="bg-fm-gold/10 p-2 rounded-lg">
                    <feature.icon className="w-6 h-6 text-fm-gold" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-1" data-testid={`text-feature-title-${index}`}>
                      {feature.title}
                    </h4>
                    <p className="text-sm text-muted-foreground" data-testid={`text-feature-description-${index}`}>
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Form */}
          <div>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SubscribeForm />
            </Elements>
            
            <div className="mt-8 text-center">
              <div className="bg-card/30 rounded-lg p-6">
                <h4 className="font-semibold text-white mb-3">Garanties FM IRL</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    Annulation à tout moment
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    Paiement 100% sécurisé
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    Support client réactif
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    Nouvelles fonctionnalités incluses
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-4">Rejoint par des centaines de joueurs ambitieux</p>
          <div className="flex justify-center items-center gap-8 opacity-60">
            <div className="text-2xl font-bold text-fm-gold">500+</div>
            <div className="text-sm text-muted-foreground">Joueurs inscrits</div>
            <div className="w-px h-8 bg-border"></div>
            <div className="text-2xl font-bold text-fm-gold">15k+</div>
            <div className="text-sm text-muted-foreground">Médias partagés</div>
            <div className="w-px h-8 bg-border"></div>
            <div className="text-2xl font-bold text-fm-gold">4.9/5</div>
            <div className="text-sm text-muted-foreground">Satisfaction</div>
          </div>
        </div>
      </main>
    </div>
  );
}
