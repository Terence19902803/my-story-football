import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function LegalNotice() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">MENTIONS LÉGALES</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. ÉDITEUR DE L'APPLICATION</h2>
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">My Story Football</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p><strong>Éditeur :</strong> Terence Desrues</p>
                    <p><strong>Statut :</strong> Micro-entrepreneur</p>
                    <p><strong>Email :</strong> contact@mystoryfootball.com</p>
                    <p><strong>Devise :</strong> "De l'amateur au pro, Montre qui tu es"</p>
                  </div>
                  <div>
                    <p><strong>Application :</strong> My Story Football</p>
                    <p><strong>Version :</strong> 1.0.0</p>
                    <p><strong>Type :</strong> Progressive Web App (PWA)</p>
                    <p><strong>Plateforme :</strong> iOS / Android / Web</p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. HÉBERGEMENT ET INFRASTRUCTURE</h2>
              
              <h3 className="text-xl font-semibold mb-3">2.1 Hébergement principal</h3>
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <p><strong>Replit, Inc.</strong></p>
                <p>767 Bryant St. #203, San Francisco, CA 94107, États-Unis</p>
                <p>Site web : https://replit.com</p>
              </div>

              <h3 className="text-xl font-semibold mb-3">2.2 Stockage des données</h3>
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <p><strong>Base de données :</strong> Neon (PostgreSQL)</p>
                <p><strong>Stockage fichiers :</strong> Google Cloud Storage</p>
                <p><strong>Localisation :</strong> Europe (RGPD conforme)</p>
              </div>

              <h3 className="text-xl font-semibold mb-3">2.3 Paiements</h3>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Stripe, Inc.</strong></p>
                <p>510 Townsend Street, San Francisco, CA 94103, États-Unis</p>
                <p>Certifié PCI DSS niveau 1</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. OBJET DE L'APPLICATION</h2>
              <p className="mb-4">
                My Story Football est une plateforme communautaire dédiée au football permettant de :
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>Créer et gérer des profils de joueurs, entraîneurs et clubs</li>
                <li>Partager des statistiques sportives style Football Manager</li>
                <li>Documenter l'historique de carrière footballistique</li>
                <li>Partager des médias (photos, vidéos) liés au football</li>
                <li>Interagir avec la communauté football française et internationale</li>
                <li>Consulter des classements et effectuer des comparaisons</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. PROPRIÉTÉ INTELLECTUELLE</h2>
              
              <h3 className="text-xl font-semibold mb-3">4.1 Droits de l'éditeur</h3>
              <p className="mb-4">
                Tous les éléments de l'application My Story Football sont protégés par les droits 
                de propriété intellectuelle :
              </p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Nom et logo :</strong> "My Story Football" ® Terence Desrues</li>
                <li><strong>Slogan :</strong> "De l'amateur au pro, Montre qui tu es" ® Terence Desrues</li>
                <li><strong>Code source :</strong> Propriété exclusive de Terence Desrues</li>
                <li><strong>Design et interface :</strong> Création originale protégée</li>
                <li><strong>Base de données :</strong> Structure et organisation protégées</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">4.2 Contenus utilisateurs</h3>
              <p>
                Les utilisateurs conservent la propriété de leurs contenus (photos, vidéos, textes) 
                mais accordent à My Story Football une licence d'utilisation dans le cadre du service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. RESPONSABILITÉ</h2>
              
              <h3 className="text-xl font-semibold mb-3">5.1 Disponibilité du service</h3>
              <p className="mb-4">
                Nous nous efforçons d'assurer une disponibilité optimale de l'application, 
                cependant nous ne garantissons pas un service ininterrompu en raison de :
              </p>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Maintenance technique programmée</li>
                <li>Pannes imprévisibles des infrastructures</li>
                <li>Attaques informatiques ou surcharge</li>
                <li>Défaillances des prestataires tiers</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">5.2 Contenu utilisateur</h3>
              <p>
                L'éditeur n'est pas responsable du contenu publié par les utilisateurs. 
                Cependant, nous nous réservons le droit de modérer et supprimer tout 
                contenu contraire à nos conditions d'utilisation.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. DONNÉES PERSONNELLES</h2>
              <p className="mb-4">
                Le traitement des données personnelles est détaillé dans notre 
                <Link href="/privacy-policy" className="text-fm-gold underline"> Politique de Confidentialité</Link>.
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Responsable de traitement :</strong> Terence Desrues</p>
                <p><strong>DPO :</strong> contact@mystoryfootball.com</p>
                <p><strong>Finalités :</strong> Gestion des comptes, fonctionnalités de l'app, communication</p>
                <p><strong>Base légale :</strong> Consentement, exécution du contrat, intérêt légitime</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. COOKIES</h2>
              <p>
                L'utilisation des cookies est détaillée dans notre 
                <Link href="/cookie-policy" className="text-fm-gold underline"> Politique des Cookies</Link>. 
                En résumé, nous utilisons des cookies pour :
              </p>
              <ul className="list-disc list-inside space-y-2 mt-4">
                <li>Maintenir votre session de connexion</li>
                <li>Mémoriser vos préférences d'affichage</li>
                <li>Analyser l'usage de l'application (anonyme)</li>
                <li>Assurer la sécurité des transactions</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. DROIT APPLICABLE</h2>
              <p className="mb-4">
                L'application et les présentes mentions légales sont régies par le droit français.
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Juridiction compétente :</strong> Tribunaux français</p>
                <p><strong>Réglementation applicable :</strong></p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>RGPD (Règlement Général sur la Protection des Données)</li>
                  <li>Loi Informatique et Libertés</li>
                  <li>Code de la consommation</li>
                  <li>Directive e-commerce</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. MÉDIATION</h2>
              <p className="mb-4">
                En cas de litige, les parties s'efforceront de trouver une solution amiable. 
                À défaut, vous pouvez recourir à :
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>Médiation de la consommation :</strong></p>
                <p>Plateforme européenne de règlement des litiges en ligne</p>
                <p><strong>URL :</strong> https://ec.europa.eu/consumers/odr/</p>
                <p><strong>Délai :</strong> Dans l'année suivant la réclamation écrite</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. ÉVOLUTION DES MENTIONS</h2>
              <p>
                Ces mentions légales peuvent être modifiées à tout moment. 
                Les modifications substantielles seront portées à votre connaissance 
                par email ou notification dans l'application.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">11. CONTACT</h2>
              <div className="bg-white/5 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Pour nous contacter :</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p><strong>Support technique :</strong></p>
                    <p>contact@mystoryfootball.com</p>
                    <p>Objet : "Support - [Votre problème]"</p>
                  </div>
                  <div>
                    <p><strong>Questions légales :</strong></p>
                    <p>contact@mystoryfootball.com</p>
                    <p>Objet : "Légal - [Votre question]"</p>
                  </div>
                  <div>
                    <p><strong>Signalement :</strong></p>
                    <p>contact@mystoryfootball.com</p>
                    <p>Objet : "Signalement - [Description]"</p>
                  </div>
                  <div>
                    <p><strong>Données personnelles :</strong></p>
                    <p>contact@mystoryfootball.com</p>
                    <p>Objet : "RGPD - [Votre demande]"</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-white/60">
                  <strong>Délai de réponse :</strong> 72 heures maximum (hors week-ends et jours fériés)
                </p>
              </div>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-white/40 mt-2">
                My Story Football - "De l'amateur au pro, Montre qui tu es" - © {new Date().getFullYear()} Terence Desrues
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}