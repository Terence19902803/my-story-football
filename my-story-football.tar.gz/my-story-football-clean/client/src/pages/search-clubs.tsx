import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Building2, Trophy, Users, MapPin, Search,
  Heart, UserCheck
} from "lucide-react";
import { FRENCH_CLUBS } from "@shared/constants";
import Header from "@/components/Header";

export default function SearchClubs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLeague, setSelectedLeague] = useState("");
  const [selectedLevel, setSelectedLevel] = useState("");
  const [clubs, setClubs] = useState(FRENCH_CLUBS);

  useEffect(() => {
    filterClubs();
  }, [searchTerm, selectedLeague, selectedLevel]);

  const filterClubs = () => {
    let filtered = FRENCH_CLUBS;
    
    if (searchTerm) {
      filtered = filtered.filter(club => 
        club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        club.city.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedLeague) {
      filtered = filtered.filter(club => club.league === selectedLeague);
    }
    
    if (selectedLevel) {
      filtered = filtered.filter(club => club.level === selectedLevel);
    }
    
    setClubs(filtered);
  };

  // Obtenir les ligues uniques
  const leagues = [...new Set(FRENCH_CLUBS.map(club => club.league))];
  
  // Générer un nombre aléatoire d'inscrits pour la démo (simulerait le nombre réel d'inscrits)
  const getRegisteredPlayers = (club: typeof FRENCH_CLUBS[0]) => {
    // En production, cela viendrait de la base de données
    // Pour la démo, générer un nombre basé sur le niveau du club
    if (club.level === 'pro') {
      return Math.floor(Math.random() * 50) + 20; // 20-70 joueurs
    } else if (club.level === 'semi-pro') {
      return Math.floor(Math.random() * 30) + 10; // 10-40 joueurs
    } else {
      return Math.floor(Math.random() * 20); // 0-20 joueurs
    }
  };

  const getLevelLabel = (level: string) => {
    switch (level) {
      case 'pro': return 'Professionnel';
      case 'semi-pro': return 'Semi-Pro';
      case 'amateur': return 'Amateur';
      default: return level;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'pro': return 'text-yellow-500 bg-yellow-500/20 border-yellow-500/30';
      case 'semi-pro': return 'text-blue-500 bg-blue-500/20 border-blue-500/30';
      case 'amateur': return 'text-green-500 bg-green-500/20 border-green-500/30';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-fm-darker">
      <Header />
      
      <main className="container mx-auto max-w-7xl px-4 py-6">
        <h1 className="font-bebas text-3xl text-blue-500 mb-6">
          Clubs
        </h1>

        {/* Filtres */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input 
                placeholder="Rechercher un club ou une ville..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-background border-gray-700"
              />
            </div>
            <select 
              className="px-4 py-2 rounded-lg bg-background border border-gray-700 text-white"
              value={selectedLeague}
              onChange={(e) => setSelectedLeague(e.target.value)}
            >
              <option value="">Toutes les ligues</option>
              {leagues.map(league => (
                <option key={league} value={league}>{league}</option>
              ))}
            </select>
            <select 
              className="px-4 py-2 rounded-lg bg-background border border-gray-700 text-white"
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
            >
              <option value="">Tous les niveaux</option>
              <option value="pro">Professionnel</option>
              <option value="semi-pro">Semi-Pro</option>
              <option value="amateur">Amateur</option>
            </select>
          </div>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-card rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-white">{FRENCH_CLUBS.filter(c => c.level === 'pro').length}</div>
            <div className="text-sm text-gray-400">Clubs Pro</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-white">{FRENCH_CLUBS.filter(c => c.level === 'semi-pro').length}</div>
            <div className="text-sm text-gray-400">Clubs Semi-Pro</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-white">{FRENCH_CLUBS.filter(c => c.level === 'amateur').length}</div>
            <div className="text-sm text-gray-400">Clubs Amateur</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-white">{clubs.length}</div>
            <div className="text-sm text-gray-400">Résultats</div>
          </div>
        </div>

        {/* Résultats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {clubs.map((club) => {
            const registeredPlayers = getRegisteredPlayers(club);
            return (
              <Card key={club.id} className="bg-card border-gray-700 hover:border-blue-500 transition-all">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full border-2 border-blue-500 bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                      <Building2 className="w-6 h-6 text-blue-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-white text-sm truncate">{club.name}</h3>
                      <div className="flex items-center gap-1 text-xs text-gray-400">
                        <MapPin className="w-3 h-3" />
                        <span className="truncate">{club.city}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">{club.league}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${getLevelColor(club.level)}`}>
                        {getLevelLabel(club.level)}
                      </span>
                    </div>
                    
                    {/* Nombre d'inscrits sur l'appli */}
                    <div className="flex items-center justify-between bg-gradient-to-r from-blue-500/10 to-blue-600/10 rounded-lg p-2">
                      <div className="flex items-center gap-2">
                        <UserCheck className="w-4 h-4 text-blue-500" />
                        <span className="text-xs text-gray-300">Joueurs inscrits</span>
                      </div>
                      <span className="text-sm font-bold text-white">
                        {registeredPlayers}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    size="sm" 
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white"
                  >
                    <Heart className="w-4 h-4 mr-1" />
                    Suivre
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {clubs.length === 0 && (
          <div className="text-center py-12">
            <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Aucun club trouvé</p>
            <p className="text-sm text-gray-500 mt-2">Essayez de modifier vos critères de recherche</p>
          </div>
        )}
        
        {/* Info box */}
        <div className="mt-8 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-blue-500 mt-0.5" />
            <div>
              <h3 className="text-sm font-semibold text-white mb-1">Joueurs inscrits par club</h3>
              <p className="text-xs text-gray-400">
                Le nombre de joueurs inscrits indique combien de membres de l'application sont affiliés à ce club.
                Plus ce nombre est élevé, plus le club est représenté sur My Story Football.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}