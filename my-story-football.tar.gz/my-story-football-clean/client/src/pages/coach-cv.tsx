import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Users, Trophy, Target, BookOpen, 
  TrendingUp, Heart, Star, Award, 
  Calendar, BarChart3, Clock, MapPin,
  GraduationCap, ChevronLeft, Camera,
  Play, CheckCircle, AlertCircle
} from "lucide-react";

export default function CoachCV() {
  const coachData = {
    name: "Philippe Moreau",
    age: 48,
    club: "AS Montpellier", 
    role: "Entraîneur Principal",
    experience: "15 ans",
    license: "UEFA Pro",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces",
    likes: 892,
    rank: 8,
    philosophy: "Jeu offensif basé sur la possession et la créativité",
    biography: "Ancien joueur professionnel reconverti entraîneur, Philippe Moreau a gravi les échelons du coaching après une carrière prometteuse stoppée par une blessure. Formé à l'INF Clairefontaine, il promeut un football technique et offensif. Son parcours l'a mené du centre de formation du PSG jusqu'à la Ligue 2 avec Montpellier.",
    
    // Points forts
    strengths: [
      "Excellent formateur de jeunes talents",
      "Tactique flexible et adaptative", 
      "Gestion humaine exceptionnelle",
      "Analyse vidéo poussée"
    ],
    
    // Axes de progression
    improvements: [
      "Expérience en compétitions européennes",
      "Gestion de la pression médiatique",
      "Communication avec les supporters"
    ],
    
    // Section Média
    media: [
      {
        type: "photo",
        title: "Conférence de presse", 
        date: "12 novembre 2023",
        likes: 234,
        image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=400&h=300&fit=crop"
      },
      {
        type: "video",
        title: "Analyse tactique du derby",
        date: "5 novembre 2023", 
        views: 1567,
        duration: "2:45",
        image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=300&fit=crop"
      },
      {
        type: "photo",
        title: "Entraînement collectif",
        date: "28 octobre 2023",
        likes: 456,
        image: "https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=400&h=300&fit=crop"
      }
    ],
    
    // Compétences coaching (sur 20)
    skills: {
      tactical: [
        { name: "Tactique", value: 17 },
        { name: "Formation jeunes", value: 15 },
        { name: "Analyse vidéo", value: 16 }
      ],
      management: [
        { name: "Motivation", value: 19 },
        { name: "Communication", value: 18 },
        { name: "Gestion groupe", value: 16 }
      ],
      technical: [
        { name: "Entraînement", value: 17 },
        { name: "Préparation physique", value: 14 },
        { name: "Développement technique", value: 16 }
      ]
    },
    
    // Statistiques carrière
    stats: {
      totalMatches: 412,
      wins: 198,
      draws: 108,
      losses: 106,
      winRate: "48%",
      goalsFor: 687,
      goalsAgainst: 432,
      trophies: 5
    },
    
    // Historique carrière
    career: [
      {
        season: "2023-2024",
        club: "AS Montpellier",
        role: "Entraîneur Principal",
        league: "Ligue 2",
        position: "6ème",
        matches: 38,
        wins: 15,
        draws: 11,
        losses: 12
      },
      {
        season: "2022-2023",
        club: "FC Nantes B",
        role: "Entraîneur Principal",
        league: "National 2",
        position: "2ème",
        matches: 30,
        wins: 18,
        draws: 7,
        losses: 5
      },
      {
        season: "2021-2022",
        club: "FC Nantes",
        role: "Entraîneur Adjoint",
        league: "Ligue 1",
        position: "9ème",
        matches: 38,
        wins: 14,
        draws: 10,
        losses: 14
      }
    ],
    
    // Palmarès
    achievements: [
      { year: "2023", title: "Montée en Ligue 2", club: "FC Nantes B" },
      { year: "2021", title: "Meilleur entraîneur National 2", club: "FC Nantes B" },
      { year: "2019", title: "Coupe régionale", club: "US Créteil" },
      { year: "2018", title: "Champion National 3", club: "US Créteil" },
      { year: "2016", title: "Meilleur formateur régional", club: "Centre de formation PSG" }
    ]
  };

  return (
    <div className="min-h-screen bg-fm-darker">
      {/* Header Navigation */}
      <div className="sticky top-0 z-50 bg-fm-darker/95 backdrop-blur-xl border-b border-purple-500/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              className="text-white hover:text-purple-500"
              onClick={() => window.history.back()}
            >
              <ChevronLeft className="w-5 h-5 mr-1" />
              Retour
            </Button>
            <span className="font-bebas text-xl text-purple-500">Profil Entraîneur</span>
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Profile Header */}
        <Card className="bg-gradient-to-r from-purple-500/20 to-transparent border-purple-500/30 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <img 
                src={coachData.image}
                alt={coachData.name}
                className="w-32 h-32 rounded-full border-4 border-purple-500 object-cover"
              />
              
              <div className="flex-1 text-center md:text-left">
                <h1 className="font-bebas text-4xl text-white mb-2">{coachData.name}</h1>
                <div className="flex flex-wrap justify-center md:justify-start gap-4 text-sm text-white/80">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4 text-purple-500" />
                    {coachData.club}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-purple-500" />
                    {coachData.role}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-purple-500" />
                    {coachData.experience}
                  </div>
                  <div className="flex items-center gap-1">
                    <Award className="w-4 h-4 text-purple-500" />
                    {coachData.license}
                  </div>
                </div>
                
                <div className="mt-4 p-4 bg-fm-dark/50 rounded-lg">
                  <p className="text-white/90 italic text-center md:text-left">
                    "{coachData.philosophy}"
                  </p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-500/20 p-4 rounded-xl">
                  <div className="text-3xl font-bold text-purple-500">{coachData.likes}</div>
                  <div className="text-sm text-white/60">Likes</div>
                </div>
                <div className="mt-3">
                  <div className="text-2xl font-bold text-white">#{coachData.rank}</div>
                  <div className="text-sm text-white/60">Classement</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Biography Section */}
        <Card className="bg-card border-purple-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-4">Biographie</h2>
            <p className="text-white/80 leading-relaxed">
              {coachData.biography}
            </p>
          </CardContent>
        </Card>

        {/* Mon Projet Section */}
        <Card className="bg-card border-purple-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-4">Mon Projet</h2>
            <p className="text-white/80 leading-relaxed">
              Mon ambition est de développer des jeunes talents et de les accompagner vers le haut niveau. 
              Je souhaite continuer à évoluer dans la formation tout en visant un poste d'entraîneur principal en Ligue 2. 
              Mon objectif à long terme est de diriger une équipe professionnelle et de la qualifier pour les compétitions européennes.
            </p>
          </CardContent>
        </Card>

        {/* Career Statistics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-4 text-center">
              <Trophy className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{coachData.stats.wins}</div>
              <div className="text-sm text-white/60">Victoires</div>
              <div className="text-xs text-purple-500 mt-1">{coachData.stats.winRate} taux</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-4 text-center">
              <BarChart3 className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{coachData.stats.totalMatches}</div>
              <div className="text-sm text-white/60">Matchs dirigés</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{coachData.stats.goalsFor}</div>
              <div className="text-sm text-white/60">Buts marqués</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-4 text-center">
              <Award className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{coachData.stats.trophies}</div>
              <div className="text-sm text-white/60">Trophées</div>
            </CardContent>
          </Card>
        </div>

        {/* Strengths and Improvements */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-6">
              <h3 className="font-bebas text-xl text-purple-500 mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Points Forts
              </h3>
              <div className="space-y-3">
                {coachData.strengths.map((strength, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-white/80">{strength}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-purple-500/20">
            <CardContent className="p-6">
              <h3 className="font-bebas text-xl text-purple-500 mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Axes de Progression
              </h3>
              <div className="space-y-3">
                {coachData.improvements.map((improvement, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-white/80">{improvement}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Coaching Skills */}
        <Card className="bg-card border-purple-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-6">Compétences Coaching</h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {/* Tactical */}
              <div>
                <h3 className="font-bold text-white mb-4">Tactique</h3>
                <div className="space-y-3">
                  {coachData.skills.tactical.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-white/70">{skill.name}</span>
                        <span className="text-sm font-bold text-purple-500">{skill.value}/20</span>
                      </div>
                      <div className="w-full bg-fm-dark/50 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-purple-400 h-2 rounded-full"
                          style={{ width: `${(skill.value / 20) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Management */}
              <div>
                <h3 className="font-bold text-white mb-4">Management</h3>
                <div className="space-y-3">
                  {coachData.skills.management.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-white/70">{skill.name}</span>
                        <span className="text-sm font-bold text-purple-500">{skill.value}/20</span>
                      </div>
                      <div className="w-full bg-fm-dark/50 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-purple-400 h-2 rounded-full"
                          style={{ width: `${(skill.value / 20) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Technical */}
              <div>
                <h3 className="font-bold text-white mb-4">Technique</h3>
                <div className="space-y-3">
                  {coachData.skills.technical.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-white/70">{skill.name}</span>
                        <span className="text-sm font-bold text-purple-500">{skill.value}/20</span>
                      </div>
                      <div className="w-full bg-fm-dark/50 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-purple-400 h-2 rounded-full"
                          style={{ width: `${(skill.value / 20) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Career History */}
        <Card className="bg-card border-purple-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-6">Historique Carrière</h2>
            
            <div className="space-y-4">
              {coachData.career.map((season, index) => (
                <Card key={index} className="bg-fm-dark/50 border-purple-500/10">
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <div className="font-bold text-white">{season.season}</div>
                        <div className="text-sm text-white/70">{season.club} - {season.role}</div>
                        <div className="text-xs text-purple-500 mt-1">{season.league} • {season.position}</div>
                      </div>
                      <div className="flex gap-4 text-sm">
                        <div className="text-center">
                          <div className="font-bold text-green-500">{season.wins}</div>
                          <div className="text-xs text-white/50">V</div>
                        </div>
                        <div className="text-center">
                          <div className="font-bold text-yellow-500">{season.draws}</div>
                          <div className="text-xs text-white/50">N</div>
                        </div>
                        <div className="text-center">
                          <div className="font-bold text-red-500">{season.losses}</div>
                          <div className="text-xs text-white/50">D</div>
                        </div>
                        <div className="text-center">
                          <div className="font-bold text-white">{season.matches}</div>
                          <div className="text-xs text-white/50">Matchs</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card className="bg-card border-purple-500/20 mb-8">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-6">Palmarès</h2>
            
            <div className="grid md:grid-cols-2 gap-4">
              {coachData.achievements.map((achievement, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-fm-dark/50 rounded-lg">
                  <Trophy className="w-6 h-6 text-purple-500 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-white">{achievement.title}</div>
                    <div className="text-sm text-white/60">{achievement.year} • {achievement.club}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Media Section */}
        <Card className="bg-card border-purple-500/20">
          <CardContent className="p-6">
            <h2 className="font-bebas text-2xl text-purple-500 mb-6">Médias</h2>
            
            <div className="grid md:grid-cols-3 gap-4">
              {coachData.media.map((item, index) => (
                <Card key={index} className="bg-fm-dark/50 border-purple-500/10 overflow-hidden cursor-pointer hover:scale-105 transition-transform">
                  <div className="relative">
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-40 object-cover"
                    />
                    {item.type === 'video' && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Play className="w-12 h-12 text-white" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-3">
                    <h4 className="font-bold text-white text-sm mb-1">{item.title}</h4>
                    <p className="text-xs text-white/60 mb-2">{item.date}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1">
                        {item.type === 'video' ? (
                          <>
                            <Play className="w-3 h-3 text-purple-500" />
                            <span className="text-xs text-white/60">{item.views} vues</span>
                          </>
                        ) : (
                          <>
                            <Heart className="w-3 h-3 text-purple-500" />
                            <span className="text-xs text-white/60">{item.likes} likes</span>
                          </>
                        )}
                      </div>
                      {item.type === 'video' && (
                        <span className="text-xs text-purple-500">{item.duration}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
        {/* CTA Final */}
        <Card className="bg-card border-2 border-purple-500 text-center p-8 mb-24">
          <div className="mb-6">
            <Trophy className="w-16 h-16 text-purple-500 mx-auto mb-4" />
            <h2 className="font-bebas text-4xl text-white mb-2">
              CRÉEZ VOTRE PROFIL COACH PROFESSIONNEL
            </h2>
            <p className="text-xl text-gray-400">
              Rejoignez Profil Pro et gérez votre carrière comme un professionnel
            </p>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Button
              size="lg"
              className="bg-purple-500 hover:bg-purple-600 text-white font-bold"
              onClick={() => window.location.href = '/create-coach'}
              data-testid="button-create-coach"
            >
              Commencer maintenant
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-purple-500 text-purple-500 hover:bg-purple-500/20"
              onClick={() => window.location.href = '/'}
            >
              Retour à l'accueil
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}