import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function Legal() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto max-w-4xl px-4 py-8" data-testid="legal-content">
        <div className="text-center mb-12">
          <h1 className="font-montserrat font-extrabold text-4xl md:text-5xl text-white mb-4">
            Mentions <span className="text-fm-gold">Légales</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Informations légales et conditions d'utilisation de FM IRL
          </p>
        </div>

        <div className="space-y-8">
          {/* Éditeur */}
          <Card className="bg-card border-border" data-testid="card-editor">
            <CardHeader>
              <CardTitle className="text-fm-gold">Éditeur du site</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Football Manager IRL</h4>
                <p className="text-muted-foreground">
                  Plateforme de gestion de carrière footballistique
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Contact</h4>
                <p className="text-muted-foreground">
                  Email : contact@fm-irl.com<br/>
                  Téléphone : +33 1 23 45 67 89
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Hébergement */}
          <Card className="bg-card border-border" data-testid="card-hosting">
            <CardHeader>
              <CardTitle className="text-fm-gold">Hébergement</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Ce site est hébergé par Replit, Inc.<br/>
                767 Bryant St. #203, San Francisco, CA 94107, USA
              </p>
            </CardContent>
          </Card>

          {/* Conditions d'utilisation */}
          <Card className="bg-card border-border" data-testid="card-terms">
            <CardHeader>
              <CardTitle className="text-fm-gold">Conditions d'utilisation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Accès au service</h4>
                <p className="text-muted-foreground">
                  L'accès à FM IRL est réservé aux abonnés ayant souscrit à l'offre premium au tarif de 6,99€/mois. 
                  L'abonnement est renouvelé automatiquement chaque mois sauf résiliation par l'utilisateur.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Utilisation des services</h4>
                <p className="text-muted-foreground">
                  Les utilisateurs s'engagent à utiliser la plateforme de manière respectueuse et conforme aux lois en vigueur. 
                  Ils sont responsables du contenu qu'ils publient (profils, photos, vidéos).
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Résiliation</h4>
                <p className="text-muted-foreground">
                  L'abonnement peut être résilié à tout moment depuis l'interface utilisateur. 
                  La résiliation prend effet à la fin de la période de facturation en cours.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Propriété intellectuelle */}
          <Card className="bg-card border-border" data-testid="card-ip">
            <CardHeader>
              <CardTitle className="text-fm-gold">Propriété intellectuelle</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Contenu de la plateforme</h4>
                <p className="text-muted-foreground">
                  Le design, l'architecture, et tous les éléments de la plateforme FM IRL sont protégés par le droit d'auteur. 
                  Toute reproduction sans autorisation est interdite.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Contenu utilisateur</h4>
                <p className="text-muted-foreground">
                  Les utilisateurs conservent la propriété de leur contenu (profils, photos, vidéos) mais accordent à FM IRL 
                  une licence d'utilisation nécessaire au fonctionnement du service.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Responsabilité */}
          <Card className="bg-card border-border" data-testid="card-liability">
            <CardHeader>
              <CardTitle className="text-fm-gold">Responsabilité</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Limitation de responsabilité</h4>
                <p className="text-muted-foreground">
                  FM IRL met tout en œuvre pour assurer la disponibilité et la sécurité du service, 
                  mais ne peut garantir une disponibilité à 100%. La responsabilité de FM IRL est limitée 
                  au montant de l'abonnement mensuel.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Contenu utilisateur</h4>
                <p className="text-muted-foreground">
                  FM IRL n'est pas responsable du contenu publié par les utilisateurs. 
                  Chaque utilisateur est responsable de ses publications et de leur conformité aux lois en vigueur.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card className="bg-card border-border" data-testid="card-contact">
            <CardHeader>
              <CardTitle className="text-fm-gold">Contact</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Pour toute question concernant ces mentions légales ou l'utilisation de notre service :<br/><br/>
                
                <strong className="text-white">Email :</strong> legal@fm-irl.com<br/>
                <strong className="text-white">Téléphone :</strong> +33 1 23 45 67 89<br/>
                <strong className="text-white">Adresse :</strong> Football Manager IRL, Service Juridique
              </p>
            </CardContent>
          </Card>

          <Separator className="my-8" />
          
          <div className="text-center text-sm text-muted-foreground">
            <p>Dernière mise à jour : 1er septembre 2024</p>
          </div>
        </div>
      </main>
    </div>
  );
}
