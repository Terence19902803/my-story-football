import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Trophy, MapPin, Calendar, Globe, Users, 
  Award, Target, TrendingUp, Star, ChevronLeft, Download,
  Mail, Phone, Instagram, Twitter, Heart, Share2
} from "lucide-react";

export default function PlayerCV() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-fm-dark border-b border-fm-gold/20 py-3 md:py-4 px-2 md:px-4 sticky top-0 z-50">
        <div className="container mx-auto max-w-6xl">
          {/* Mobile Layout */}
          <div className="md:hidden flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:text-fm-gold p-2"
                onClick={() => window.location.href = "/"}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <div className="flex items-center gap-1.5">
                <Trophy className="w-5 h-5 text-fm-gold flex-shrink-0" />
                <span className="font-bebas text-sm text-white truncate">
                  PROFIL <span className="text-fm-gold">JOUEUR</span>
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                className="text-fm-gold hover:bg-fm-gold/20 p-2"
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                className="bg-fm-gold text-fm-dark hover:bg-fm-gold/90 px-3 py-1 text-xs"
                onClick={() => window.location.href = "/api/login"}
              >
                Créer
              </Button>
            </div>
          </div>
          
          {/* Desktop Layout */}
          <div className="hidden md:flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                className="text-white hover:text-fm-gold"
                onClick={() => window.location.href = "/"}
              >
                <ChevronLeft className="w-5 h-5 mr-2" />
                Retour
              </Button>
              <div className="flex items-center gap-2">
                <Trophy className="w-8 h-8 text-fm-gold" />
                <span className="font-bebas text-2xl text-white">
                  PROFIL <span className="text-fm-gold">JOUEUR</span> PROFESSIONNEL
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                className="border-fm-gold text-fm-gold hover:bg-fm-gold/20"
              >
                <Download className="w-4 h-4 mr-2" />
                Télécharger PDF
              </Button>
              <Button
                className="fm-button fm-button-gold"
                onClick={() => window.location.href = "/api/login"}
              >
                Créer mon profil
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto max-w-7xl px-4 py-8">
        {/* Header avec photo et infos principales */}
        <Card className="fm-card border-2 border-fm-gold mb-8 overflow-hidden">
          <div className="fm-gradient-gold h-2"></div>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-3 gap-6 md:gap-8">
              {/* Photo et infos de base */}
              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=300&h=300&fit=crop&crop=faces" 
                  alt="Photo joueur"
                  className="w-32 h-32 md:w-48 md:h-48 rounded-full mx-auto mb-3 md:mb-4 border-2 md:border-4 border-fm-gold object-cover"
                />
                <h1 className="font-bebas text-2xl md:text-4xl text-white mb-2 leading-tight">NICOLAS MARTINEZ</h1>
                <Badge className="bg-fm-gold text-fm-dark mb-3 md:mb-4 text-xs md:text-sm">Milieu Offensif</Badge>
                
                <div className="flex items-center justify-center gap-4 text-xs md:text-sm text-gray-400 mb-3 md:mb-4">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 md:w-4 md:h-4" />
                    Lyon, France
                  </span>
                </div>

                {/* Réseaux sociaux */}
                <div className="flex justify-center gap-2 md:gap-3 mb-3 md:mb-4">
                  <Button size="sm" variant="outline" className="border-gray-600 h-8 w-8 md:h-10 md:w-10 p-0">
                    <Mail className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="border-gray-600 h-8 w-8 md:h-10 md:w-10 p-0">
                    <Phone className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="border-gray-600 h-8 w-8 md:h-10 md:w-10 p-0">
                    <Instagram className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="border-gray-600 h-8 w-8 md:h-10 md:w-10 p-0">
                    <Twitter className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                </div>

                {/* Stats de popularité */}
                <div className="grid grid-cols-2 gap-2 md:gap-4 p-3 md:p-4 bg-card rounded-lg">
                  <div>
                    <div className="text-lg md:text-2xl font-bold text-fm-gold">3,847</div>
                    <div className="text-[10px] md:text-xs text-gray-500">Likes</div>
                  </div>
                  <div>
                    <div className="text-lg md:text-2xl font-bold text-fm-green">#8</div>
                    <div className="text-[10px] md:text-xs text-gray-500">Classement</div>
                  </div>
                </div>
              </div>

              {/* Informations détaillées */}
              <div className="md:col-span-2 space-y-6">
                {/* Informations personnelles */}
                <div>
                  <h3 className="font-bebas text-2xl text-fm-gold mb-4">INFORMATIONS PERSONNELLES</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Date de naissance:</span>
                        <span className="text-white font-semibold">15 Mars 1998 (26 ans)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Nationalité:</span>
                        <span className="text-white font-semibold">🇫🇷 Française</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Lieu de naissance:</span>
                        <span className="text-white font-semibold">Marseille, France</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Taille:</span>
                        <span className="text-white font-semibold">1m82</span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Poids:</span>
                        <span className="text-white font-semibold">75 kg</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Pied fort:</span>
                        <span className="text-white font-semibold">Droit (★★★★☆ Gauche)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Agent:</span>
                        <span className="text-white font-semibold">Sports Management Int.</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Valeur marchande:</span>
                        <span className="text-fm-gold font-bold">8.5M €</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Club actuel */}
                <div>
                  <h3 className="font-bebas text-2xl text-fm-gold mb-4">CLUB ACTUEL</h3>
                  <Card className="bg-card/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-white rounded-lg flex items-center justify-center font-bold text-2xl">
                            OL
                          </div>
                          <div>
                            <h4 className="font-bold text-xl text-white">Olympique Lyonnais</h4>
                            <p className="text-gray-400">Ligue 1 • Depuis 2022</p>
                            <p className="text-sm text-gray-500">Contrat jusqu'en Juin 2026</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-3xl font-bebas text-fm-gold">#10</div>
                          <div className="text-sm text-gray-400">Numéro</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Biographie */}
                <div>
                  <h3 className="font-bebas text-2xl text-fm-gold mb-4">BIOGRAPHIE</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Formé à l'Olympique de Marseille, Nicolas Martinez a gravi tous les échelons du centre de formation phocéen avant de faire ses débuts professionnels en 2017. 
                    Milieu offensif technique et créatif, il s'est rapidement imposé comme l'un des grands espoirs du football français. 
                    Après 5 saisons à Marseille et un passage remarqué à Monaco, il a rejoint l'Olympique Lyonnais en 2022 où il est devenu un élément clé de l'équipe. 
                    International Espoirs français, il aspire à décrocher sa première sélection en équipe de France A.
                  </p>
                </div>

                {/* Mon Projet */}
                <div>
                  <h3 className="font-bebas text-2xl text-fm-gold mb-4">MON PROJET</h3>
                  <p className="text-gray-300 leading-relaxed mb-6">
                    Mon objectif est de devenir un joueur clé en Ligue 1 et de décrocher ma première sélection en équipe de France A. 
                    Je travaille quotidiennement pour améliorer ma finition et ma condition physique. 
                    À moyen terme, j'aspire à évoluer dans l'un des cinq grands championnats européens et participer aux compétitions européennes.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistiques détaillées FM */}
        <Card className="fm-card mb-8">
          <CardHeader>
            <CardTitle className="font-bebas text-3xl text-fm-gold">
              ATTRIBUTS PROFESSIONNELS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              {/* Techniques */}
              <div>
                <h4 className="font-bebas text-xl text-fm-green mb-4">TECHNIQUES (150 pts)</h4>
                <div className="space-y-3">
                  {[
                    { name: "Contrôle de balle", value: 18, color: "bg-green-500" },
                    { name: "Dribble", value: 17, color: "bg-green-500" },
                    { name: "Finition", value: 13, color: "bg-yellow-500" },
                    { name: "Tête", value: 8, color: "bg-red-500" },
                    { name: "Tirs de loin", value: 14, color: "bg-yellow-500" },
                    { name: "Passes", value: 19, color: "bg-green-500" },
                    { name: "Centres", value: 15, color: "bg-yellow-500" },
                    { name: "Technique", value: 18, color: "bg-green-500" },
                    { name: "Coups francs", value: 16, color: "bg-green-500" },
                    { name: "Tacles", value: 12, color: "bg-orange-500" }
                  ].map((stat) => (
                    <div key={stat.name} className="flex items-center gap-3">
                      <span className="text-sm text-gray-400 w-32">{stat.name}</span>
                      <div className="flex-1 bg-gray-700 rounded-full h-2 relative">
                        <div 
                          className={`${stat.color} h-2 rounded-full`}
                          style={{ width: `${(stat.value / 20) * 100}%` }}
                        />
                      </div>
                      <span className="text-white font-bold w-8 text-right">{stat.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Mentales */}
              <div>
                <h4 className="font-bebas text-xl text-fm-blue mb-4">MENTALES (150 pts)</h4>
                <div className="space-y-3">
                  {[
                    { name: "Vision du jeu", value: 19, color: "bg-green-500" },
                    { name: "Anticipation", value: 16, color: "bg-green-500" },
                    { name: "Sang-froid", value: 15, color: "bg-yellow-500" },
                    { name: "Concentration", value: 14, color: "bg-yellow-500" },
                    { name: "Décisions", value: 17, color: "bg-green-500" },
                    { name: "Détermination", value: 15, color: "bg-yellow-500" },
                    { name: "Créativité", value: 18, color: "bg-green-500" },
                    { name: "Leadership", value: 11, color: "bg-orange-500" },
                    { name: "Positionnement", value: 13, color: "bg-orange-500" },
                    { name: "Travail d'équipe", value: 12, color: "bg-orange-500" }
                  ].map((stat) => (
                    <div key={stat.name} className="flex items-center gap-3">
                      <span className="text-sm text-gray-400 w-32">{stat.name}</span>
                      <div className="flex-1 bg-gray-700 rounded-full h-2 relative">
                        <div 
                          className={`${stat.color} h-2 rounded-full`}
                          style={{ width: `${(stat.value / 20) * 100}%` }}
                        />
                      </div>
                      <span className="text-white font-bold w-8 text-right">{stat.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Physiques */}
              <div>
                <h4 className="font-bebas text-xl text-fm-orange mb-4">PHYSIQUES (150 pts)</h4>
                <div className="space-y-3">
                  {[
                    { name: "Accélération", value: 16, color: "bg-green-500" },
                    { name: "Vitesse", value: 15, color: "bg-yellow-500" },
                    { name: "Agilité", value: 17, color: "bg-green-500" },
                    { name: "Équilibre", value: 16, color: "bg-green-500" },
                    { name: "Détente", value: 11, color: "bg-orange-500" },
                    { name: "Endurance", value: 15, color: "bg-yellow-500" },
                    { name: "Force", value: 12, color: "bg-orange-500" },
                    { name: "Résistance", value: 14, color: "bg-yellow-500" },
                    { name: "Explosivité", value: 17, color: "bg-green-500" },
                    { name: "Récupération", value: 17, color: "bg-green-500" }
                  ].map((stat) => (
                    <div key={stat.name} className="flex items-center gap-3">
                      <span className="text-sm text-gray-400 w-32">{stat.name}</span>
                      <div className="flex-1 bg-gray-700 rounded-full h-2 relative">
                        <div 
                          className={`${stat.color} h-2 rounded-full`}
                          style={{ width: `${(stat.value / 20) * 100}%` }}
                        />
                      </div>
                      <span className="text-white font-bold w-8 text-right">{stat.value}</span>
                    </div>
                  ))}
                </div>

                {/* Note globale */}
                <div className="mt-8 p-4 bg-gradient-to-r from-fm-gold/20 to-fm-green/20 rounded-lg text-center">
                  <div className="text-5xl font-bebas text-fm-gold mb-2">87</div>
                  <div className="text-sm text-gray-400">NOTE GLOBALE</div>
                  <div className="flex justify-center gap-1 mt-2">
                    {[1,2,3,4,5].map((star) => (
                      <Star key={star} className={`w-5 h-5 ${star <= 4 ? 'text-fm-gold fill-fm-gold' : 'text-gray-600'}`} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Historique de carrière */}
        <Card className="fm-card mb-8">
          <CardHeader>
            <CardTitle className="font-bebas text-3xl text-fm-gold">
              PARCOURS PROFESSIONNEL
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 text-gray-400">Saison</th>
                    <th className="text-left py-3 text-gray-400">Club</th>
                    <th className="text-center py-3 text-gray-400">Division</th>
                    <th className="text-center py-3 text-gray-400">Matchs</th>
                    <th className="text-center py-3 text-gray-400">Buts</th>
                    <th className="text-center py-3 text-gray-400">Passes D.</th>
                    <th className="text-center py-3 text-gray-400">Cartons J.</th>
                    <th className="text-center py-3 text-gray-400">Cartons R.</th>
                    <th className="text-center py-3 text-gray-400">Note Moy.</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2023-24</td>
                    <td className="py-3 text-white">Olympique Lyonnais</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">34</td>
                    <td className="text-center py-3 text-fm-gold font-bold">12</td>
                    <td className="text-center py-3 text-fm-green font-bold">15</td>
                    <td className="text-center py-3">3</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7.8</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2022-23</td>
                    <td className="py-3 text-white">Olympique Lyonnais</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">31</td>
                    <td className="text-center py-3 text-fm-gold font-bold">8</td>
                    <td className="text-center py-3 text-fm-green font-bold">11</td>
                    <td className="text-center py-3">4</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7.4</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2021-22</td>
                    <td className="py-3 text-white">AS Monaco</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">28</td>
                    <td className="text-center py-3 text-fm-gold font-bold">6</td>
                    <td className="text-center py-3 text-fm-green font-bold">9</td>
                    <td className="text-center py-3">2</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7.2</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2020-21</td>
                    <td className="py-3 text-white">Olympique Marseille</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">35</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7</td>
                    <td className="text-center py-3 text-fm-green font-bold">8</td>
                    <td className="text-center py-3">5</td>
                    <td className="text-center py-3">1</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7.1</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2019-20</td>
                    <td className="py-3 text-white">Olympique Marseille</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">22</td>
                    <td className="text-center py-3 text-fm-gold font-bold">3</td>
                    <td className="text-center py-3 text-fm-green font-bold">5</td>
                    <td className="text-center py-3">3</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">6.8</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2018-19</td>
                    <td className="py-3 text-white">Olympique Marseille</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">18</td>
                    <td className="text-center py-3 text-fm-gold font-bold">2</td>
                    <td className="text-center py-3 text-fm-green font-bold">3</td>
                    <td className="text-center py-3">2</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">6.5</td>
                  </tr>
                  <tr className="border-b border-gray-800 hover:bg-gray-800/30">
                    <td className="py-3 text-white font-semibold">2017-18</td>
                    <td className="py-3 text-white">Olympique Marseille</td>
                    <td className="text-center py-3">Ligue 1</td>
                    <td className="text-center py-3 text-white font-semibold">8</td>
                    <td className="text-center py-3 text-fm-gold font-bold">1</td>
                    <td className="text-center py-3 text-fm-green font-bold">1</td>
                    <td className="text-center py-3">1</td>
                    <td className="text-center py-3">0</td>
                    <td className="text-center py-3 text-fm-gold font-bold">6.3</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-fm-gold">
                    <td className="py-3 text-fm-gold font-bold">TOTAL</td>
                    <td className="py-3"></td>
                    <td className="py-3"></td>
                    <td className="text-center py-3 text-white font-bold">176</td>
                    <td className="text-center py-3 text-fm-gold font-bold">39</td>
                    <td className="text-center py-3 text-fm-green font-bold">52</td>
                    <td className="text-center py-3 font-bold">20</td>
                    <td className="text-center py-3 font-bold">1</td>
                    <td className="text-center py-3 text-fm-gold font-bold">7.1</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Palmarès */}
        <Card className="fm-card mb-8">
          <CardHeader>
            <CardTitle className="font-bebas text-3xl text-fm-gold">
              PALMARÈS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              {/* Trophées collectifs */}
              <div>
                <h4 className="font-bebas text-xl text-fm-green mb-4">TROPHÉES COLLECTIFS</h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Trophy className="w-12 h-12 text-fm-gold" />
                    <div>
                      <h5 className="text-white font-semibold">Coupe de France</h5>
                      <p className="text-sm text-gray-400">AS Monaco • 2021-22</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Trophy className="w-12 h-12 text-fm-gold" />
                    <div>
                      <h5 className="text-white font-semibold">Finaliste Europa League</h5>
                      <p className="text-sm text-gray-400">Olympique Marseille • 2017-18</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Trophy className="w-12 h-12 text-gray-400" />
                    <div>
                      <h5 className="text-white font-semibold">Championnat U19 National</h5>
                      <p className="text-sm text-gray-400">Olympique Marseille • 2016-17</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Distinctions individuelles */}
              <div>
                <h4 className="font-bebas text-xl text-fm-blue mb-4">DISTINCTIONS INDIVIDUELLES</h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Award className="w-12 h-12 text-fm-gold" />
                    <div>
                      <h5 className="text-white font-semibold">Joueur du mois Ligue 1</h5>
                      <p className="text-sm text-gray-400">Octobre 2023</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Award className="w-12 h-12 text-fm-gold" />
                    <div>
                      <h5 className="text-white font-semibold">Équipe type Ligue 1</h5>
                      <p className="text-sm text-gray-400">Saison 2023-24</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Award className="w-12 h-12 text-gray-400" />
                    <div>
                      <h5 className="text-white font-semibold">Meilleur passeur OL</h5>
                      <p className="text-sm text-gray-400">Saison 2023-24 • 15 passes</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-gray-700">
                    <Award className="w-12 h-12 text-gray-400" />
                    <div>
                      <h5 className="text-white font-semibold">International Espoirs</h5>
                      <p className="text-sm text-gray-400">France U21 • 12 sélections</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Points forts et axes de progression */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Points forts */}
          <Card className="fm-card">
            <CardHeader>
              <CardTitle className="font-bebas text-2xl text-fm-green">
                POINTS FORTS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Star className="w-5 h-5 text-fm-green mt-0.5" />
                  <span className="text-gray-300">Vision du jeu exceptionnelle et créativité</span>
                </li>
                <li className="flex items-start gap-3">
                  <Star className="w-5 h-5 text-fm-green mt-0.5" />
                  <span className="text-gray-300">Technique individuelle de très haut niveau</span>
                </li>
                <li className="flex items-start gap-3">
                  <Star className="w-5 h-5 text-fm-green mt-0.5" />
                  <span className="text-gray-300">Qualité de passes et dernière passe décisive</span>
                </li>
                <li className="flex items-start gap-3">
                  <Star className="w-5 h-5 text-fm-green mt-0.5" />
                  <span className="text-gray-300">Excellent sur coups de pied arrêtés</span>
                </li>
                <li className="flex items-start gap-3">
                  <Star className="w-5 h-5 text-fm-green mt-0.5" />
                  <span className="text-gray-300">Capacité à faire la différence dans les grands matchs</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Axes de progression */}
          <Card className="fm-card">
            <CardHeader>
              <CardTitle className="font-bebas text-2xl text-fm-orange">
                AXES DE PROGRESSION
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-fm-orange mt-0.5" />
                  <span className="text-gray-300">Améliorer l'impact défensif et le pressing</span>
                </li>
                <li className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-fm-orange mt-0.5" />
                  <span className="text-gray-300">Développer le jeu de tête et le jeu aérien</span>
                </li>
                <li className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-fm-orange mt-0.5" />
                  <span className="text-gray-300">Renforcer la puissance physique</span>
                </li>
                <li className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-fm-orange mt-0.5" />
                  <span className="text-gray-300">Gagner en leadership et caractère</span>
                </li>
                <li className="flex items-start gap-3">
                  <Target className="w-5 h-5 text-fm-orange mt-0.5" />
                  <span className="text-gray-300">Améliorer la régularité sur une saison complète</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Statistiques avancées */}
        <Card className="fm-card mb-8">
          <CardHeader>
            <CardTitle className="font-bebas text-3xl text-fm-gold">
              STATISTIQUES AVANCÉES SAISON 2023-24
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-card rounded-lg">
                <div className="text-3xl font-bebas text-fm-gold">89%</div>
                <div className="text-sm text-gray-400">Passes réussies</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg">
                <div className="text-3xl font-bebas text-fm-green">2.8</div>
                <div className="text-sm text-gray-400">Occasions créées/match</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg">
                <div className="text-3xl font-bebas text-fm-blue">3.2</div>
                <div className="text-sm text-gray-400">Dribbles réussis/match</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg">
                <div className="text-3xl font-bebas text-fm-orange">62</div>
                <div className="text-sm text-gray-400">Ballons récupérés</div>
              </div>
            </div>

            <Separator className="my-6 bg-gray-700" />

            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <h4 className="font-semibold text-white mb-4">Répartition des buts</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Pied droit</span>
                    <span className="text-white">8 buts</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Pied gauche</span>
                    <span className="text-white">3 buts</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tête</span>
                    <span className="text-white">1 but</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-4">Zone de jeu préférée</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Milieu central</span>
                    <span className="text-white">45%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Côté droit</span>
                    <span className="text-white">35%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Côté gauche</span>
                    <span className="text-white">20%</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-4">Temps de jeu</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Minutes jouées</span>
                    <span className="text-white">2,847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Titularisations</span>
                    <span className="text-white">30/34</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Remplacements</span>
                    <span className="text-white">4</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Final */}
        <Card className="fm-card border-2 border-fm-gold text-center p-8">
          <div className="mb-6">
            <Trophy className="w-16 h-16 text-fm-gold mx-auto mb-4" />
            <h2 className="font-bebas text-4xl text-white mb-2">
              CRÉEZ VOTRE PROFIL JOUEUR PROFESSIONNEL
            </h2>
            <p className="text-xl text-gray-400">
              Rejoignez Profil Pro et gérez votre carrière comme un professionnel
            </p>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Button
              size="lg"
              className="fm-button fm-button-gold"
              onClick={() => window.location.href = "/api/login"}
            >
              Commencer maintenant
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-fm-gold text-fm-gold hover:bg-fm-gold/20"
              onClick={() => window.location.href = "/"}
            >
              Retour à l'accueil
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}