import { Trophy, Medal, Award, User, Heart, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function TopProfiles() {
  const topPlayers = [
    { rank: 1, icon: "🥇", color: "from-yellow-400 to-yellow-600", likes: 45320 },
    { rank: 2, icon: "🥈", color: "from-gray-300 to-gray-500", likes: 38190 },
    { rank: 3, icon: "🥉", color: "from-orange-400 to-orange-600", likes: 32450 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-fm-gold" />
            <h1 className="text-2xl font-bold text-white">Top 10 Profils</h1>
          </div>
          <p className="text-sm text-gray-400 mt-1">Les joueurs les plus likés de la communauté</p>
        </div>
      </div>

      {/* Podium Top 3 */}
      <div className="px-4 py-8">
        <div className="grid grid-cols-3 gap-2 mb-8">
          {topPlayers.map((player, index) => (
            <div key={player.rank} className={`${index === 0 ? 'order-2' : index === 1 ? 'order-1' : 'order-3'}`}>
              <Card className={`bg-gradient-to-br ${player.color} border-0 ${index === 0 ? 'scale-110' : ''}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{player.icon}</div>
                  <div className="w-16 h-16 mx-auto bg-white/20 rounded-full flex items-center justify-center mb-2">
                    <User className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">Joueur #{player.rank}</h3>
                  <div className="flex items-center justify-center gap-1">
                    <Heart className="w-3 h-3 text-white" />
                    <span className="text-xs text-white font-semibold">{player.likes.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* Reste du classement */}
        <div className="space-y-3">
          {[4, 5, 6, 7, 8, 9, 10].map((rank) => (
            <Card key={rank} className="bg-black/40 border-fm-gold/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {/* Rang */}
                  <div className="w-8 h-8 bg-fm-gold/20 rounded-full flex items-center justify-center">
                    <span className="text-fm-gold font-bold text-sm">#{rank}</span>
                  </div>

                  {/* Avatar */}
                  <div className="w-12 h-12 bg-gradient-to-r from-gray-700 to-gray-800 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-gray-400" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white">Joueur Pro #{rank}</h3>
                    <p className="text-xs text-gray-400">Attaquant • Paris FC</p>
                  </div>

                  {/* Likes */}
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-white">
                      <Heart className="w-4 h-4 text-red-500" />
                      <span className="font-bold text-sm">{(50000 - rank * 3000).toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-green-400 mt-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>+{15 - rank}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}