import { Camera, Heart, Eye, Download, Share2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function TopPhotos() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <div className="flex items-center gap-2">
            <Camera className="w-6 h-6 text-fm-gold" />
            <h1 className="text-2xl font-bold text-white">Top 10 Photos</h1>
          </div>
          <p className="text-sm text-gray-400 mt-1">Les photos les plus appréciées</p>
        </div>
      </div>

      {/* Grille de photos */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((index) => (
            <Card key={index} className="bg-black/40 border-fm-gold/20 overflow-hidden">
              <CardContent className="p-0">
                <div className="relative">
                  {/* Photo placeholder */}
                  <div className={`aspect-square bg-gradient-to-br ${
                    index === 1 ? 'from-purple-600 to-purple-900' :
                    index === 2 ? 'from-blue-600 to-blue-900' :
                    index === 3 ? 'from-green-600 to-green-900' :
                    'from-gray-600 to-gray-900'
                  } flex items-center justify-center`}>
                    <Camera className="w-12 h-12 text-white/30" />
                  </div>

                  {/* Badge rang */}
                  {index <= 3 && (
                    <div className={`absolute top-2 left-2 px-2 py-1 rounded-lg font-bold text-xs ${
                      index === 1 ? 'bg-yellow-500 text-black' :
                      index === 2 ? 'bg-gray-400 text-black' :
                      'bg-orange-500 text-white'
                    }`}>
                      #{index}
                    </div>
                  )}

                  {/* Stats overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-3">
                    <div className="flex items-center justify-between text-xs text-white">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Heart className="w-3 h-3 text-red-500" />
                          <span>{(15000 - index * 1000).toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          <span>{(50000 - index * 3000).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3">
                  <p className="text-xs text-gray-400">@joueur{index}</p>
                  <p className="text-xs text-white font-medium mt-1">Action mémorable</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}