import { Video, Heart, Eye, Play, Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function TopVideos() {
  const topVideos = [
    { rank: 1, likes: 89432, views: 234567, duration: "4:23", title: "But exceptionnel en finale" },
    { rank: 2, likes: 76543, views: 198234, duration: "3:15", title: "Dribbles magiques" },
    { rank: 3, likes: 65432, views: 167890, duration: "5:47", title: "Compilation des meilleures actions" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <div className="flex items-center gap-2">
            <Video className="w-6 h-6 text-fm-gold" />
            <h1 className="text-2xl font-bold text-white">Top 10 Vidéos</h1>
          </div>
          <p className="text-sm text-gray-400 mt-1">Les vidéos les plus likées du mois</p>
        </div>
      </div>

      {/* Top 3 en vedette */}
      <div className="px-4 py-6 space-y-4">
        {topVideos.map((video) => (
          <Card key={video.rank} className={`border-0 overflow-hidden ${
            video.rank === 1 ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/10' :
            video.rank === 2 ? 'bg-gradient-to-r from-gray-400/20 to-gray-500/10' :
            'bg-gradient-to-r from-orange-500/20 to-orange-600/10'
          }`}>
            <CardContent className="p-0">
              <div className="relative">
                {/* Thumbnail */}
                <div className="aspect-video bg-gradient-to-r from-gray-800 to-gray-900 flex items-center justify-center">
                  <Play className="w-16 h-16 text-white/50" />
                </div>

                {/* Badge rang */}
                <div className={`absolute top-3 left-3 px-3 py-1.5 rounded-full font-bold text-sm flex items-center gap-1 ${
                  video.rank === 1 ? 'bg-yellow-500 text-black' :
                  video.rank === 2 ? 'bg-gray-400 text-black' :
                  'bg-orange-500 text-white'
                }`}>
                  <Award className="w-4 h-4" />
                  <span>#{video.rank}</span>
                </div>

                {/* Durée */}
                <div className="absolute bottom-3 right-3 bg-black/80 px-2 py-1 rounded text-xs text-white font-semibold">
                  {video.duration}
                </div>
              </div>

              <div className="p-4">
                <h3 className="text-white font-bold mb-2">{video.title}</h3>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1 text-white">
                      <Heart className="w-4 h-4 text-red-500" />
                      <span className="font-semibold">{video.likes.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-400">
                      <Eye className="w-4 h-4" />
                      <span>{video.views.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Reste du classement */}
      <div className="px-4 pb-6">
        <div className="space-y-3">
          {[4, 5, 6, 7, 8, 9, 10].map((rank) => (
            <Card key={rank} className="bg-black/40 border-fm-gold/20">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  {/* Thumbnail mini */}
                  <div className="relative w-32 aspect-video bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg overflow-hidden flex-shrink-0">
                    <Play className="absolute inset-0 m-auto w-8 h-8 text-white/50" />
                    <div className="absolute bottom-1 right-1 bg-black/80 px-1.5 py-0.5 rounded text-xs text-white font-semibold">
                      {2 + Math.floor(Math.random() * 3)}:{10 + Math.floor(Math.random() * 50)}
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-fm-gold font-bold text-sm">#{rank}</span>
                          <h3 className="text-sm font-semibold text-white truncate">Performance #{rank}</h3>
                        </div>
                        <p className="text-xs text-gray-400">@joueur{rank} • Il y a {rank} jours</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 mt-2 text-xs">
                      <div className="flex items-center gap-1 text-white">
                        <Heart className="w-3 h-3 text-red-500" />
                        <span>{(60000 - rank * 5000).toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1 text-gray-400">
                        <Eye className="w-3 h-3" />
                        <span>{(150000 - rank * 12000).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}