import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Users, Trophy, Heart, Search, MapPin,
  Target, TrendingUp, Shield, GraduationCap
} from "lucide-react";
import Header from "@/components/Header";

interface Coach {
  id: string;
  name: string;
  club: string;
  city: string;
  experience: number;
  wins: number;
  draws: number;
  losses: number;
  philosophy: string;
  speciality: string;
  likes: number;
}

export default function SearchCoaches() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPhilosophy, setSelectedPhilosophy] = useState("");
  const [coaches, setCoaches] = useState<Coach[]>([]);

  // Données exemple d'entraîneurs
  const allCoaches: Coach[] = [
    { id: "1", name: "Jean-Marc Dubois", club: "FC Lyon", city: "Lyon", experience: 15, wins: 142, draws: 87, losses: 45, philosophy: "Jeu offensif", speciality: "Formation jeunes", likes: 2341 },
    { id: "2", name: "Thierry Martin", club: "AS Monaco B", city: "Monaco", experience: 12, wins: 98, draws: 52, losses: 31, philosophy: "Possession", speciality: "Tactique", likes: 1876 },
    { id: "3", name: "Laurent Petit", club: "RC Strasbourg", city: "Strasbourg", experience: 10, wins: 87, draws: 43, losses: 29, philosophy: "Contre-attaque", speciality: "Préparation physique", likes: 1543 },
    { id: "4", name: "Michel Bernard", club: "Toulouse FC", city: "Toulouse", experience: 8, wins: 76, draws: 41, losses: 38, philosophy: "Pressing haut", speciality: "Gestion de groupe", likes: 1298 },
    { id: "5", name: "Patrick Moreau", club: "Nantes FC", city: "Nantes", experience: 7, wins: 65, draws: 38, losses: 42, philosophy: "Défense solide", speciality: "Montée en puissance", likes: 987 },
    { id: "6", name: "Didier Blanc", club: "FC Metz", city: "Metz", experience: 6, wins: 54, draws: 35, losses: 51, philosophy: "Polyvalent", speciality: "Recrutement", likes: 765 },
    { id: "7", name: "François Durand", club: "Lens B", city: "Lens", experience: 9, wins: 89, draws: 45, losses: 32, philosophy: "Jeu offensif", speciality: "Développement jeunes", likes: 1432 },
    { id: "8", name: "Philippe Rousseau", club: "Nice B", city: "Nice", experience: 11, wins: 102, draws: 56, losses: 41, philosophy: "Possession", speciality: "Analyse vidéo", likes: 1654 }
  ];

  useEffect(() => {
    filterCoaches();
  }, [searchTerm, selectedPhilosophy]);

  const filterCoaches = () => {
    let filtered = allCoaches;
    
    if (searchTerm) {
      filtered = filtered.filter(coach => 
        coach.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        coach.club.toLowerCase().includes(searchTerm.toLowerCase()) ||
        coach.city.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (selectedPhilosophy) {
      filtered = filtered.filter(coach => coach.philosophy === selectedPhilosophy);
    }
    
    setCoaches(filtered);
  };

  const philosophies = ["Jeu offensif", "Possession", "Contre-attaque", "Pressing haut", "Défense solide", "Polyvalent"];

  const getWinRate = (coach: Coach) => {
    const total = coach.wins + coach.draws + coach.losses;
    return total > 0 ? Math.round((coach.wins / total) * 100) : 0;
  };

  return (
    <div className="min-h-screen bg-fm-darker">
      <Header />
      
      <main className="container mx-auto max-w-6xl px-4 py-6">
        <h1 className="font-bebas text-3xl text-purple-500 mb-6">
          Coachs
        </h1>

        {/* Filtres */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input 
                placeholder="Rechercher un entraîneur, club ou ville..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-background border-gray-700"
              />
            </div>
            <select 
              className="px-4 py-2 rounded-lg bg-background border border-gray-700 text-white"
              value={selectedPhilosophy}
              onChange={(e) => setSelectedPhilosophy(e.target.value)}
            >
              <option value="">Toutes philosophies</option>
              {philosophies.map(philosophy => (
                <option key={philosophy} value={philosophy}>{philosophy}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Résultats */}
        <div className="text-sm text-gray-400 mb-4">
          {coaches.length} entraîneur{coaches.length > 1 ? 's' : ''} trouvé{coaches.length > 1 ? 's' : ''}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {coaches.map((coach) => (
            <Card key={coach.id} className="bg-card border-purple-500/30 hover:border-purple-500 transition-all">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <img 
                    src={`https://images.unsplash.com/photo-${coach.id % 2 === 0 ? '1507003211169-0a1dd7228f2d' : '1500648767791-1163a6c8163c'}?w=64&h=64&fit=crop&crop=faces`}
                    alt={coach.name}
                    className="w-16 h-16 rounded-full border-2 border-purple-500 object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-bold text-white text-lg">{coach.name}</h3>
                    <p className="text-sm text-gray-400">{coach.club}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <MapPin className="w-3 h-3" />
                      <span>{coach.city}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">
                      <GraduationCap className="w-4 h-4 inline mr-1" />
                      Expérience:
                    </span>
                    <span className="text-white font-semibold">{coach.experience} ans</span>
                  </div>
                  
                  <div className="text-xs text-gray-400 mb-2">Statistiques de carrière:</div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-green-500/20 rounded p-1">
                      <div className="text-lg font-bold text-green-500">{coach.wins}</div>
                      <div className="text-[10px] text-gray-400">Victoires</div>
                    </div>
                    <div className="bg-yellow-500/20 rounded p-1">
                      <div className="text-lg font-bold text-yellow-500">{coach.draws}</div>
                      <div className="text-[10px] text-gray-400">Nuls</div>
                    </div>
                    <div className="bg-red-500/20 rounded p-1">
                      <div className="text-lg font-bold text-red-500">{coach.losses}</div>
                      <div className="text-[10px] text-gray-400">Défaites</div>
                    </div>
                  </div>

                  <div className="flex justify-between text-sm mt-2">
                    <span className="text-gray-400">Taux de victoire:</span>
                    <span className="text-purple-500 font-bold">{getWinRate(coach)}%</span>
                  </div>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-purple-500" />
                    <span className="text-sm text-gray-400">Philosophie:</span>
                    <span className="text-purple-500 font-semibold text-sm">{coach.philosophy}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-purple-500" />
                    <span className="text-sm text-gray-400">Spécialité:</span>
                    <span className="text-white font-semibold text-sm">{coach.speciality}</span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="text-center">
                    <div className="text-lg font-bold text-white">{coach.likes.toLocaleString()}</div>
                    <div className="text-xs text-muted-foreground">Likes</div>
                  </div>
                  <Button 
                    size="sm" 
                    className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white"
                  >
                    <Heart className="w-4 h-4 mr-1" />
                    Liker
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {coaches.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Aucun entraîneur trouvé</p>
            <p className="text-sm text-gray-500 mt-2">Essayez de modifier vos critères de recherche</p>
          </div>
        )}
      </main>
    </div>
  );
}