import ClubOnboarding from "@/components/ClubOnboarding";

export default function CreateClub() {
  const handleComplete = () => {
    window.location.href = "/home";
  };

  return (
    <ClubOnboarding onComplete={handleComplete} />
  );
}