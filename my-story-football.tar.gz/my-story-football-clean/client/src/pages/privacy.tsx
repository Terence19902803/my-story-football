import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto max-w-4xl px-4 py-8" data-testid="privacy-content">
        <div className="text-center mb-12">
          <h1 className="font-montserrat font-extrabold text-4xl md:text-5xl text-white mb-4">
            Politique de <span className="text-fm-gold">Confidentialité</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Comment nous protégeons et utilisons vos données personnelles
          </p>
        </div>

        <div className="space-y-8">
          {/* Introduction */}
          <Card className="bg-card border-border" data-testid="card-intro">
            <CardHeader>
              <CardTitle className="text-fm-gold">Notre engagement</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Chez Football Manager IRL, nous prenons la protection de vos données personnelles très au sérieux. 
                Cette politique explique quelles données nous collectons, comment nous les utilisons et quels sont vos droits 
                conformément au Règlement Général sur la Protection des Données (RGPD).
              </p>
            </CardContent>
          </Card>

          {/* Données collectées */}
          <Card className="bg-card border-border" data-testid="card-data-collected">
            <CardHeader>
              <CardTitle className="text-fm-gold">Données collectées</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Informations de compte</h4>
                <p className="text-muted-foreground">
                  • Email (pour la connexion et les communications)<br/>
                  • Nom et prénom<br/>
                  • Photo de profil (optionnelle)
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Informations de profil joueur</h4>
                <p className="text-muted-foreground">
                  • Nom de joueur<br/>
                  • Date de naissance<br/>
                  • Nationalité<br/>
                  • Poste et club actuel<br/>
                  • Biographie<br/>
                  • Statistiques footballistiques<br/>
                  • Historique de carrière
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Contenu multimédia</h4>
                <p className="text-muted-foreground">
                  • Photos et vidéos téléchargées<br/>
                  • Métadonnées des fichiers (taille, type, date)
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Données de paiement</h4>
                <p className="text-muted-foreground">
                  • Informations de facturation (traitées par Stripe)<br/>
                  • Historique des abonnements
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Utilisation des données */}
          <Card className="bg-card border-border" data-testid="card-data-usage">
            <CardHeader>
              <CardTitle className="text-fm-gold">Finalité de l'utilisation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Fonctionnement du service</h4>
                <p className="text-muted-foreground">
                  • Création et gestion de votre profil joueur<br/>
                  • Affichage de vos statistiques et historique<br/>
                  • Participation aux classements communautaires<br/>
                  • Stockage et partage de vos médias
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Gestion des abonnements</h4>
                <p className="text-muted-foreground">
                  • Traitement des paiements via Stripe<br/>
                  • Gestion du renouvellement automatique<br/>
                  • Support client et facturation
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Amélioration du service</h4>
                <p className="text-muted-foreground">
                  • Analyse de l'utilisation pour améliorer l'expérience<br/>
                  • Développement de nouvelles fonctionnalités<br/>
                  • Résolution des problèmes techniques
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Partage des données */}
          <Card className="bg-card border-border" data-testid="card-data-sharing">
            <CardHeader>
              <CardTitle className="text-fm-gold">Partage des données</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Partenaires de confiance</h4>
                <p className="text-muted-foreground">
                  • <strong>Stripe :</strong> pour le traitement sécurisé des paiements<br/>
                  • <strong>Replit :</strong> pour l'hébergement et l'infrastructure<br/>
                  • <strong>Google Cloud :</strong> pour le stockage des médias
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Données publiques</h4>
                <p className="text-muted-foreground">
                  Seules les informations que vous choisissez de rendre publiques dans votre profil 
                  sont visibles par les autres utilisateurs de la plateforme.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Conservation */}
          <Card className="bg-card border-border" data-testid="card-data-retention">
            <CardHeader>
              <CardTitle className="text-fm-gold">Conservation des données</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Nous conservons vos données personnelles aussi longtemps que votre compte est actif. 
                Après suppression de votre compte, vos données personnelles sont supprimées dans un délai de 30 jours, 
                à l'exception des données nécessaires pour des obligations légales ou comptables.
              </p>
            </CardContent>
          </Card>

          {/* Droits RGPD */}
          <Card className="bg-card border-border" data-testid="card-rights">
            <CardHeader>
              <CardTitle className="text-fm-gold">Vos droits (RGPD)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-white mb-2">Droit d'accès</h4>
                <p className="text-muted-foreground">
                  Vous pouvez demander une copie de toutes les données personnelles que nous détenons sur vous.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-white mb-2">Droit de rectification</h4>
                <p className="text-muted-foreground">
                  Vous pouvez modifier vos informations personnelles directement dans votre profil 
                  ou nous contacter pour corriger des données inexactes.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Droit à l'effacement</h4>
                <p className="text-muted-foreground">
                  Vous pouvez demander la suppression de vos données personnelles en supprimant votre compte 
                  ou en nous contactant directement.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Droit à la portabilité</h4>
                <p className="text-muted-foreground">
                  Vous pouvez demander à recevoir vos données dans un format structuré pour les transférer ailleurs.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Droit d'opposition</h4>
                <p className="text-muted-foreground">
                  Vous pouvez vous opposer au traitement de vos données à des fins de marketing 
                  ou dans certaines autres circonstances.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Sécurité */}
          <Card className="bg-card border-border" data-testid="card-security">
            <CardHeader>
              <CardTitle className="text-fm-gold">Sécurité des données</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Nous mettons en place des mesures techniques et organisationnelles appropriées pour protéger vos données :
                <br/><br/>
                • Chiffrement des données en transit et au repos<br/>
                • Accès restreint aux données personnelles<br/>
                • Surveillance continue de nos systèmes<br/>
                • Partenaires certifiés pour le traitement des paiements<br/>
                • Sauvegardes régulières et plan de récupération
              </p>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card className="bg-card border-border" data-testid="card-contact">
            <CardHeader>
              <CardTitle className="text-fm-gold">Contact et réclamations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Pour exercer vos droits ou pour toute question concernant cette politique de confidentialité :<br/><br/>
                
                <strong className="text-white">Email :</strong> privacy@fm-irl.com<br/>
                <strong className="text-white">Délégué à la protection des données :</strong> dpo@fm-irl.com<br/><br/>
                
                Vous avez également le droit de déposer une plainte auprès de la Commission Nationale de l'Informatique 
                et des Libertés (CNIL) si vous estimez que vos droits ne sont pas respectés.
              </p>
            </CardContent>
          </Card>

          <Separator className="my-8" />
          
          <div className="text-center text-sm text-muted-foreground">
            <p>Dernière mise à jour : 1er septembre 2024</p>
          </div>
        </div>
      </main>
    </div>
  );
}
