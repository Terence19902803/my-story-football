import { Play, Eye, Heart, Clock, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function MostViewedVideos() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-white">Vidéos les plus vues</h1>
          <p className="text-sm text-gray-400 mt-1">Les meilleures performances de la semaine</p>
        </div>
      </div>

      {/* Filtres */}
      <div className="px-4 py-4">
        <div className="flex gap-2 overflow-x-auto">
          <button className="px-4 py-2 bg-fm-gold/20 text-fm-gold rounded-lg text-sm font-semibold whitespace-nowrap">
            Cette semaine
          </button>
          <button className="px-4 py-2 bg-black/40 text-white/70 rounded-lg text-sm font-semibold whitespace-nowrap hover:bg-black/60 transition-colors">
            Ce mois
          </button>
          <button className="px-4 py-2 bg-black/40 text-white/70 rounded-lg text-sm font-semibold whitespace-nowrap hover:bg-black/60 transition-colors">
            Tout temps
          </button>
        </div>
      </div>

      {/* Liste des vidéos */}
      <div className="px-4 py-2 space-y-4">
        {[1, 2, 3, 4, 5].map((index) => (
          <Card key={index} className="bg-black/40 border-fm-gold/20 overflow-hidden">
            <CardContent className="p-0">
              <div className="relative">
                {/* Thumbnail placeholder */}
                <div className="aspect-video bg-gradient-to-r from-gray-800 to-gray-900 flex items-center justify-center">
                  <Play className="w-12 h-12 text-white/50" />
                </div>
                
                {/* Durée */}
                <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs text-white font-semibold">
                  3:45
                </div>

                {/* Nombre de vues */}
                <div className="absolute top-2 left-2 bg-black/80 px-2 py-1 rounded-lg flex items-center gap-1">
                  <Eye className="w-3 h-3 text-fm-gold" />
                  <span className="text-xs text-white font-semibold">{(index * 12543).toLocaleString()}</span>
                </div>
              </div>

              <div className="p-4">
                <h3 className="text-white font-semibold mb-1">Performance exceptionnelle #{index}</h3>
                <p className="text-xs text-gray-400 mb-3">Joueur Pro • Il y a {index} jour{index > 1 ? 's' : ''}</p>
                
                {/* Stats */}
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-1 text-gray-400">
                    <Heart className="w-3 h-3" />
                    <span>{(index * 432).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-400">
                    <TrendingUp className="w-3 h-3" />
                    <span>+{index * 12}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}