import { Play, Flame, Heart, Clock, Share2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function TrendingVideos() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <div className="flex items-center gap-2 mb-2">
            <Flame className="w-6 h-6 text-orange-500" />
            <h1 className="text-2xl font-bold text-white">Vidéos du moment</h1>
          </div>
          <p className="text-sm text-gray-400">Les vidéos qui font le buzz aujourd'hui</p>
        </div>
      </div>

      {/* Vidéo à la une */}
      <div className="px-4 py-6">
        <Card className="bg-gradient-to-br from-fm-gold/20 to-yellow-500/10 border-fm-gold/30 overflow-hidden">
          <CardContent className="p-0">
            <div className="relative">
              <div className="aspect-video bg-gradient-to-r from-purple-800 to-purple-900 flex items-center justify-center">
                <Play className="w-16 h-16 text-white/70" />
              </div>
              
              {/* Badge Trending */}
              <div className="absolute top-2 left-2 bg-orange-500/90 px-3 py-1 rounded-full flex items-center gap-1">
                <Flame className="w-4 h-4 text-white" />
                <span className="text-xs text-white font-bold">#1 Tendance</span>
              </div>
            </div>

            <div className="p-4">
              <h3 className="text-lg text-white font-bold mb-2">Action incroyable du jour !</h3>
              <p className="text-sm text-gray-300 mb-3">La performance qui enflamme les réseaux</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs">
                  <div className="flex items-center gap-1 text-white/80">
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span className="font-semibold">156K vues</span>
                  </div>
                  <div className="flex items-center gap-1 text-white/80">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span>12.5K</span>
                  </div>
                </div>
                <button className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors">
                  <Share2 className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Autres vidéos tendance */}
      <div className="px-4">
        <h2 className="text-lg font-semibold text-white mb-4">En progression</h2>
        <div className="space-y-3">
          {[2, 3, 4, 5, 6].map((index) => (
            <Card key={index} className="bg-black/40 border-fm-gold/20">
              <CardContent className="p-3">
                <div className="flex gap-3">
                  {/* Thumbnail */}
                  <div className="relative w-32 aspect-video bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg overflow-hidden flex-shrink-0">
                    <Play className="absolute inset-0 m-auto w-8 h-8 text-white/50" />
                    <div className="absolute bottom-1 right-1 bg-black/80 px-1.5 py-0.5 rounded text-xs text-white font-semibold">
                      2:30
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-sm font-semibold text-white truncate">Performance #{index}</h3>
                        <p className="text-xs text-gray-400 mt-1">Il y a {index}h</p>
                      </div>
                      <div className="bg-orange-500/20 px-2 py-1 rounded-lg flex items-center gap-1">
                        <Flame className="w-3 h-3 text-orange-500" />
                        <span className="text-xs text-orange-400 font-bold">#{index}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                      <span>{(index * 8432).toLocaleString()} vues</span>
                      <span>+{25 - index * 3}% /h</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}