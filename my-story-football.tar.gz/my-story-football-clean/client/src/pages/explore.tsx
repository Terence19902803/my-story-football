import { useState } from "react";
import { Search, Users, TrendingUp, Play, Star } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";

export default function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    {
      title: "Joueurs populaires",
      icon: Users,
      link: "/search-players",
      color: "from-blue-500 to-blue-600"
    },
    {
      title: "Vidéos tendances",
      icon: Play,
      link: "/videos/trending",
      color: "from-purple-500 to-purple-600"
    },
    {
      title: "Top classements",
      icon: Star,
      link: "/top/profiles",
      color: "from-yellow-500 to-yellow-600"
    },
    {
      title: "En progression",
      icon: TrendingUp,
      link: "/rankings",
      color: "from-green-500 to-green-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-fm-darker to-black pb-24">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-white mb-4">Explorer</h1>
          
          {/* Barre de recherche */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher un joueur..."
              className="w-full pl-10 pr-4 py-3 bg-black/50 border border-fm-gold/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-fm-gold/40 transition-colors"
              data-testid="search-input"
            />
          </div>
        </div>
      </div>

      {/* Catégories */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-semibold text-white mb-4">Catégories</h2>
        <div className="grid grid-cols-2 gap-3">
          {categories.map((category, index) => (
            <Link key={index} href={category.link}>
              <Card className="bg-black/40 border-fm-gold/20 hover:border-fm-gold/40 transition-all duration-200 active:scale-95">
                <CardContent className="p-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center mb-3`}>
                    <category.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-sm font-semibold text-white">{category.title}</h3>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Section Découvrir */}
      <div className="px-4 py-6">
        <h2 className="text-lg font-semibold text-white mb-4">Découvrir</h2>
        <div className="space-y-4">
          {/* Profils du jour */}
          <Card className="bg-black/40 border-fm-gold/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-fm-gold to-yellow-500 flex items-center justify-center">
                  <Star className="w-5 h-5 text-fm-darker" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Profils du jour</h3>
                  <p className="text-xs text-gray-400">Les joueurs les plus actifs</p>
                </div>
              </div>
              <Link href="/top/profiles">
                <button className="text-fm-gold text-xs font-semibold hover:text-yellow-400 transition-colors">
                  Voir tous →
                </button>
              </Link>
            </CardContent>
          </Card>

          {/* Vidéos populaires */}
          <Card className="bg-black/40 border-fm-gold/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-purple-600 flex items-center justify-center">
                  <Play className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Vidéos populaires</h3>
                  <p className="text-xs text-gray-400">Les plus regardées cette semaine</p>
                </div>
              </div>
              <Link href="/videos/most-viewed">
                <button className="text-fm-gold text-xs font-semibold hover:text-yellow-400 transition-colors">
                  Voir toutes →
                </button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}