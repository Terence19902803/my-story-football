import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">POLITIQUE DE CONFIDENTIALITÉ</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. INFORMATIONS GÉNÉRALES</h2>
              <p className="mb-4">
                <strong>My Story Football</strong> (ci-après "l'Application") est éditée par <strong>Terence Desrues</strong>, 
                micro-entrepreneur, dans le cadre de la fourniture d'une plateforme communautaire dédiée au football.
              </p>
              <p className="mb-4">
                <strong>Devise :</strong> "De l'amateur au pro, Montre qui tu es"
              </p>
              <p>
                La présente politique de confidentialité décrit comment nous collectons, utilisons et protégeons 
                vos données personnelles conformément au Règlement Général sur la Protection des Données (RGPD).
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. DONNÉES COLLECTÉES</h2>
              <h3 className="text-xl font-semibold mb-3">2.1 Données d'inscription</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Nom et prénom</li>
                <li>Adresse email</li>
                <li>Photo de profil (optionnelle)</li>
                <li>Type de profil (joueur, entraîneur, club)</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">2.2 Données de profil sportif</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li>Informations footballistiques (position, club, nationalité)</li>
                <li>Statistiques sportives (style Football Manager)</li>
                <li>Historique de carrière</li>
                <li>Médias (photos et vidéos de performances)</li>
                <li>Trophées et récompenses</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">2.3 Données d'usage</h3>
              <ul className="list-disc list-inside space-y-2">
                <li>Interactions sur la plateforme (likes, partages)</li>
                <li>Données de navigation et d'utilisation</li>
                <li>Préférences utilisateur</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. FINALITÉS DU TRAITEMENT</h2>
              <p className="mb-4">Vos données sont traitées pour :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Gestion des comptes :</strong> Création et gestion de votre profil</li>
                <li><strong>Fonctionnalités de l'app :</strong> Affichage des profils, classements, interactions sociales</li>
                <li><strong>Communication :</strong> Notifications, support technique</li>
                <li><strong>Amélioration du service :</strong> Analyses d'usage, développement de nouvelles fonctionnalités</li>
                <li><strong>Obligations légales :</strong> Conformité aux réglementations applicables</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. BASE LÉGALE</h2>
              <p className="mb-4">Le traitement de vos données repose sur :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Votre consentement</strong> pour la création de profil et l'utilisation des fonctionnalités</li>
                <li><strong>L'exécution du contrat</strong> pour la fourniture des services</li>
                <li><strong>L'intérêt légitime</strong> pour l'amélioration du service et la sécurité</li>
                <li><strong>L'obligation légale</strong> pour certaines communications</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. PARTAGE DES DONNÉES</h2>
              <p className="mb-4">Vos données peuvent être partagées avec :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Autres utilisateurs :</strong> Selon vos paramètres de confidentialité (profils publics)</li>
                <li><strong>Prestataires techniques :</strong> Replit (hébergement), Google Cloud (stockage), Stripe (paiements)</li>
                <li><strong>Autorités compétentes :</strong> En cas d'obligation légale</li>
              </ul>
              <p className="mt-4">
                <strong>Nous ne vendons jamais vos données personnelles à des tiers.</strong>
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. DURÉE DE CONSERVATION</h2>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Comptes actifs :</strong> Tant que votre compte est actif</li>
                <li><strong>Comptes supprimés :</strong> 30 jours après suppression</li>
                <li><strong>Données de facturation :</strong> 10 ans (obligation comptable)</li>
                <li><strong>Logs techniques :</strong> 12 mois maximum</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. VOS DROITS</h2>
              <p className="mb-4">Conformément au RGPD, vous disposez des droits suivants :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Droit d'accès :</strong> Connaître les données que nous détenons sur vous</li>
                <li><strong>Droit de rectification :</strong> Corriger vos données inexactes</li>
                <li><strong>Droit à l'effacement :</strong> Supprimer vos données ("droit à l'oubli")</li>
                <li><strong>Droit à la portabilité :</strong> Récupérer vos données dans un format structuré</li>
                <li><strong>Droit d'opposition :</strong> Vous opposer au traitement de vos données</li>
                <li><strong>Droit de limitation :</strong> Limiter le traitement de vos données</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. SÉCURITÉ</h2>
              <p>
                Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger 
                vos données contre l'accès non autorisé, la modification, la divulgation ou la destruction, 
                notamment le chiffrement des données en transit et au repos, l'authentification sécurisée, 
                et la surveillance des accès.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. CONTACT</h2>
              <p className="mb-4">
                Pour exercer vos droits ou pour toute question relative à cette politique de confidentialité :
              </p>
              <p>
                <strong>Terence Desrues</strong><br />
                Email : <strong>contact@mystoryfootball.com</strong><br />
                Délai de réponse : 30 jours maximum
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. MODIFICATIONS</h2>
              <p>
                Cette politique peut être modifiée. Toute modification substantielle vous sera notifiée 
                par email ou via l'application au moins 30 jours avant son entrée en vigueur.
              </p>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}