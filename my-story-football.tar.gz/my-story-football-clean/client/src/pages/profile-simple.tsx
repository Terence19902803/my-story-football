import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatSlider } from "@/components/StatSlider";
import { 
  User, Save, Camera, Trophy, BarChart3, Award, Edit, X, Share2, Plus, Heart, AlertCircle
} from "lucide-react";

// Schéma de validation du formulaire profil
const profileFormSchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères"),
  dateOfBirth: z.string().optional(),
  nationality: z.string().optional(),
  position: z.string().min(1, "La position est requise"),
  currentClub: z.string().optional(),
  height: z.string().optional(),
  weight: z.string().optional(),
  preferredFoot: z.enum(["Gauche", "Droit", "Les deux"]).optional(),
  biography: z.string().max(1000).optional(),
});

export default function ProfileSimple() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth() as any;
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditing, setIsEditing] = useState(true); // Toujours en mode édition pour faciliter
  
  // Stats state avec 150 points par catégorie
  const [technicalStats, setTechnicalStats] = useState({
    corners: 10,
    crossing: 10,
    dribbling: 10,
    finishing: 10,
    firstTouch: 10,
    freeKickTaking: 10,
    heading: 10,
    longShots: 10,
    longThrows: 10,
    marking: 10,
    passing: 10,
    penaltyTaking: 10,
    tackling: 10,
    technique: 10,
  });

  const [mentalStats, setMentalStats] = useState({
    aggression: 10,
    anticipation: 10,
    bravery: 10,
    composure: 10,
    concentration: 10,
    decisions: 10,
    determination: 10,
    flair: 10,
    leadership: 10,
    offTheBall: 10,
    positioning: 10,
    teamwork: 10,
    vision: 10,
    workRate: 10,
  });

  const [physicalStats, setPhysicalStats] = useState({
    acceleration: 10,
    agility: 10,
    balance: 10,
    jumpingReach: 10,
    naturalFitness: 10,
    pace: 10,
    stamina: 10,
    strength: 10,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour accéder à votre profil",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Profile form
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: "",
      dateOfBirth: "",
      nationality: "",
      position: "",
      currentClub: "",
      height: "",
      weight: "",
      preferredFoot: "Droit",
      biography: "",
    },
  });

  // Calculate points total for a category
  const calculateCategoryTotal = (stats: any) => {
    return Object.values(stats).reduce((sum: any, val: any) => sum + val, 0);
  };

  // Update stat with 150 points limit
  const updateStat = (category: string, stat: string, value: number) => {
    const categoryStats = 
      category === 'technical' ? technicalStats :
      category === 'mental' ? mentalStats : physicalStats;
    
    const setStats = 
      category === 'technical' ? setTechnicalStats :
      category === 'mental' ? setMentalStats : setPhysicalStats;
    
    const newStats = { ...categoryStats, [stat]: value };
    const total = calculateCategoryTotal(newStats);
    
    // Limite à 150 points
    if (total <= 150) {
      setStats(newStats);
    } else {
      toast({
        title: "Limite atteinte",
        description: "Maximum 150 points par catégorie",
        variant: "destructive",
      });
    }
  };

  // Save profile
  const saveProfile = () => {
    const data = profileForm.getValues();
    toast({
      title: "Profil sauvegardé !",
      description: "Vos informations ont été enregistrées avec succès",
    });
  };

  // Save stats
  const saveStats = () => {
    toast({
      title: "Statistiques sauvegardées !",
      description: "Vos statistiques ont été mises à jour",
    });
  };

  const shareProfile = () => {
    const profileUrl = `${window.location.origin}/player/mon-profil`;
    navigator.clipboard.writeText(profileUrl);
    toast({ 
      title: "Lien copié!", 
      description: "Le lien de votre profil a été copié" 
    });
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-fm-dark via-gray-900 to-fm-dark">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="font-bebas text-5xl text-fm-gold mb-2">CRÉER MON PROFIL</h1>
            <p className="text-gray-400">Configurez votre profil de joueur professionnel</p>
          </div>
          <Button
            onClick={shareProfile}
            className="fm-button fm-button-gold"
            data-testid="button-share-profile"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Partager
          </Button>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-fm-card">
            <TabsTrigger value="profile" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <User className="w-4 h-4 mr-2" />
              Infos
            </TabsTrigger>
            <TabsTrigger value="stats" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <BarChart3 className="w-4 h-4 mr-2" />
              Stats
            </TabsTrigger>
            <TabsTrigger value="career" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Trophy className="w-4 h-4 mr-2" />
              Carrière
            </TabsTrigger>
            <TabsTrigger value="media" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Camera className="w-4 h-4 mr-2" />
              Médias
            </TabsTrigger>
            <TabsTrigger value="achievements" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Award className="w-4 h-4 mr-2" />
              Trophées
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="fm-card">
              <CardHeader>
                <CardTitle className="font-bebas text-3xl text-white">Informations personnelles</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...profileForm}>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={profileForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nom complet</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Ex: Kylian Mbappé"
                                className="fm-input"
                                data-testid="input-name"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="position"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Position</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="fm-input" data-testid="select-position">
                                  <SelectValue placeholder="Sélectionnez votre position" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="GK">Gardien</SelectItem>
                                <SelectItem value="DC">Défenseur Central</SelectItem>
                                <SelectItem value="DG">Défenseur Gauche</SelectItem>
                                <SelectItem value="DD">Défenseur Droit</SelectItem>
                                <SelectItem value="MDC">Milieu Défensif</SelectItem>
                                <SelectItem value="MC">Milieu Central</SelectItem>
                                <SelectItem value="MO">Milieu Offensif</SelectItem>
                                <SelectItem value="AG">Ailier Gauche</SelectItem>
                                <SelectItem value="AD">Ailier Droit</SelectItem>
                                <SelectItem value="BU">Buteur</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="currentClub"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Club actuel</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Ex: Paris Saint-Germain"
                                className="fm-input"
                                data-testid="input-current-club"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="nationality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nationalité</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Ex: Français"
                                className="fm-input"
                                data-testid="input-nationality"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={profileForm.control}
                      name="biography"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Biographie</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field} 
                              placeholder="Parlez-nous de votre parcours..."
                              className="fm-input min-h-[120px]"
                              data-testid="textarea-biography"
                            />
                          </FormControl>
                          <FormDescription>
                            {field.value?.length || 0}/1000 caractères
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="button"
                      onClick={saveProfile}
                      className="fm-button fm-button-green"
                      data-testid="button-save-profile"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Sauvegarder le profil
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats">
            <Card className="fm-card">
              <CardHeader>
                <CardTitle className="font-bebas text-3xl text-white">Statistiques Football Manager</CardTitle>
                <CardDescription>
                  Répartissez 150 points maximum par catégorie
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                {/* Technical Stats */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bebas text-fm-gold">
                      TECHNIQUE
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-white">
                        {calculateCategoryTotal(technicalStats)}
                      </span>
                      <span className="text-gray-400">/150 points</span>
                      {calculateCategoryTotal(technicalStats) > 150 && (
                        <AlertCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(technicalStats).map(([stat, value]) => (
                      <StatSlider
                        key={stat}
                        label={stat.replace(/([A-Z])/g, ' $1').trim()}
                        value={value}
                        onChange={(v) => updateStat('technical', stat, v)}
                      />
                    ))}
                  </div>
                </div>

                {/* Mental Stats */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bebas text-fm-gold">
                      MENTAL
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-white">
                        {calculateCategoryTotal(mentalStats)}
                      </span>
                      <span className="text-gray-400">/150 points</span>
                      {calculateCategoryTotal(mentalStats) > 150 && (
                        <AlertCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(mentalStats).map(([stat, value]) => (
                      <StatSlider
                        key={stat}
                        label={stat.replace(/([A-Z])/g, ' $1').trim()}
                        value={value}
                        onChange={(v) => updateStat('mental', stat, v)}
                      />
                    ))}
                  </div>
                </div>

                {/* Physical Stats */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bebas text-fm-gold">
                      PHYSIQUE
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-white">
                        {calculateCategoryTotal(physicalStats)}
                      </span>
                      <span className="text-gray-400">/150 points</span>
                      {calculateCategoryTotal(physicalStats) > 150 && (
                        <AlertCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(physicalStats).map(([stat, value]) => (
                      <StatSlider
                        key={stat}
                        label={stat.replace(/([A-Z])/g, ' $1').trim()}
                        value={value}
                        onChange={(v) => updateStat('physical', stat, v)}
                      />
                    ))}
                  </div>
                </div>

                <Button 
                  type="button"
                  onClick={saveStats}
                  className="fm-button fm-button-green"
                  data-testid="button-save-stats"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Sauvegarder les statistiques
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Career Tab */}
          <TabsContent value="career">
            <Card className="fm-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-bebas text-3xl text-white">Historique de carrière</CardTitle>
                <Button className="fm-button fm-button-gold" size="sm" data-testid="button-add-career">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter une saison
                </Button>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Aucune saison enregistrée</p>
                  <p className="text-sm text-gray-500">
                    Cliquez sur "Ajouter une saison" pour documenter votre parcours
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Media Tab */}
          <TabsContent value="media">
            <Card className="fm-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-bebas text-3xl text-white">Galerie média</CardTitle>
                <Button className="fm-button fm-button-gold" data-testid="button-add-media">
                  <Camera className="w-4 h-4 mr-2" />
                  Ajouter photo/vidéo
                </Button>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Camera className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Aucun média uploadé</p>
                  <p className="text-sm text-gray-500">
                    Ajoutez des photos et vidéos de vos meilleurs moments
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <Card className="fm-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-bebas text-3xl text-white">Trophées et récompenses</CardTitle>
                <Button className="fm-button fm-button-gold" size="sm" data-testid="button-add-achievement">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un trophée
                </Button>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Award className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Aucun trophée enregistré</p>
                  <p className="text-sm text-gray-500">
                    Ajoutez vos trophées et distinctions personnelles
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}