import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import PlayerCard from "@/components/PlayerCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Trophy, Users, Camera, TrendingUp } from "lucide-react";

export default function Rankings() {
  const { data: topPlayers, isLoading: isPlayersLoading } = useQuery({
    queryKey: ["/api/rankings/players"],
    retry: false,
  });

  const { data: topMedia, isLoading: isMediaLoading } = useQuery({
    queryKey: ["/api/rankings/media"],
    retry: false,
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto max-w-6xl px-4 py-8" data-testid="rankings-content">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-montserrat font-extrabold text-4xl md:text-5xl text-white mb-4">
            <span className="text-fm-gold">Classements</span> Communautaires
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Découvrez les meilleurs joueurs et contenus de la communauté Football Manager IRL
          </p>
        </div>

        <Tabs defaultValue="players" className="w-full" data-testid="tabs-rankings">
          <TabsList className="grid w-full grid-cols-2 bg-card border-border mb-8">
            <TabsTrigger 
              value="players" 
              className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark"
              data-testid="tab-players"
            >
              <Trophy className="w-4 h-4 mr-2" />
              Top Joueurs
            </TabsTrigger>
            <TabsTrigger 
              value="media" 
              className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark"
              data-testid="tab-media"
            >
              <Camera className="w-4 h-4 mr-2" />
              Top Médias
            </TabsTrigger>
          </TabsList>

          {/* Players Rankings */}
          <TabsContent value="players" className="mt-6">
            <Card className="bg-card border-border mb-6" data-testid="card-players-stats">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                  <div>
                    <TrendingUp className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">
                      {topPlayers?.length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Joueurs actifs</div>
                  </div>
                  <div>
                    <Users className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">
                      {topPlayers?.reduce((sum: number, player: any) => sum + (player.totalLikes || 0), 0) || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Total likes</div>
                  </div>
                  <div>
                    <Trophy className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">Elite</div>
                    <div className="text-sm text-muted-foreground">Niveau communauté</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {isPlayersLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="bg-card border-border animate-pulse" data-testid={`skeleton-player-${i}`}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-8 h-8 bg-muted rounded"></div>
                        <div className="w-12 h-12 bg-muted rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-muted rounded mb-2"></div>
                          <div className="h-3 bg-muted rounded w-2/3"></div>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <div className="h-6 bg-muted rounded w-16"></div>
                        <div className="h-6 bg-muted rounded w-16"></div>
                        <div className="h-8 bg-muted rounded w-20"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : topPlayers && topPlayers.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {topPlayers.map((player: any, index: number) => (
                  <PlayerCard
                    key={player.id}
                    player={player}
                    rank={index + 1}
                    data-testid={`player-card-${index}`}
                  />
                ))}
              </div>
            ) : (
              <Card className="bg-card border-border" data-testid="card-no-players">
                <CardContent className="text-center py-12">
                  <Trophy className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Aucun joueur trouvé</h3>
                  <p className="text-muted-foreground">
                    Soyez le premier à créer votre profil et apparaître dans les classements !
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Media Rankings */}
          <TabsContent value="media" className="mt-6">
            <Card className="bg-card border-border mb-6" data-testid="card-media-stats">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                  <div>
                    <Camera className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">
                      {topMedia?.length || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Médias partagés</div>
                  </div>
                  <div>
                    <TrendingUp className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">
                      {topMedia?.reduce((sum: number, media: any) => sum + (media.likes || 0), 0) || 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Total interactions</div>
                  </div>
                  <div>
                    <Users className="w-8 h-8 text-fm-gold mx-auto mb-2" />
                    <div className="text-2xl font-bold text-white">Actif</div>
                    <div className="text-sm text-muted-foreground">Engagement</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {isMediaLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="bg-card border-border overflow-hidden animate-pulse" data-testid={`skeleton-media-${i}`}>
                    <div className="aspect-video bg-muted"></div>
                    <CardContent className="p-4">
                      <div className="h-4 bg-muted rounded mb-2"></div>
                      <div className="flex justify-between">
                        <div className="h-3 bg-muted rounded w-20"></div>
                        <div className="h-3 bg-muted rounded w-16"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : topMedia && topMedia.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {topMedia.map((media: any, index: number) => (
                  <Card 
                    key={media.id} 
                    className="bg-card border-border hover:border-fm-gold/50 transition-all group overflow-hidden"
                    data-testid={`media-card-${index}`}
                  >
                    <div className="relative overflow-hidden aspect-video">
                      {media.filePath ? (
                        <img 
                          src={media.filePath} 
                          alt={media.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          data-testid={`img-media-${index}`}
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <Camera className="w-8 h-8 text-muted-foreground" />
                        </div>
                      )}
                      <div className="absolute top-2 left-2">
                        <Badge className={`${index < 3 ? 'bg-fm-gold text-fm-dark' : 'bg-black/70 text-white'}`} data-testid={`badge-rank-${index}`}>
                          #{index + 1}
                        </Badge>
                      </div>
                      {media.duration && (
                        <Badge className="absolute top-2 right-2 bg-black/70 text-white" data-testid={`badge-duration-${index}`}>
                          {media.duration}s
                        </Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2 truncate" data-testid={`text-media-title-${index}`}>
                        {media.title}
                      </h3>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground" data-testid={`text-media-date-${index}`}>
                          {new Date(media.createdAt).toLocaleDateString('fr-FR')}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-red-500">♥</span>
                          <span className="text-white font-semibold" data-testid={`text-media-likes-${index}`}>
                            {media.likes || 0}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-card border-border" data-testid="card-no-media">
                <CardContent className="text-center py-12">
                  <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">Aucun média trouvé</h3>
                  <p className="text-muted-foreground">
                    Soyez le premier à partager vos moments forts !
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
