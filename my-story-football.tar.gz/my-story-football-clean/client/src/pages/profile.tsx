import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { frenchClubs, internationalClubs } from "@/data/clubs";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { ObjectUploader } from "@/components/ObjectUploader";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  User, Calendar, MapPin, Trophy, Star, Save, Camera, Upload,
  Plus, Heart, Share2, BarChart3, Target, Activity, Shield,
  Clock, Award, Edit, X, Check, Trash2, Image, Video
} from "lucide-react";
import type { PlayerProfile, PlayerStats, CareerHistory, Achievement, MediaFile } from "@shared/schema";

// Schéma de validation du formulaire profil
const profileFormSchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères"),
  dateOfBirth: z.string().optional(),
  nationality: z.string().optional(),
  position: z.string().min(1, "La position est requise"),
  currentClub: z.string().optional(),
  biography: z.string().max(1000).optional(),
});

// Schéma pour les statistiques selon le schema DB
const statsFormSchema = z.object({
  // Technical stats
  dribbling: z.number().min(1).max(20),
  finishing: z.number().min(1).max(20),
  passing: z.number().min(1).max(20),
  crossing: z.number().min(1).max(20),
  shooting: z.number().min(1).max(20),
  
  // Physical stats
  pace: z.number().min(1).max(20),
  stamina: z.number().min(1).max(20),
  strength: z.number().min(1).max(20),
  jumping: z.number().min(1).max(20),
  
  // Mental stats
  vision: z.number().min(1).max(20),
  leadership: z.number().min(1).max(20),
  determination: z.number().min(1).max(20),
  composure: z.number().min(1).max(20),
  
  // Goalkeeping stats
  handling: z.number().min(1).max(20),
  reflexes: z.number().min(1).max(20),
});

export default function Profile() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth() as any;
  const [activeTab, setActiveTab] = useState("profile");
  const [isEditing, setIsEditing] = useState(false);
  const [showMediaDialog, setShowMediaDialog] = useState(false);
  const [mediaType, setMediaType] = useState<"image" | "video">("image");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Veuillez vous connecter pour accéder à votre profil",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch player profile
  const { data: playerProfile, isLoading: profileLoading } = useQuery<PlayerProfile>({
    queryKey: ["/api/player-profile"],
    enabled: isAuthenticated,
  });

  // Fetch player stats
  const { data: playerStats } = useQuery<PlayerStats>({
    queryKey: ["/api/player-stats"],
    enabled: isAuthenticated && !!playerProfile,
  });

  // Fetch career history
  const { data: careerHistory } = useQuery<CareerHistory[]>({
    queryKey: ["/api/career-history"],
    enabled: isAuthenticated && !!playerProfile,
  });

  // Fetch achievements
  const { data: achievements } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
    enabled: isAuthenticated && !!playerProfile,
  });

  // Fetch media files
  const { data: mediaFiles } = useQuery<MediaFile[]>({
    queryKey: ["/api/media-files"],
    enabled: isAuthenticated && !!playerProfile,
  });

  // Profile form
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: playerProfile?.name || "",
      dateOfBirth: playerProfile?.dateOfBirth ? new Date(playerProfile.dateOfBirth).toISOString().split('T')[0] : "",
      nationality: playerProfile?.nationality || "",
      position: playerProfile?.position || "",
      currentClub: playerProfile?.currentClub || "",
      biography: playerProfile?.biography || "",
    },
  });

  // Stats form
  const statsForm = useForm<z.infer<typeof statsFormSchema>>({
    resolver: zodResolver(statsFormSchema),
    defaultValues: {
      dribbling: playerStats?.dribbling || 10,
      finishing: playerStats?.finishing || 10,
      passing: playerStats?.passing || 10,
      crossing: playerStats?.crossing || 10,
      shooting: playerStats?.shooting || 10,
      pace: playerStats?.pace || 10,
      stamina: playerStats?.stamina || 10,
      strength: playerStats?.strength || 10,
      jumping: playerStats?.jumping || 10,
      vision: playerStats?.vision || 10,
      leadership: playerStats?.leadership || 10,
      determination: playerStats?.determination || 10,
      composure: playerStats?.composure || 10,
      handling: playerStats?.handling || 10,
      reflexes: playerStats?.reflexes || 10,
    },
  });

  // Save profile mutation
  const saveProfileMutation = useMutation({
    mutationFn: async (data: z.infer<typeof profileFormSchema>) => {
      return apiRequest("POST", "/api/player-profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/player-profile"] });
      toast({ title: "Profil sauvegardé avec succès!" });
      setIsEditing(false);
    },
    onError: () => {
      toast({ title: "Erreur lors de la sauvegarde", variant: "destructive" });
    },
  });

  // Save stats mutation
  const saveStatsMutation = useMutation({
    mutationFn: async (data: z.infer<typeof statsFormSchema>) => {
      return apiRequest("POST", "/api/player-stats", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/player-stats"] });
      toast({ title: "Statistiques sauvegardées!" });
    },
    onError: () => {
      toast({ title: "Erreur lors de la sauvegarde", variant: "destructive" });
    },
  });

  // Upload media mutation
  const uploadMediaMutation = useMutation({
    mutationFn: async (data: { filePath: string; fileType: string; title: string }) => {
      return apiRequest("POST", "/api/media-files", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media-files"] });
      toast({ title: "Média ajouté avec succès!" });
      setShowMediaDialog(false);
    },
    onError: () => {
      toast({ title: "Erreur lors de l'upload", variant: "destructive" });
    },
  });

  // Like media mutation
  const likeMediaMutation = useMutation({
    mutationFn: async (mediaId: string) => {
      return apiRequest("POST", `/api/media-files/${mediaId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media-files"] });
    },
  });

  // Group stats by category
  const technicalStats = ['dribbling', 'finishing', 'passing', 'crossing', 'shooting'];
  const physicalStats = ['pace', 'stamina', 'strength', 'jumping'];
  const mentalStats = ['vision', 'leadership', 'determination', 'composure'];
  const goalkeepingStats = ['handling', 'reflexes'];
  
  // Calculate total for a stat group
  const calculateGroupTotal = (statNames: string[]) => {
    return statNames.reduce((sum, stat) => sum + (statsForm.watch(stat as any) || 0), 0);
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const shareProfile = () => {
    const profileUrl = `${window.location.origin}/player/${playerProfile?.id || 'new'}`;
    navigator.clipboard.writeText(profileUrl);
    toast({ 
      title: "Lien copié!", 
      description: "Le lien de votre profil a été copié dans le presse-papier" 
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-fm-dark via-gray-900 to-fm-dark">
      <Header />
      
      <div className="container mx-auto px-2 md:px-4 py-4 md:py-8">
        {/* Header Section - Mobile Optimized */}
        <div className="mb-6 md:mb-8">
          {/* Mobile Header */}
          <div className="md:hidden">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="font-bebas text-3xl text-white leading-tight mb-1">
                  MON<br/>
                  <span className="text-fm-gold">PROFIL</span><br/>
                  <span className="text-fm-gold">JOUEUR</span>
                </h1>
                <p className="text-gray-400 text-sm">Créez et gérez votre profil professionnel</p>
              </div>
              <Button
                onClick={shareProfile}
                className="bg-fm-gold/20 text-fm-gold border border-fm-gold/30 hover:bg-fm-gold/30 px-3 py-2 rounded-full text-xs font-semibold"
                data-testid="button-share-profile"
              >
                PARTAGER MON PROFIL
              </Button>
            </div>
          </div>
          
          {/* Desktop Header */}
          <div className="hidden md:flex justify-between items-center">
            <div>
              <h1 className="font-bebas text-5xl text-fm-gold mb-2">MON PROFIL JOUEUR</h1>
              <p className="text-gray-400">Créez et gérez votre profil professionnel</p>
            </div>
            <Button
              onClick={shareProfile}
              className="fm-button fm-button-gold"
              data-testid="button-share-profile"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Partager mon profil
            </Button>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 md:space-y-6">
          {/* Mobile Tab List */}
          <div className="md:hidden">
            <div className="bg-fm-card/50 backdrop-blur-sm rounded-xl p-1 grid grid-cols-5 gap-1">
              <button
                onClick={() => setActiveTab("profile")}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  activeTab === "profile" 
                    ? "bg-fm-gold text-fm-dark font-semibold" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <User className="w-4 h-4" />
                <span className="text-xs">Profil</span>
              </button>
              <button
                onClick={() => setActiveTab("stats")}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  activeTab === "stats" 
                    ? "bg-fm-gold text-fm-dark font-semibold" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span className="text-xs">Statistiques</span>
              </button>
              <button
                onClick={() => setActiveTab("career")}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  activeTab === "career" 
                    ? "bg-fm-gold text-fm-dark font-semibold" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Trophy className="w-4 h-4" />
                <span className="text-xs">Carrière</span>
              </button>
              <button
                onClick={() => setActiveTab("media")}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  activeTab === "media" 
                    ? "bg-fm-gold text-fm-dark font-semibold" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Camera className="w-4 h-4" />
                <span className="text-xs">Médias</span>
              </button>
              <button
                onClick={() => setActiveTab("achievements")}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  activeTab === "achievements" 
                    ? "bg-fm-gold text-fm-dark font-semibold" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Award className="w-4 h-4" />
                <span className="text-xs">Trophées</span>
              </button>
            </div>
          </div>
          
          {/* Desktop Tab List */}
          <TabsList className="hidden md:grid w-full grid-cols-5 bg-fm-card">
            <TabsTrigger value="profile" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <User className="w-4 h-4 mr-2" />
              Profil
            </TabsTrigger>
            <TabsTrigger value="stats" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <BarChart3 className="w-4 h-4 mr-2" />
              Statistiques
            </TabsTrigger>
            <TabsTrigger value="career" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Trophy className="w-4 h-4 mr-2" />
              Carrière
            </TabsTrigger>
            <TabsTrigger value="media" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Camera className="w-4 h-4 mr-2" />
              Médias
            </TabsTrigger>
            <TabsTrigger value="achievements" className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark">
              <Award className="w-4 h-4 mr-2" />
              Trophées
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="fm-card border-0 md:border">
              <CardHeader className="px-4 md:px-6">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="font-bebas text-2xl md:text-3xl text-white">Informations personnelles</CardTitle>
                    <CardDescription className="text-sm md:text-base">Modifiez directement vos informations et elles seront sauvegardées automatiquement</CardDescription>
                  </div>
                  <Button
                    size="sm"
                    className="bg-fm-gold text-fm-dark hover:bg-fm-gold/90 rounded-full w-8 h-8 md:w-10 md:h-10 p-0"
                    onClick={() => setIsEditing(!isEditing)}
                  >
                    <Plus className="w-4 h-4 md:w-5 md:h-5" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="px-4 md:px-6">
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit((data) => saveProfileMutation.mutate(data))} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={profileForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nom complet</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Votre nom complet"
                                className="fm-input"
                                data-testid="input-name"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="position"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Position</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="fm-input" data-testid="select-position">
                                  <SelectValue placeholder="Sélectionnez votre position" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="GK">Gardien</SelectItem>
                                <SelectItem value="DC">Défenseur Central</SelectItem>
                                <SelectItem value="DG">Défenseur Gauche</SelectItem>
                                <SelectItem value="DD">Défenseur Droit</SelectItem>
                                <SelectItem value="MDC">Milieu Défensif</SelectItem>
                                <SelectItem value="MC">Milieu Central</SelectItem>
                                <SelectItem value="MO">Milieu Offensif</SelectItem>
                                <SelectItem value="AG">Ailier Gauche</SelectItem>
                                <SelectItem value="AD">Ailier Droit</SelectItem>
                                <SelectItem value="BU">Buteur</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="dateOfBirth"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date de naissance</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="date"
                                className="fm-input"
                                data-testid="input-date-of-birth"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="nationality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nationalité</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Ex: Français"
                                className="fm-input"
                                data-testid="input-nationality"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="currentClub"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Club actuel</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger className="fm-input" data-testid="select-current-club">
                                  <SelectValue placeholder="Sélectionner un club" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-[rgb(30,41,59)] border-white/10 max-h-[300px] overflow-y-auto">
                                <SelectItem value="Sans club">Sans club</SelectItem>
                                {Object.entries(frenchClubs).map(([league, clubs]) => (
                                  <div key={league}>
                                    <div className="px-2 py-1 text-xs text-white/60 font-bold">{league}</div>
                                    {clubs.map((club, index) => (
                                      <SelectItem key={`french-${league}-${club}-${index}`} value={club}>{club}</SelectItem>
                                    ))}
                                  </div>
                                ))}
                                {Object.entries(internationalClubs).slice(0, 4).map(([league, clubs]) => (
                                  <div key={`int-${league}`}>
                                    <div className="px-2 py-1 text-xs text-white/60 font-bold">{league}</div>
                                    {clubs.map((club, index) => (
                                      <SelectItem key={`int-${league}-${club}-${index}`} value={club}>{club}</SelectItem>
                                    ))}
                                  </div>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />



                    </div>

                    <FormField
                      control={profileForm.control}
                      name="biography"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Biographie</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field}
                              placeholder="Parlez-nous de votre parcours..."
                              className="fm-input min-h-[120px]"
                              data-testid="textarea-biography"
                            />
                          </FormControl>
                          <FormDescription>
                            {field.value?.length || 0}/1000 caractères
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="fm-button fm-button-green"
                      disabled={saveProfileMutation.isPending}
                      data-testid="button-save-profile"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {saveProfileMutation.isPending ? "Sauvegarde..." : "Sauvegarder le profil"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats">
            <Card className="fm-card">
              <CardHeader>
                <CardTitle className="font-bebas text-3xl text-white">Statistiques FM</CardTitle>
                <CardDescription>
                  Répartissez 150 points par catégorie (Technical, Mental, Physique)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...statsForm}>
                  <form onSubmit={statsForm.handleSubmit((data) => saveStatsMutation.mutate(data))} className="space-y-6 md:space-y-8">
                    {/* Technical Stats */}
                    <div>
                      <h3 className="text-lg md:text-xl font-bebas text-fm-gold mb-3 md:mb-4">
                        TECHNIQUE - {calculateGroupTotal(technicalStats)}/100 points
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                        {technicalStats.map((stat) => (
                          <FormField
                            key={stat}
                            control={statsForm.control}
                            name={stat as any}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-xs md:text-sm capitalize text-white">
                                  {stat === 'dribbling' ? 'Dribble' :
                                   stat === 'finishing' ? 'Finition' :
                                   stat === 'passing' ? 'Passes' :
                                   stat === 'crossing' ? 'Centres' :
                                   stat === 'shooting' ? 'Tir' : stat}
                                </FormLabel>
                                <FormControl>
                                  <div className="flex items-center gap-2">
                                    <Slider
                                      min={1}
                                      max={20}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={([value]) => field.onChange(value)}
                                      className="flex-1"
                                    />
                                    <span className="text-xs md:text-sm font-bold w-6 md:w-8 text-center text-fm-gold">
                                      {field.value}
                                    </span>
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Physical Stats */}
                    <div>
                      <h3 className="text-lg md:text-xl font-bebas text-fm-gold mb-3 md:mb-4">
                        PHYSIQUE - {calculateGroupTotal(physicalStats)}/80 points
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                        {physicalStats.map((stat) => (
                          <FormField
                            key={stat}
                            control={statsForm.control}
                            name={stat as any}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-xs md:text-sm capitalize text-white">
                                  {stat === 'pace' ? 'Vitesse' :
                                   stat === 'stamina' ? 'Endurance' :
                                   stat === 'strength' ? 'Force' :
                                   stat === 'jumping' ? 'Saut' : stat}
                                </FormLabel>
                                <FormControl>
                                  <div className="flex items-center gap-2">
                                    <Slider
                                      min={1}
                                      max={20}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={([value]) => field.onChange(value)}
                                      className="flex-1"
                                    />
                                    <span className="text-xs md:text-sm font-bold w-6 md:w-8 text-center text-fm-gold">
                                      {field.value}
                                    </span>
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Mental Stats */}
                    <div>
                      <h3 className="text-lg md:text-xl font-bebas text-fm-gold mb-3 md:mb-4">
                        MENTAL - {calculateGroupTotal(mentalStats)}/80 points
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                        {mentalStats.map((stat) => (
                          <FormField
                            key={stat}
                            control={statsForm.control}
                            name={stat as any}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-xs md:text-sm capitalize text-white">
                                  {stat === 'vision' ? 'Vision' :
                                   stat === 'leadership' ? 'Leadership' :
                                   stat === 'determination' ? 'Détermination' :
                                   stat === 'composure' ? 'Sang-froid' : stat}
                                </FormLabel>
                                <FormControl>
                                  <div className="flex items-center gap-2">
                                    <Slider
                                      min={1}
                                      max={20}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={([value]) => field.onChange(value)}
                                      className="flex-1"
                                    />
                                    <span className="text-xs md:text-sm font-bold w-6 md:w-8 text-center text-fm-gold">
                                      {field.value}
                                    </span>
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Goalkeeping Stats */}
                    <div>
                      <h3 className="text-lg md:text-xl font-bebas text-fm-gold mb-3 md:mb-4">
                        GARDIEN - {calculateGroupTotal(goalkeepingStats)}/40 points
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                        {goalkeepingStats.map((stat) => (
                          <FormField
                            key={stat}
                            control={statsForm.control}
                            name={stat as any}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-xs md:text-sm capitalize text-white">
                                  {stat === 'handling' ? 'Prise de balle' :
                                   stat === 'reflexes' ? 'Réflexes' : stat}
                                </FormLabel>
                                <FormControl>
                                  <div className="flex items-center gap-2">
                                    <Slider
                                      min={1}
                                      max={20}
                                      step={1}
                                      value={[field.value]}
                                      onValueChange={([value]) => field.onChange(value)}
                                      className="flex-1"
                                    />
                                    <span className="text-xs md:text-sm font-bold w-6 md:w-8 text-center text-fm-gold">
                                      {field.value}
                                    </span>
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="flex justify-end pt-4">
                      <Button 
                        type="submit" 
                        className="fm-button fm-button-gold text-sm md:text-base px-6 py-2 md:px-8 md:py-3"
                        disabled={saveStatsMutation.isPending}
                        data-testid="button-save-stats"
                      >
                        <Save className="w-3 h-3 md:w-4 md:h-4 mr-2" />
                        {saveStatsMutation.isPending ? "Sauvegarde..." : "Sauvegarder"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Career Tab */}
          <TabsContent value="career">
            <Card className="fm-card border-0 md:border">
              <CardHeader className="px-4 md:px-6">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="font-bebas text-2xl md:text-3xl text-white">Historique de carrière</CardTitle>
                  </div>
                  <Button className="bg-fm-gold text-fm-dark hover:bg-fm-gold/90 rounded-full w-8 h-8 md:w-10 md:h-10 p-0" size="sm" data-testid="button-add-career">
                    <Plus className="w-4 h-4 md:w-5 md:h-5" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="px-4 md:px-6">
                {(!careerHistory || careerHistory.length === 0) ? (
                  <div className="text-center py-8 md:py-12">
                    <Trophy className="w-12 h-12 md:w-16 md:h-16 text-gray-600 mx-auto mb-3 md:mb-4" />
                    <p className="text-gray-400 mb-3 md:mb-4 text-sm md:text-base">Aucune saison enregistrée</p>
                    <p className="text-xs md:text-sm text-gray-500">
                      Ajoutez vos saisons pour documenter votre parcours
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 md:space-y-4">
                    {careerHistory.map((season, index) => (
                      <div key={index} className="bg-gray-800/50 rounded-lg p-3 md:p-4 border border-gray-700">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-bold text-white text-sm md:text-base">{season.season}</h4>
                            <p className="text-fm-gold text-sm md:text-base">{season.club}</p>
                            <div className="flex gap-3 md:gap-4 mt-2 text-xs md:text-sm text-gray-400">
                              <span>{season.matches || 0} matchs</span>
                              <span>{season.goals || 0} buts</span>
                              <span>{season.assists || 0} passes</span>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-500 h-8 w-8 p-0">
                            <Trash2 className="w-3 h-3 md:w-4 md:h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Media Tab */}
          <TabsContent value="media">
            <Card className="fm-card border-0 md:border">
              <CardHeader className="px-4 md:px-6">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="font-bebas text-2xl md:text-3xl text-white">Galerie média</CardTitle>
                  </div>
                  <Dialog open={showMediaDialog} onOpenChange={setShowMediaDialog}>
                    <DialogTrigger asChild>
                      <Button className="bg-fm-gold text-fm-dark hover:bg-fm-gold/90 rounded-full w-8 h-8 md:w-10 md:h-10 p-0" data-testid="button-add-media">
                        <Plus className="w-4 h-4 md:w-5 md:h-5" />
                      </Button>
                    </DialogTrigger>
                  <DialogContent className="bg-fm-card border-fm-gold/30">
                    <DialogHeader>
                      <DialogTitle>Ajouter un média</DialogTitle>
                      <DialogDescription>
                        Téléchargez une photo ou vidéo de vos performances
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Select value={mediaType} onValueChange={(v: any) => setMediaType(v)}>
                        <SelectTrigger className="fm-input">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="image">
                            <div className="flex items-center gap-2">
                              <Image className="w-4 h-4" />
                              Photo
                            </div>
                          </SelectItem>
                          <SelectItem value="video">
                            <div className="flex items-center gap-2">
                              <Video className="w-4 h-4" />
                              Vidéo
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <ObjectUploader
                        maxNumberOfFiles={1}
                        maxFileSize={mediaType === "video" ? 104857600 : 10485760}
                        onGetUploadParameters={async () => {
                          const response = await apiRequest("POST", "/api/objects/upload");
                          const data = await response.json();
                          return {
                            method: "PUT" as const,
                            url: data.uploadURL,
                          };
                        }}
                        onComplete={async (result) => {
                          const uploadedFile = result.successful?.[0];
                          if (uploadedFile) {
                            await uploadMediaMutation.mutateAsync({
                              filePath: uploadedFile.uploadURL || "",
                              fileType: mediaType,
                              title: uploadedFile.name || "Media",
                            });
                          }
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <Camera className="w-5 h-5" />
                          Sélectionner un fichier
                        </div>
                      </ObjectUploader>
                    </div>
                  </DialogContent>
                </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {(!mediaFiles || mediaFiles.length === 0) ? (
                  <div className="text-center py-12">
                    <Camera className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">Aucun média uploadé</p>
                    <p className="text-sm text-gray-500">
                      Ajoutez des photos et vidéos pour enrichir votre profil
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {mediaFiles.map((media) => (
                      <div key={media.id} className="relative group">
                        <div className="aspect-square bg-gray-800 rounded-lg overflow-hidden">
                          {media.fileType === "image" ? (
                            <img 
                              src={media.filePath} 
                              alt={media.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <video 
                              src={media.filePath}
                              className="w-full h-full object-cover"
                            />
                          )}
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Button
                              onClick={() => likeMediaMutation.mutate(media.id)}
                              variant="ghost"
                              size="sm"
                              className="text-white"
                              data-testid={`button-like-media-${media.id}`}
                            >
                              <Heart className="w-5 h-5 mr-2" />
                              {media.likes}
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-gray-400 mt-2 truncate">{media.title}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <Card className="fm-card border-0 md:border">
              <CardHeader className="px-4 md:px-6">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="font-bebas text-2xl md:text-3xl text-white">Trophées et récompenses</CardTitle>
                  </div>
                  <Button className="bg-fm-gold text-fm-dark hover:bg-fm-gold/90 rounded-full w-8 h-8 md:w-10 md:h-10 p-0" size="sm" data-testid="button-add-achievement">
                    <Plus className="w-4 h-4 md:w-5 md:h-5" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="px-4 md:px-6">
                {(!achievements || achievements.length === 0) ? (
                  <div className="text-center py-8 md:py-12">
                    <Award className="w-12 h-12 md:w-16 md:h-16 text-gray-600 mx-auto mb-3 md:mb-4" />
                    <p className="text-gray-400 mb-3 md:mb-4 text-sm md:text-base">Aucun trophée enregistré</p>
                    <p className="text-xs md:text-sm text-gray-500">
                      Ajoutez vos trophées et récompenses
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                    {achievements.map((achievement) => (
                      <div key={achievement.id} className="bg-gray-800/50 rounded-lg p-3 md:p-4 border border-gray-700 flex items-center gap-3 md:gap-4">
                        <Trophy className="w-8 h-8 md:w-10 md:h-10 text-fm-gold flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-white text-sm md:text-base truncate">{achievement.title}</h4>
                          <p className="text-xs md:text-sm text-gray-400">{achievement.year}</p>
                          {achievement.description && (
                            <p className="text-xs md:text-sm text-gray-500 mt-1 line-clamp-2">{achievement.description}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}