import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ContentPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">POLITIQUE DE CONTENU</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. NOTRE VISION DE LA COMMUNAUTÉ</h2>
              <p className="mb-4">
                My Story Football aspire à créer une communauté bienveillante et passionnée où chaque 
                membre peut partager son parcours footballistique, de l'amateur au professionnel. 
                Notre devise <strong>"De l'amateur au pro, Montre qui tu es"</strong> reflète notre 
                engagement à célébrer tous les niveaux de pratique.
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <p><strong>🏆 Nos valeurs :</strong> Respect, Fair-play, Passion, Partage, Excellence</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. CONTENU AUTORISÉ</h2>
              
              <h3 className="text-xl font-semibold mb-3 text-green-400">✅ Contenu encouragé</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Performances sportives :</strong> Vidéos de matchs, entraînements, techniques</li>
                <li><strong>Parcours inspirants :</strong> Témoignages, progression, défis surmontés</li>
                <li><strong>Conseils techniques :</strong> Astuces d'entraînement, tactiques, préparation</li>
                <li><strong>Actualités clubs :</strong> Résultats, transferts, événements</li>
                <li><strong>Statistiques véridiques :</strong> Stats personnelles authentiques</li>
                <li><strong>Photos de terrain :</strong> Matchs, équipes, installations</li>
                <li><strong>Moments de convivialité :</strong> Célébrations, esprit d'équipe</li>
                <li><strong>Formation et développement :</strong> Stages, formations, certifications</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3 text-blue-400">ℹ️ Contenu acceptable avec modération</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Débats sportifs :</strong> Discussions respectueuses sur le football</li>
                <li><strong>Critiques constructives :</strong> Analyses d'arbitrage, de performances</li>
                <li><strong>Promotion modérée :</strong> Clubs, écoles de foot (non commercial)</li>
                <li><strong>Recherche de partenaires :</strong> Coéquipiers, clubs, entraîneurs</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. CONTENU INTERDIT</h2>
              
              <h3 className="text-xl font-semibold mb-3 text-red-400">❌ Strictement prohibé</h3>
              
              <div className="space-y-4">
                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Violence et harcèlement</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Menaces physiques ou verbales</li>
                    <li>Harcèlement envers joueurs, arbitres, supporters</li>
                    <li>Incitation à la violence sur ou hors terrain</li>
                    <li>Intimidation ou chantage</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Discrimination et haine</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Propos racistes, sexistes, homophobes</li>
                    <li>Discrimination par origine, religion, orientation</li>
                    <li>Symboles ou discours haineux</li>
                    <li>Stéréotypes dégradants</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Contenu inapproprié</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Nudité ou contenu sexuellement explicite</li>
                    <li>Violence graphique hors contexte sportif</li>
                    <li>Drogues, alcool en excès</li>
                    <li>Langage excessivement vulgaire</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Fraude et tromperie</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Fausses statistiques ou faux palmarès</li>
                    <li>Usurpation d'identité de joueurs pros</li>
                    <li>Faux témoignages ou recommandations</li>
                    <li>Manipulation de médias (deepfakes)</li>
                  </ul>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">🚫 Activités illégales</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Paris sportifs non autorisés</li>
                    <li>Vente de substances interdites</li>
                    <li>Matchs truqués ou corruption</li>
                    <li>Violation des droits d'image</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. RÈGLES SPÉCIFIQUES PAR TYPE DE PROFIL</h2>
              
              <h3 className="text-xl font-semibold mb-3">⚽ Profils Joueurs</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Statistiques authentiques :</strong> Seules les vraies stats personnelles</li>
                <li><strong>Photos de performances :</strong> Matchs, entraînements, cérémonies</li>
                <li><strong>Parcours véridique :</strong> Clubs réellement fréquentés</li>
                <li><strong>Respect des coéquipiers :</strong> Pas de dénigrement d'équipiers</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">👨‍🏫 Profils Entraîneurs</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Qualifications réelles :</strong> Diplômes et certifications vérifiables</li>
                <li><strong>Méthodes pédagogiques :</strong> Partage d'expertise constructif</li>
                <li><strong>Éthique professionnelle :</strong> Respect des joueurs et parents</li>
                <li><strong>Formations continues :</strong> Mise à jour des compétences</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">🏟️ Profils Clubs</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Informations officielles :</strong> Données vérifiables du club</li>
                <li><strong>Infrastructures réelles :</strong> Photos authentiques des installations</li>
                <li><strong>Recrutement transparent :</strong> Conditions d'adhésion claires</li>
                <li><strong>Résultats honnêtes :</strong> Classements et performances réels</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. SIGNALEMENT ET MODÉRATION</h2>
              
              <h3 className="text-xl font-semibold mb-3">🚨 Comment signaler</h3>
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <ol className="list-decimal list-inside space-y-2">
                  <li>Cliquez sur le bouton "Signaler" sur le contenu concerné</li>
                  <li>Sélectionnez la catégorie de violation</li>
                  <li>Ajoutez une description détaillée (optionnel)</li>
                  <li>Confirmez votre signalement</li>
                </ol>
                <p className="mt-4 text-sm text-white/60">
                  <strong>⏱️ Délai de traitement :</strong> 24-48h selon la gravité
                </p>
              </div>

              <h3 className="text-xl font-semibold mb-3">⚖️ Processus de modération</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Évaluation :</strong> Analyse du contenu signalé par notre équipe</li>
                <li><strong>Décision :</strong> Application des sanctions appropriées</li>
                <li><strong>Notification :</strong> Information à l'auteur et au signaleur</li>
                <li><strong>Recours :</strong> Possibilité de contester la décision</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. SANCTIONS</h2>
              
              <div className="space-y-4">
                <div className="bg-yellow-900/20 p-4 rounded-lg border border-yellow-500/30">
                  <h4 className="font-semibold mb-2">⚠️ Avertissement</h4>
                  <p className="text-sm">Première violation mineure • Notification + rappel des règles</p>
                </div>

                <div className="bg-orange-900/20 p-4 rounded-lg border border-orange-500/30">
                  <h4 className="font-semibold mb-2">🔇 Restriction temporaire</h4>
                  <p className="text-sm">Violation répétée • Limitation des publications (7-30 jours)</p>
                </div>

                <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-2">⏸️ Suspension</h4>
                  <p className="text-sm">Violation grave • Compte suspendu (1-6 mois)</p>
                </div>

                <div className="bg-black/40 p-4 rounded-lg border border-gray-500/30">
                  <h4 className="font-semibold mb-2">🚫 Exclusion définitive</h4>
                  <p className="text-sm">Violation très grave ou récidive • Suppression permanente</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. DROITS D'AUTEUR ET PROPRIÉTÉ</h2>
              <p className="mb-4">
                Respectez la propriété intellectuelle d'autrui :
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Photos :</strong> Utilisez vos propres images ou avec autorisation</li>
                <li><strong>Vidéos :</strong> Respect des droits de diffusion</li>
                <li><strong>Musique :</strong> Pas de contenu sous copyright sans licence</li>
                <li><strong>Logos et marques :</strong> Usage non commercial uniquement</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. PROTECTION DES MINEURS</h2>
              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <h4 className="font-semibold mb-2">👶 Règles spéciales pour les -18 ans</h4>
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li>Autorisation parentale obligatoire pour l'inscription</li>
                  <li>Modération renforcée des interactions</li>
                  <li>Interdiction de partage d'informations personnelles</li>
                  <li>Signalement prioritaire des contenus inappropriés</li>
                  <li>Pas de contact direct avec des adultes non encadrants</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. RECOURS ET CONTESTATION</h2>
              <p className="mb-4">
                Si vous pensez qu'une sanction est injustifiée :
              </p>
              <div className="bg-white/5 p-4 rounded-lg">
                <ol className="list-decimal list-inside space-y-2">
                  <li>Contactez contact@mystoryfootball.com</li>
                  <li>Objet : "Recours - [Votre nom d'utilisateur]"</li>
                  <li>Expliquez votre situation avec preuves</li>
                  <li>Réponse sous 7 jours ouvrés</li>
                </ol>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. ÉVOLUTION DE CETTE POLITIQUE</h2>
              <p>
                Cette politique peut évoluer pour s'adapter aux nouveaux défis de la communauté. 
                Les modifications importantes seront annoncées 30 jours à l'avance et feront 
                l'objet d'une notification dans l'application.
              </p>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-white/40 mt-2">
                "De l'amateur au pro, Montre qui tu es" - Ensemble, construisons une communauté football exemplaire ! ⚽
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}