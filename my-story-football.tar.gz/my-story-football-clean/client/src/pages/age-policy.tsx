import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AgePolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-blue-800">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
          <h1 className="font-bebas text-4xl text-white">PROTECTION DES MINEURS</h1>
        </div>

        {/* Content */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 space-y-8">
          <div className="text-white/90 leading-relaxed space-y-6">
            
            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">1. ENGAGEMENT DE PROTECTION</h2>
              <p className="mb-4">
                <strong>My Story Football</strong> s'engage fermement à protéger les jeunes footballeurs 
                et footballeuses qui utilisent notre plateforme. La sécurité des mineurs est notre priorité absolue, 
                conformément aux réglementations en vigueur et aux meilleures pratiques du secteur.
              </p>
              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <p><strong>👶 Âge minimum :</strong> 13 ans révolus</p>
                <p><strong>👨‍👩‍👧‍👦 Accord parental :</strong> Obligatoire pour les 13-17 ans</p>
                <p><strong>🛡️ Modération renforcée :</strong> Surveillance 24h/7j des comptes mineurs</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">2. CONDITIONS D'INSCRIPTION POUR MINEURS</h2>
              
              <h3 className="text-xl font-semibold mb-3">📝 Procédure d'inscription (13-17 ans)</h3>
              <ol className="list-decimal list-inside space-y-3 mb-4">
                <li>
                  <strong>Vérification de l'âge :</strong>
                  <p className="text-sm text-white/70 mt-1">Saisie obligatoire de la date de naissance vérifiable</p>
                </li>
                <li>
                  <strong>Autorisation parentale :</strong>
                  <p className="text-sm text-white/70 mt-1">Email envoyé automatiquement au représentant légal</p>
                </li>
                <li>
                  <strong>Validation parentale :</strong>
                  <p className="text-sm text-white/70 mt-1">Clic de confirmation requis dans les 48h</p>
                </li>
                <li>
                  <strong>Paramètres de sécurité :</strong>
                  <p className="text-sm text-white/70 mt-1">Configuration automatique en mode "protection renforcée"</p>
                </li>
              </ol>

              <h3 className="text-xl font-semibold mb-3">🚫 Accès refusé (-13 ans)</h3>
              <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30">
                <p className="text-sm">
                  Conformément au RGPD et à la loi française, l'inscription est strictement interdite 
                  aux enfants de moins de 13 ans. Toute tentative d'inscription avec une fausse date 
                  de naissance entraîne la suppression immédiate du compte.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">3. FONCTIONNALITÉS ADAPTÉES AUX MINEURS</h2>
              
              <h3 className="text-xl font-semibold mb-3 text-green-400">✅ Fonctionnalités disponibles</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Profil personnel :</strong> Création et gestion de leur profil football</li>
                <li><strong>Statistiques sportives :</strong> Enregistrement de leurs performances</li>
                <li><strong>Galerie limitée :</strong> Photos de matches et entraînements (modérées)</li>
                <li><strong>Parcours sportif :</strong> Documentation de leur évolution</li>
                <li><strong>Consultation publique :</strong> Visualisation des profils publics d'autres joueurs</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3 text-red-400">❌ Fonctionnalités restreintes</h3>
              <div className="space-y-3">
                <div className="bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-1">🚫 Messagerie privée</h4>
                  <p className="text-sm">Aucun contact direct avec d'autres utilisateurs hors supervision</p>
                </div>
                <div className="bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-1">🚫 Données personnelles</h4>
                  <p className="text-sm">Interdiction de partager numéro, adresse, nom d'établissement</p>
                </div>
                <div className="bg-red-900/20 p-3 rounded-lg border border-red-500/30">
                  <h4 className="font-semibold mb-1">🚫 Contenu non supervisé</h4>
                  <p className="text-sm">Tous les posts et médias sont pré-modérés avant publication</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">4. MODÉRATION RENFORCÉE</h2>
              
              <h3 className="text-xl font-semibold mb-3">🔍 Surveillance continue</h3>
              <div className="bg-white/5 p-4 rounded-lg mb-4">
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li><strong>IA de détection :</strong> Analyse automatique de tous les contenus</li>
                  <li><strong>Modération humaine :</strong> Équipe dédiée à la protection des mineurs</li>
                  <li><strong>Signalements prioritaires :</strong> Traitement immédiat (1h maximum)</li>
                  <li><strong>Contrôles aléatoires :</strong> Vérification régulière des interactions</li>
                  <li><strong>Alertes automatiques :</strong> Notification immédiate en cas de risque</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-3">⚠️ Détection d'incidents</h3>
              <p className="mb-4">Notre système détecte et bloque automatiquement :</p>
              <ul className="list-disc list-inside space-y-2">
                <li>Demandes d'informations personnelles</li>
                <li>Propositions de rencontres hors cadre sportif</li>
                <li>Langages inappropriés ou suggestifs</li>
                <li>Tentatives de contournement des restrictions</li>
                <li>Contenus à caractère sexuel ou violent</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">5. DROITS DES PARENTS/TUTEURS</h2>
              
              <h3 className="text-xl font-semibold mb-3">👨‍👩‍👧‍👦 Contrôle parental</h3>
              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30 mb-4">
                <h4 className="font-semibold mb-2">🎛️ Tableau de bord parental</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Accès complet au profil de leur enfant</li>
                  <li>Historique de toutes les activités</li>
                  <li>Paramètres de confidentialité modifiables</li>
                  <li>Notifications en temps réel des interactions</li>
                  <li>Possibilité de suspension temporaire du compte</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-3">🔒 Droits RGPD spécifiques</h3>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Consentement éclairé :</strong> Information complète avant autorisation</li>
                <li><strong>Droit d'accès :</strong> Consultation de toutes les données collectées</li>
                <li><strong>Droit de rectification :</strong> Modification des informations inexactes</li>
                <li><strong>Droit à l'effacement :</strong> Suppression définitive du compte</li>
                <li><strong>Droit d'opposition :</strong> Refus du traitement à tout moment</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">6. GESTION DES SIGNALEMENTS</h2>
              
              <h3 className="text-xl font-semibold mb-3">🚨 Signalement d'urgence</h3>
              <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30 mb-4">
                <h4 className="font-semibold mb-2">☎️ Contact d'urgence 24h/24</h4>
                <p className="text-sm mb-2">
                  En cas de danger immédiat pour un mineur :
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li><strong>Email prioritaire :</strong> urgence@mystoryfootball.com</li>
                  <li><strong>Objet :</strong> "URGENCE MINEUR - [Description]"</li>
                  <li><strong>Délai de réponse :</strong> 1 heure maximum</li>
                  <li><strong>Procédure :</strong> Suspension immédiate + enquête</li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-3">📋 Procédure standard</h3>
              <ol className="list-decimal list-inside space-y-2">
                <li>Réception et accusé de réception immédiat</li>
                <li>Évaluation par l'équipe de protection des mineurs</li>
                <li>Mesures conservatoires si nécessaire (suspension)</li>
                <li>Enquête approfondie (24-48h)</li>
                <li>Décision et sanctions appropriées</li>
                <li>Information aux parents et aux autorités si requis</li>
              </ol>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">7. COLLABORATION AVEC LES AUTORITÉS</h2>
              <p className="mb-4">
                My Story Football collabore étroitement avec les autorités compétentes :
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">🏛️ Autorités françaises</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>CNIL (Protection des données)</li>
                    <li>Brigades spécialisées (cybercriminalité)</li>
                    <li>Procureurs (signalements obligatoires)</li>
                  </ul>
                </div>
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">⚽ Instances sportives</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>FFF (Fédération Française de Football)</li>
                    <li>Ligues régionales</li>
                    <li>Comités départementaux</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">8. FORMATION ET SENSIBILISATION</h2>
              
              <h3 className="text-xl font-semibold mb-3">👥 Équipe My Story Football</h3>
              <ul className="list-disc list-inside space-y-2 mb-4">
                <li><strong>Formation spécialisée :</strong> Protection de l'enfance et cybersécurité</li>
                <li><strong>Mise à jour continue :</strong> Évolution des réglementations</li>
                <li><strong>Certification :</strong> Agrément protection des mineurs</li>
                <li><strong>Supervision externe :</strong> Audit annuel par organisme indépendant</li>
              </ul>

              <h3 className="text-xl font-semibold mb-3">📚 Ressources éducatives</h3>
              <p className="mb-4">Nous proposons des guides pour :</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Parents :</strong> Surveillance et accompagnement numérique</li>
                <li><strong>Jeunes :</strong> Bonnes pratiques et signalement</li>
                <li><strong>Clubs :</strong> Intégration sécurisée des réseaux sociaux</li>
                <li><strong>Éducateurs :</strong> Détection des comportements à risque</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">9. TRANSITION VERS LA MAJORITÉ</h2>
              <div className="bg-green-900/20 p-4 rounded-lg border border-green-500/30">
                <h4 className="font-semibold mb-2">🎂 À 18 ans révolus</h4>
                <ul className="list-disc list-inside space-y-2 text-sm">
                  <li>Notification automatique de changement de statut</li>
                  <li>Levée progressive des restrictions (avec confirmation)</li>
                  <li>Nouveau consentement requis pour le traitement des données</li>
                  <li>Accès complet aux fonctionnalités adultes</li>
                  <li>Maintien possible des paramètres de protection sur demande</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-fm-gold mb-4">10. CONTACT SPÉCIALISÉ</h2>
              <div className="bg-white/5 p-6 rounded-lg">
                <h4 className="font-semibold mb-4">👶 Service Protection des Mineurs</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p><strong>Email :</strong> protection-mineurs@mystoryfootball.com</p>
                    <p><strong>Urgences :</strong> urgence@mystoryfootball.com</p>
                  </div>
                  <div>
                    <p><strong>Disponibilité :</strong> 24h/7j</p>
                    <p><strong>Délai de réponse :</strong> 1h (urgences) / 24h (standard)</p>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-blue-900/30 rounded-lg">
                  <p className="text-sm">
                    <strong>📞 Numéro national :</strong> En cas de danger immédiat, appelez le 3020 
                    (numéro national d'information pour lutter contre le harcèlement à l'école) 
                    ou le 119 (Service National d'Information pour l'Enfance en Danger).
                  </p>
                </div>
              </div>
            </section>

            <footer className="text-center pt-8 border-t border-white/20">
              <p className="text-sm text-white/60">
                <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-white/40 mt-2">
                "De l'amateur au pro, Montre qui tu es" - En sécurité et avec bienveillance ! 🛡️⚽
              </p>
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}