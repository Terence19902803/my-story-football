import type { 
  User, 
  PlayerProfile, 
  PlayerStats, 
  CareerHistory, 
  Achievement, 
  MediaFile 
} from "@shared/schema";

// API Response types with proper typing
export interface PlayerProfileWithStats extends PlayerProfile {
  stats?: PlayerStats;
  careerHistory?: CareerHistory[];
  achievements?: Achievement[];
  mediaFiles?: MediaFile[];
}

export interface PlayerWithProfile extends User {
  playerProfile?: PlayerProfile;
}

export interface RankedPlayer extends PlayerProfile {
  totalLikes: number;
  user?: {
    firstName?: string | null;
    lastName?: string | null;
  };
}

export interface MediaWithLikes extends MediaFile {
  likes: number;
}