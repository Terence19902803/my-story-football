import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { useState, useEffect } from "react";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Profile from "@/pages/profile";
import Rankings from "@/pages/rankings";
import Subscribe from "@/pages/subscribe";
import Legal from "@/pages/legal";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import CookiePolicy from "@/pages/cookie-policy";
import LegalNotice from "@/pages/legal-notice";
import ContentPolicy from "@/pages/content-policy";
import RefundPolicy from "@/pages/refund-policy";
import AgePolicy from "@/pages/age-policy";
import PlayerCV from "@/pages/player-cv";
import CoachCV from "@/pages/coach-cv";
import ClubCV from "@/pages/club-cv";
import ExplorePage from "@/pages/explore";
import SearchPlayers from "@/pages/search-players";
import SearchCoaches from "@/pages/search-coaches";
import SearchClubs from "@/pages/search-clubs";
import Messages from "@/pages/messages";
import MostViewedVideos from "@/pages/videos/most-viewed";
import TrendingVideos from "@/pages/videos/trending";
import TopProfiles from "@/pages/top/profiles";
import TopPhotos from "@/pages/top/photos";
import TopVideos from "@/pages/top/videos";
import ProfileTypeSelection from "@/pages/profile-type-selection";
import CreatePlayer from "@/pages/create-player";
import CreateCoach from "@/pages/create-coach";
import CreateClub from "@/pages/create-club";
import SplashScreen from "@/components/SplashScreen";
import MobileNavigation from "@/components/MobileNavigation";
import Footer from "@/components/Footer";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-fm-darker">
        <div className="animate-spin w-12 h-12 border-4 border-fm-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="fm-mobile-content">
      <Switch>
        {!isAuthenticated ? (
          <>
            <Route path="/" component={Landing} />
            <Route path="/player-cv" component={PlayerCV} />
            <Route path="/coach-cv" component={CoachCV} />
            <Route path="/club-cv" component={ClubCV} />
            <Route path="/profile-type-selection" component={ProfileTypeSelection} />
            <Route path="/create-player" component={CreatePlayer} />
            <Route path="/create-coach" component={CreateCoach} />
            <Route path="/create-club" component={CreateClub} />
            <Route path="/explore" component={ExplorePage} />
            <Route path="/search-players" component={SearchPlayers} />
            <Route path="/search-coaches" component={SearchCoaches} />
            <Route path="/search-clubs" component={SearchClubs} />
            <Route path="/messages" component={Messages} />
            <Route path="/videos/most-viewed" component={MostViewedVideos} />
            <Route path="/videos/trending" component={TrendingVideos} />
            <Route path="/top/profiles" component={TopProfiles} />
            <Route path="/top/photos" component={TopPhotos} />
            <Route path="/top/videos" component={TopVideos} />
            <Route path="/rankings" component={Rankings} />
            <Route path="/legal" component={Legal} />
            <Route path="/privacy" component={Privacy} />
            <Route path="/terms" component={Terms} />
            <Route path="/privacy-policy" component={PrivacyPolicy} />
            <Route path="/terms-of-service" component={TermsOfService} />
            <Route path="/cookie-policy" component={CookiePolicy} />
            <Route path="/legal-notice" component={LegalNotice} />
            <Route path="/content-policy" component={ContentPolicy} />
            <Route path="/refund-policy" component={RefundPolicy} />
            <Route path="/age-policy" component={AgePolicy} />
          </>
        ) : (
          <>
            {/* Check if user has selected a profile type */}
            {user && !user.profileType && (
              <Route path="/" component={ProfileTypeSelection} />
            )}
            {user && user.profileType && (
              <Route path="/" component={Home} />
            )}
            <Route path="/select-profile-type" component={ProfileTypeSelection} />
            <Route path="/create-player" component={CreatePlayer} />
            <Route path="/create-coach" component={CreateCoach} />
            <Route path="/create-club" component={CreateClub} />
            <Route path="/profile" component={Profile} />
            <Route path="/explore" component={ExplorePage} />
            <Route path="/search-players" component={SearchPlayers} />
            <Route path="/search-coaches" component={SearchCoaches} />
            <Route path="/search-clubs" component={SearchClubs} />
            <Route path="/messages" component={Messages} />
            <Route path="/videos/most-viewed" component={MostViewedVideos} />
            <Route path="/videos/trending" component={TrendingVideos} />
            <Route path="/top/profiles" component={TopProfiles} />
            <Route path="/top/photos" component={TopPhotos} />
            <Route path="/top/videos" component={TopVideos} />
            <Route path="/rankings" component={Rankings} />
            <Route path="/subscribe" component={Subscribe} />
            <Route path="/player-cv" component={PlayerCV} />
            <Route path="/coach-cv" component={CoachCV} />
            <Route path="/club-cv" component={ClubCV} />
            <Route path="/legal" component={Legal} />
            <Route path="/privacy" component={Privacy} />
            <Route path="/terms" component={Terms} />
            <Route path="/privacy-policy" component={PrivacyPolicy} />
            <Route path="/terms-of-service" component={TermsOfService} />
            <Route path="/cookie-policy" component={CookiePolicy} />
            <Route path="/legal-notice" component={LegalNotice} />
            <Route path="/content-policy" component={ContentPolicy} />
            <Route path="/refund-policy" component={RefundPolicy} />
            <Route path="/age-policy" component={AgePolicy} />
          </>
        )}
        <Route component={NotFound} />
      </Switch>
      
      {/* Navigation mobile pour tous les utilisateurs */}
      <MobileNavigation />
      
      {/* Footer avec toutes les politiques */}
      <Footer />
    </div>
  );
}

function App() {
  const [showSplash, setShowSplash] = useState(true);

  // Register Service Worker
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js')
        .then(() => console.log('📱 Service Worker enregistré'))
        .catch(err => console.log('❌ Service Worker erreur:', err));
    }
  }, []);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark min-h-screen min-h-dvh bg-fm-darker text-foreground overflow-hidden">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
