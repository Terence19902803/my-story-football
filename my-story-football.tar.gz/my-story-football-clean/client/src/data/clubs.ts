export const frenchClubs = {
  "Ligue 1": [
    "Paris Saint-Germain", "AS Monaco", "Olympique Lyonnais", "Olympique de Marseille",
    "RC Lens", "Stade Rennais", "LOSC Lille", "FC Nantes", "OGC Nice",
    "Stade de Reims", "RC Strasbourg", "Toulouse FC", "AJ Auxerre",
    "Montpellier HSC", "Stade Brestois", "Le Havre AC", "FC Metz", "Clermont Foot"
  ],
  "Ligue 2": [
    "FC Annecy", "SC Bastia", "Girondins de Bordeaux", "Stade Malherbe Caen",
    "USL Dunkerque", "Grenoble Foot", "EA Guingamp", "Amiens SC", "FC Lorient",
    "AC Ajaccio", "Paris FC", "Pau FC", "Quevilly-Rouen", "Rodez AF",
    "AS Saint-Étienne", "ESTAC Troyes", "Valenciennes FC", "Red Star FC"
  ],
  "National": [
    "US Avranches", "SO Cholet", "US Concarneau", "Dijon FCO", "FC Martigues",
    "US Orléans", "Red Star", "FC Sochaux", "FC Versailles", "AS Nancy Lorraine",
    "Châteauroux", "Le Mans FC", "Nîmes Olympique", "FC Villefranche",
    "US Boulogne", "FC Rouen", "Goal FC"
  ],
  "National 2": [
    "AS Beauvais", "AS Cannes", "FC Chambly", "US Créteil", "FC Fleury",
    "FC Sète", "Sporting Club Toulon", "AS Poissy", "FC Annecy", "Entente SSG",
    "AS Saint-Priest", "FC Mulhouse", "SR Colmar", "ASM Belfort",
    "US Raon-l'Étape", "FC Metz B", "RC Strasbourg B", "Haguenau"
  ],
  "National 3": [
    "FC Libourne", "Stade Montois", "AS Béziers", "Olympique Alès", "AS Furiani",
    "GFC Ajaccio", "US Colomiers", "Toulouse Rodéo", "AS Muret", "Blagnac FC",
    "Montpellier HSC B", "FC Nantes B", "Stade Rennais B", "AS Vitré",
    "Vannes OC", "FC Lorient B", "EA Guingamp B", "US Montagnarde"
  ],
  "Régional 1": [
    "AS Illzach", "FC Brunstatt", "AS Sundhoffen", "US Wittenheim", "SR Colmar B",
    "US Reims Sainte-Anne", "FC Saint-Louis", "AS Kingersheim", "FC Wittelsheim",
    "AS Strasbourg Robertsau", "FC Obernai", "FC Bischwiller", "AS Erstein",
    "FC Schweighouse", "AS Vauban", "AS Schiltigheim", "SC Sélestat"
  ],
  "District": [
    "AS Turckheim", "FC Bennwihr", "US Wintzenheim", "FC Houssen", "AS Herrlisheim",
    "FC Artzenheim", "US Sundhoffen", "FC Vogelgrun", "AS Andolsheim", "FC Fortschwihr",
    "AS Sainte-Croix", "FC Wihr", "AS Walbach", "FC Orbey", "AS Katzenthal",
    "FC Zimmerbach", "AS Sigolsheim", "FC Niedermorschwihr", "AS Eguisheim"
  ]
};

export const internationalClubs = {
  "Premier League": [
    "Manchester City", "Arsenal", "Liverpool", "Aston Villa", "Tottenham Hotspur",
    "Manchester United", "Newcastle United", "Chelsea", "Brighton & Hove Albion",
    "Bournemouth", "Fulham", "Wolverhampton Wanderers", "West Ham United",
    "Crystal Palace", "Everton", "Brentford", "Nottingham Forest", "Leicester City",
    "Ipswich Town", "Southampton"
  ],
  "Championship": [
    "Leeds United", "Leicester City", "Ipswich Town", "West Bromwich Albion",
    "Norwich City", "Hull City", "Middlesbrough", "Coventry City", "Preston North End",
    "Bristol City", "Millwall", "Swansea City", "Sheffield Wednesday", "Watford",
    "Sunderland", "Blackburn Rovers", "Oxford United", "Stoke City",
    "Derby County", "Luton Town", "Cardiff City", "Portsmouth", "QPR", "Burnley"
  ],
  "La Liga": [
    "Real Madrid", "FC Barcelona", "Atlético Madrid", "Athletic Bilbao", "Real Sociedad",
    "Real Betis", "Villarreal CF", "Valencia CF", "Girona FC", "Sevilla FC",
    "Rayo Vallecano", "CA Osasuna", "Getafe CF", "RCD Espanyol", "Deportivo Alavés",
    "Las Palmas", "Celta Vigo", "RCD Mallorca", "Cádiz CF", "Real Valladolid"
  ],
  "Segunda División": [
    "Eibar", "Burgos CF", "Racing Santander", "Sporting Gijón", "Levante UD",
    "Huesca", "Oviedo", "Zaragoza", "Elche CF", "Albacete", "Málaga CF",
    "Mirandés", "CD Tenerife", "Leganés", "Andorra FC", "Cartagena",
    "Racing Ferrol", "Amorebieta", "SD Ponferradina", "FC Andorra"
  ],
  "Serie A": [
    "Inter Milan", "AC Milan", "Juventus", "AS Roma", "SSC Napoli", "Atalanta",
    "Lazio", "Fiorentina", "Bologna", "Torino", "Udinese", "Genoa CFC",
    "Frosinone", "Monza", "Hellas Verona", "Empoli", "Cagliari", "US Salernitana",
    "US Sassuolo", "US Lecce"
  ],
  "Serie B": [
    "Parma", "Como", "Venezia FC", "US Cremonese", "Catanzaro", "Palermo",
    "Sampdoria", "Brescia", "Modena", "Reggiana", "Südtirol", "Cittadella",
    "Cosenza", "Pisa", "Spezia", "Ascoli", "Feralpisalò", "Ternana",
    "Bari", "SPAL"
  ],
  "Bundesliga": [
    "Bayer Leverkusen", "Bayern Munich", "VfB Stuttgart", "RB Leipzig", "Borussia Dortmund",
    "Eintracht Frankfurt", "SC Freiburg", "TSG Hoffenheim", "FC Augsburg", "Werder Bremen",
    "VfL Wolfsburg", "FC Heidenheim", "Borussia Mönchengladbach", "Union Berlin",
    "VfL Bochum", "1. FC Köln", "FSV Mainz 05", "SV Darmstadt 98"
  ],
  "2. Bundesliga": [
    "St. Pauli", "Holstein Kiel", "Hamburger SV", "Fortuna Düsseldorf", "SC Paderborn",
    "Hertha BSC", "Schalke 04", "Hannover 96", "Nürnberg", "Kaiserslautern",
    "Greuther Fürth", "Eintracht Braunschweig", "Karlsruher SC", "SV Elversberg",
    "SV Wehen Wiesbaden", "VfL Osnabrück", "Hansa Rostock", "Magdeburg"
  ],
  "Primeira Liga": [
    "Benfica", "Porto", "Sporting CP", "SC Braga", "Vitória SC", "Moreirense",
    "FC Arouca", "FC Famalicão", "Casa Pia", "Rio Ave", "Boavista", "Gil Vicente",
    "Estrela Amadora", "Portimonense", "Estoril", "Chaves", "Vizela", "Farense"
  ],
  "Eredivisie": [
    "PSV Eindhoven", "Feyenoord", "Ajax", "AZ Alkmaar", "FC Twente", "Sparta Rotterdam",
    "FC Utrecht", "Go Ahead Eagles", "Fortuna Sittard", "NEC Nijmegen", "SC Heerenveen",
    "RKC Waalwijk", "Excelsior Rotterdam", "PEC Zwolle", "Almere City", "FC Volendam",
    "Heracles Almelo", "Vitesse Arnhem"
  ],
  "Jupiler Pro League": [
    "Club Brugge", "Royal Antwerp", "Union Saint-Gilloise", "Anderlecht", "KAA Gent",
    "KRC Genk", "Standard Liège", "Cercle Brugge", "KV Mechelen", "OH Leuven",
    "Westerlo", "Sint-Truidense", "Charleroi", "KV Kortrijk", "RWDM", "KAS Eupen"
  ],
  "Super League Greece": [
    "PAOK", "AEK Athens", "Panathinaikos", "Olympiacos", "Aris", "OFI Crete",
    "Lamia", "Volos", "Asteras Tripolis", "Atromitos", "Panserraikos", "PAS Giannina",
    "Kifisia", "Panetolikos"
  ],
  "Süper Lig": [
    "Galatasaray", "Fenerbahçe", "Beşiktaş", "Trabzonspor", "İstanbul Başakşehir",
    "Konyaspor", "Adana Demirspor", "Fatih Karagümrük", "Kayserispor", "Sivasspor",
    "Alanyaspor", "Antalyaspor", "Rizespor", "Gaziantep", "Kasımpaşa", "Ankaragücü",
    "Hatayspor", "Samsunspor", "Pendikspor", "İstanbulspor"
  ],
  "Scottish Premiership": [
    "Celtic", "Rangers", "Hearts", "Kilmarnock", "St Mirren", "Aberdeen",
    "Hibernian", "Dundee", "Motherwell", "St Johnstone", "Ross County", "Livingston"
  ],
  "Liga Portugal 2": [
    "Nacional", "AVS", "Tondela", "Paços de Ferreira", "Académico Viseu", "CD Mafra",
    "Porto B", "Benfica B", "União de Leiria", "Penafiel", "CD Trofense", "Feirense",
    "Oliveirense", "Leixões", "CD Santa Clara", "Marítimo", "CF Os Belenenses"
  ]
};

export const allClubs = [
  ...Object.values(frenchClubs).flat(),
  ...Object.values(internationalClubs).flat()
].sort();