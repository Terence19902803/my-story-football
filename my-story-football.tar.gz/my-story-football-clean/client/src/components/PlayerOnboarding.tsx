import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  User, BarChart3, Trophy, MessageSquare, Brain, Target, Camera, Plus, Trash2
} from "lucide-react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { StatSlider } from "./StatSlider";

interface PlayerOnboardingProps {
  onComplete: () => void;
}

export default function PlayerOnboarding({ onComplete }: PlayerOnboardingProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basics");
  
  const [formData, setFormData] = useState({
    name: "",
    dateOfBirth: "",
    nationality: "",
    position: "",
    currentClub: "",
    biography: "",
    sportingProject: "",
    strengths: "",
    developmentAreas: ""
  });

  const [stats, setStats] = useState({
    // Technical stats
    dribbling: 10,
    finishing: 10,
    passing: 10,
    crossing: 10,
    shooting: 10,
    
    // Physical stats
    pace: 10,
    stamina: 10,
    strength: 10,
    jumping: 10,
    
    // Mental stats
    vision: 10,
    leadership: 10,
    determination: 10,
    composure: 10,
    
    // Goalkeeping stats
    handling: 10,
    reflexes: 10
  });

  const [achievements, setAchievements] = useState([
    { title: "", description: "", year: "", type: "trophy" }
  ]);

  const [mediaFiles, setMediaFiles] = useState([
    { title: "", description: "", type: "image" }
  ]);

  const addAchievement = () => {
    setAchievements([...achievements, { title: "", description: "", year: "", type: "trophy" }]);
  };

  const removeAchievement = (index: number) => {
    setAchievements(achievements.filter((_, i) => i !== index));
  };

  const updateAchievement = (index: number, field: string, value: string) => {
    const updated = achievements.map((achievement, i) => 
      i === index ? { ...achievement, [field]: value } : achievement
    );
    setAchievements(updated);
  };

  const addMediaFile = () => {
    setMediaFiles([...mediaFiles, { title: "", description: "", type: "image" }]);
  };

  const removeMediaFile = (index: number) => {
    setMediaFiles(mediaFiles.filter((_, i) => i !== index));
  };

  const updateMediaFile = (index: number, field: string, value: string) => {
    const updated = mediaFiles.map((media, i) => 
      i === index ? { ...media, [field]: value } : media
    );
    setMediaFiles(updated);
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir le nom",
        variant: "destructive"
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/player", {
        ...formData,
        dateOfBirth: formData.dateOfBirth ? new Date(formData.dateOfBirth) : null,
        stats,
        achievements: achievements.filter(a => a.title),
        mediaFiles: mediaFiles.filter(m => m.title)
      });

      toast({
        title: "Profil créé !",
        description: "Votre profil joueur a été créé avec succès",
      });
      
      onComplete();
      navigate("/profile");
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la création",
        variant: "destructive"
      });
    }
  };

  const isFormValid = formData.name;

  const technicalStats = [
    { key: 'dribbling', label: 'Dribble' },
    { key: 'finishing', label: 'Finition' },
    { key: 'passing', label: 'Passe' },
    { key: 'crossing', label: 'Centre' },
    { key: 'shooting', label: 'Tir' }
  ];

  const physicalStats = [
    { key: 'pace', label: 'Vitesse' },
    { key: 'stamina', label: 'Endurance' },
    { key: 'strength', label: 'Force' },
    { key: 'jumping', label: 'Détente' }
  ];

  const mentalStats = [
    { key: 'vision', label: 'Vision' },
    { key: 'leadership', label: 'Leadership' },
    { key: 'determination', label: 'Détermination' },
    { key: 'composure', label: 'Sang-froid' }
  ];

  return (
    <div className="min-h-screen bg-fm-darker p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-500 mb-2">Créer mon Profil Joueur</h1>
          <p className="text-white/70">Complétez les informations par catégories</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6 mb-8 gap-1">
            <TabsTrigger value="basics" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <User className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Infos</span>
            </TabsTrigger>
            <TabsTrigger value="technique" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <BarChart3 className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Technique</span>
            </TabsTrigger>
            <TabsTrigger value="mental" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Brain className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Mental</span>
            </TabsTrigger>
            <TabsTrigger value="physique" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Target className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Physique</span>
            </TabsTrigger>
            <TabsTrigger value="palmares" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Trophy className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Palmarès</span>
            </TabsTrigger>
            <TabsTrigger value="media" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Camera className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Média</span>
            </TabsTrigger>
          </TabsList>

          {/* Informations de base */}
          <TabsContent value="basics">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Informations de Base</CardTitle>
                <CardDescription className="text-white/60">
                  Informations personnelles et football
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white/60">Nom complet *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white"
                      placeholder="Votre nom complet"
                      data-testid="input-player-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dateOfBirth" className="text-white/60">Date de naissance</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white"
                      data-testid="input-player-birth"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nationality" className="text-white/60">Nationalité</Label>
                    <Input
                      id="nationality"
                      value={formData.nationality}
                      onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white"
                      placeholder="France"
                      data-testid="input-player-nationality"
                    />
                  </div>
                  <div>
                    <Label htmlFor="position" className="text-white/60">Poste</Label>
                    <Input
                      id="position"
                      value={formData.position}
                      onChange={(e) => setFormData({...formData, position: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white"
                      placeholder="Ex: Attaquant, Milieu..."
                      data-testid="input-player-position"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="currentClub" className="text-white/60">Club actuel</Label>
                  <Input
                    id="currentClub"
                    value={formData.currentClub}
                    onChange={(e) => setFormData({...formData, currentClub: e.target.value})}
                    className="bg-fm-dark border-green-500/20 text-white"
                    placeholder="Ex: PSG, Real Madrid, Sans club..."
                    data-testid="input-player-club"
                  />
                </div>

                <div>
                  <Label htmlFor="biography" className="text-white/60">Biographie</Label>
                  <Textarea
                    id="biography"
                    value={formData.biography}
                    onChange={(e) => setFormData({...formData, biography: e.target.value})}
                    className="bg-fm-dark border-green-500/20 text-white min-h-[120px]"
                    placeholder="Parlez de votre parcours, vos expériences, votre style de jeu..."
                    data-testid="textarea-player-biography"
                  />
                </div>

                <div>
                  <Label htmlFor="sportingProject" className="text-white/60">Projet sportif</Label>
                  <Textarea
                    id="sportingProject"
                    value={formData.sportingProject}
                    onChange={(e) => setFormData({...formData, sportingProject: e.target.value})}
                    className="bg-fm-dark border-green-500/20 text-white min-h-[120px]"
                    placeholder="Vos objectifs, ambitions, le type de club recherché..."
                    data-testid="textarea-player-project"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="strengths" className="text-white/60">Points Forts</Label>
                    <Textarea
                      id="strengths"
                      value={formData.strengths}
                      onChange={(e) => setFormData({...formData, strengths: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white min-h-[100px]"
                      placeholder="Vos principales qualités (technique, vitesse, vision de jeu...)"
                      data-testid="textarea-player-strengths"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="developmentAreas" className="text-white/60">Axes de Progression</Label>
                    <Textarea
                      id="developmentAreas"
                      value={formData.developmentAreas}
                      onChange={(e) => setFormData({...formData, developmentAreas: e.target.value})}
                      className="bg-fm-dark border-green-500/20 text-white min-h-[100px]"
                      placeholder="Domaines à améliorer (jeu aérien, pied faible, tactique...)"
                      data-testid="textarea-player-development"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats techniques */}
          <TabsContent value="technique">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Compétences Techniques</CardTitle>
                <CardDescription className="text-white/60">
                  Évaluez vos compétences techniques (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {technicalStats.map(({ key, label }) => (
                    <StatSlider
                      key={key}
                      label={label}
                      value={stats[key as keyof typeof stats]}
                      onChange={(newValue) => setStats({
                        ...stats,
                        [key]: newValue
                      })}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats mentales */}
          <TabsContent value="mental">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Compétences Mentales</CardTitle>
                <CardDescription className="text-white/60">
                  Aspects mentaux et leadership (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mentalStats.map(({ key, label }) => (
                    <StatSlider
                      key={key}
                      label={label}
                      value={stats[key as keyof typeof stats]}
                      onChange={(newValue) => setStats({
                        ...stats,
                        [key]: newValue
                      })}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats physiques */}
          <TabsContent value="physique">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Compétences Physiques</CardTitle>
                <CardDescription className="text-white/60">
                  Attributs physiques (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {physicalStats.map(({ key, label }) => (
                    <StatSlider
                      key={key}
                      label={label}
                      value={stats[key as keyof typeof stats]}
                      onChange={(newValue) => setStats({
                        ...stats,
                        [key]: newValue
                      })}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Palmarès */}
          <TabsContent value="palmares">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Palmarès & Récompenses</CardTitle>
                <CardDescription className="text-white/60">
                  Trophées et distinctions remportés
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-green-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={achievement.title}
                          onChange={(e) => updateAchievement(index, "title", e.target.value)}
                          className="bg-fm-darker border-green-500/20 text-white"
                          placeholder="Ex: Champion Régional"
                          data-testid={`input-achievement-title-${index}`}
                        />
                      </div>
                      <div>
                        <Label className="text-white/60">Année</Label>
                        <Input
                          type="number"
                          min="1990"
                          max="2024"
                          value={achievement.year}
                          onChange={(e) => updateAchievement(index, "year", e.target.value)}
                          className="bg-fm-darker border-green-500/20 text-white"
                          placeholder="2023"
                          data-testid={`input-achievement-year-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeAchievement(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={achievement.description}
                        onChange={(e) => updateAchievement(index, "description", e.target.value)}
                        className="bg-fm-darker border-green-500/20 text-white"
                        placeholder="Détails sur cette récompense..."
                        data-testid={`textarea-achievement-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addAchievement}
                  variant="outline"
                  className="w-full border-green-500/20 text-green-500 hover:bg-green-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un trophée
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Média */}
          <TabsContent value="media">
            <Card className="bg-fm-card border-green-500/20">
              <CardHeader>
                <CardTitle className="text-green-500">Photos & Vidéos</CardTitle>
                <CardDescription className="text-white/60">
                  Partagez vos moments forts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mediaFiles.map((media, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-green-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={media.title}
                          onChange={(e) => updateMediaFile(index, "title", e.target.value)}
                          className="bg-fm-darker border-green-500/20 text-white"
                          placeholder="Ex: But en finale"
                          data-testid={`input-media-title-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeMediaFile(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={media.description}
                        onChange={(e) => updateMediaFile(index, "description", e.target.value)}
                        className="bg-fm-darker border-green-500/20 text-white"
                        placeholder="Contexte de cette photo/vidéo..."
                        data-testid={`textarea-media-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addMediaFile}
                  variant="outline"
                  className="w-full border-green-500/20 text-green-500 hover:bg-green-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un média
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Boutons de navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="text-white border-white/20"
          >
            Annuler
          </Button>
          
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-blue-500 hover:to-green-500"
            data-testid="button-create-player-profile"
          >
            Créer mon profil
          </Button>
        </div>
      </div>
    </div>
  );
}