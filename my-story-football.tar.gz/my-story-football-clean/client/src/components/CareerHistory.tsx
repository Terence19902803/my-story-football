import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Calendar, Trash2, Edit3 } from "lucide-react";

interface CareerHistoryProps {
  playerId: string;
}

interface CareerRecord {
  id?: string;
  playerId: string;
  season: string;
  club: string;
  league?: string;
  matches: number;
  goals: number;
  assists: number;
  yellowCards: number;
  redCards: number;
  averageRating?: number;
}

export default function CareerHistory({ playerId }: CareerHistoryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<CareerRecord | null>(null);
  const [formData, setFormData] = useState<CareerRecord>({
    playerId,
    season: "",
    club: "",
    league: "",
    matches: 0,
    goals: 0,
    assists: 0,
    yellowCards: 0,
    redCards: 0,
    averageRating: 0
  });

  const { data: history, isLoading } = useQuery({
    queryKey: ["/api/career-history", playerId],
    retry: false,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const addRecordMutation = useMutation({
    mutationFn: async (data: CareerRecord) => {
      const response = await apiRequest("POST", "/api/career-history", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/career-history", playerId] });
      setIsAddDialogOpen(false);
      setEditingRecord(null);
      resetForm();
      toast({
        title: "Saison ajoutée",
        description: "L'historique de carrière a été mis à jour !",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter cette saison",
        variant: "destructive",
      });
    },
  });

  const deleteRecordMutation = useMutation({
    mutationFn: async (recordId: string) => {
      await apiRequest("DELETE", `/api/career-history/${recordId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/career-history", playerId] });
      toast({
        title: "Saison supprimée",
        description: "L'enregistrement a été supprimé de votre historique",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible de supprimer cette saison",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      playerId,
      season: "",
      club: "",
      league: "",
      matches: 0,
      goals: 0,
      assists: 0,
      yellowCards: 0,
      redCards: 0,
      averageRating: 0
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.season || !formData.club) {
      toast({
        title: "Données manquantes",
        description: "La saison et le club sont obligatoires",
        variant: "destructive",
      });
      return;
    }
    addRecordMutation.mutate(formData);
  };

  const handleEdit = (record: CareerRecord) => {
    setEditingRecord(record);
    setFormData(record);
    setIsAddDialogOpen(true);
  };

  const handleDelete = (recordId: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer cette saison ?")) {
      deleteRecordMutation.mutate(recordId);
    }
  };

  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setEditingRecord(null);
    resetForm();
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border" data-testid="career-loading">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/3"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-12 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="career-history">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-fm-gold flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Historique de Carrière
        </CardTitle>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-fm-gold hover:bg-fm-gold/90 text-fm-dark font-semibold"
              data-testid="button-add-season"
            >
              <Plus className="w-4 h-4 mr-2" />
              Ajouter une saison
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-2xl" data-testid="dialog-add-season">
            <DialogHeader>
              <DialogTitle className="text-fm-gold">
                {editingRecord ? "Modifier la saison" : "Ajouter une saison"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-career">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="season" className="text-white">Saison *</Label>
                  <Input
                    id="season"
                    value={formData.season}
                    onChange={(e) => setFormData(prev => ({ ...prev, season: e.target.value }))}
                    placeholder="ex: 2023-24"
                    className="bg-input border-border text-white"
                    required
                    data-testid="input-season"
                  />
                </div>
                <div>
                  <Label htmlFor="club" className="text-white">Club *</Label>
                  <Input
                    id="club"
                    value={formData.club}
                    onChange={(e) => setFormData(prev => ({ ...prev, club: e.target.value }))}
                    placeholder="Nom du club"
                    className="bg-input border-border text-white"
                    required
                    data-testid="input-club"
                  />
                </div>
                <div>
                  <Label htmlFor="league" className="text-white">Championnat</Label>
                  <Input
                    id="league"
                    value={formData.league}
                    onChange={(e) => setFormData(prev => ({ ...prev, league: e.target.value }))}
                    placeholder="ex: Ligue 1"
                    className="bg-input border-border text-white"
                    data-testid="input-league"
                  />
                </div>
                <div>
                  <Label htmlFor="matches" className="text-white">Matchs</Label>
                  <Input
                    id="matches"
                    type="number"
                    min="0"
                    value={formData.matches}
                    onChange={(e) => setFormData(prev => ({ ...prev, matches: parseInt(e.target.value) || 0 }))}
                    className="bg-input border-border text-white"
                    data-testid="input-matches"
                  />
                </div>
                <div>
                  <Label htmlFor="goals" className="text-white">Buts</Label>
                  <Input
                    id="goals"
                    type="number"
                    min="0"
                    value={formData.goals}
                    onChange={(e) => setFormData(prev => ({ ...prev, goals: parseInt(e.target.value) || 0 }))}
                    className="bg-input border-border text-white"
                    data-testid="input-goals"
                  />
                </div>
                <div>
                  <Label htmlFor="assists" className="text-white">Passes décisives</Label>
                  <Input
                    id="assists"
                    type="number"
                    min="0"
                    value={formData.assists}
                    onChange={(e) => setFormData(prev => ({ ...prev, assists: parseInt(e.target.value) || 0 }))}
                    className="bg-input border-border text-white"
                    data-testid="input-assists"
                  />
                </div>
                <div>
                  <Label htmlFor="yellowCards" className="text-white">Cartons jaunes</Label>
                  <Input
                    id="yellowCards"
                    type="number"
                    min="0"
                    value={formData.yellowCards}
                    onChange={(e) => setFormData(prev => ({ ...prev, yellowCards: parseInt(e.target.value) || 0 }))}
                    className="bg-input border-border text-white"
                    data-testid="input-yellow-cards"
                  />
                </div>
                <div>
                  <Label htmlFor="redCards" className="text-white">Cartons rouges</Label>
                  <Input
                    id="redCards"
                    type="number"
                    min="0"
                    value={formData.redCards}
                    onChange={(e) => setFormData(prev => ({ ...prev, redCards: parseInt(e.target.value) || 0 }))}
                    className="bg-input border-border text-white"
                    data-testid="input-red-cards"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="averageRating" className="text-white">Note moyenne</Label>
                  <Input
                    id="averageRating"
                    type="number"
                    min="1"
                    max="10"
                    step="0.1"
                    value={formData.averageRating}
                    onChange={(e) => setFormData(prev => ({ ...prev, averageRating: parseFloat(e.target.value) || 0 }))}
                    placeholder="ex: 7.5"
                    className="bg-input border-border text-white"
                    data-testid="input-rating"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={closeDialog}
                  data-testid="button-cancel-career"
                >
                  Annuler
                </Button>
                <Button 
                  type="submit"
                  disabled={addRecordMutation.isPending}
                  className="bg-fm-green hover:bg-fm-green/90 text-white"
                  data-testid="button-save-career"
                >
                  {addRecordMutation.isPending ? "..." : (editingRecord ? "Modifier" : "Ajouter")}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>

      <CardContent>
        {history && history.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="fm-table w-full" data-testid="table-career-history">
              <thead>
                <tr>
                  <th className="text-left">Saison</th>
                  <th className="text-left">Club</th>
                  <th className="text-left">Championnat</th>
                  <th className="text-center">Matchs</th>
                  <th className="text-center">Buts</th>
                  <th className="text-center">Passes D.</th>
                  <th className="text-center">Note Moy.</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {history.map((record: CareerRecord, index: number) => (
                  <tr key={record.id} className="hover:bg-muted/30 transition-colors" data-testid={`row-career-${index}`}>
                    <td className="font-semibold text-white" data-testid={`season-${index}`}>
                      {record.season}
                    </td>
                    <td className="text-foreground" data-testid={`club-${index}`}>
                      {record.club}
                    </td>
                    <td className="text-muted-foreground text-sm" data-testid={`league-${index}`}>
                      {record.league || "-"}
                    </td>
                    <td className="text-center text-foreground" data-testid={`matches-${index}`}>
                      {record.matches}
                    </td>
                    <td className="text-center text-foreground" data-testid={`goals-${index}`}>
                      {record.goals}
                    </td>
                    <td className="text-center text-foreground" data-testid={`assists-${index}`}>
                      {record.assists}
                    </td>
                    <td className="text-center" data-testid={`rating-${index}`}>
                      {record.averageRating ? (
                        <Badge className="bg-fm-gold text-fm-dark font-semibold">
                          {record.averageRating.toFixed(1)}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </td>
                    <td className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(record)}
                          className="h-8 w-8 p-0 hover:bg-fm-gold/20"
                          data-testid={`button-edit-${index}`}
                        >
                          <Edit3 className="w-4 h-4 text-fm-gold" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(record.id!)}
                          disabled={deleteRecordMutation.isPending}
                          className="h-8 w-8 p-0 hover:bg-red-500/20"
                          data-testid={`button-delete-${index}`}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12" data-testid="career-empty">
            <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Aucun historique</h3>
            <p className="text-muted-foreground mb-6">
              Commencez par ajouter vos saisons pour construire votre historique de carrière
            </p>
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-fm-gold hover:bg-fm-gold/90 text-fm-dark font-semibold"
              data-testid="button-add-first-season"
            >
              <Plus className="w-4 h-4 mr-2" />
              Ajouter votre première saison
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
