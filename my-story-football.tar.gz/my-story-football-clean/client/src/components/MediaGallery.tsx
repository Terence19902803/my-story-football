import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { ObjectUploader } from "@/components/ObjectUploader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Camera, Play, Heart, Trash2, Upload } from "lucide-react";
import type { UploadResult } from '@uppy/core';

interface MediaGalleryProps {
  playerId: string;
}

interface MediaFile {
  id: string;
  title: string;
  description?: string;
  filePath: string;
  fileType: "image" | "video";
  duration?: number;
  likes: number;
  createdAt: string;
}

export default function MediaGallery({ playerId }: MediaGalleryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [uploadedFileUrl, setUploadedFileUrl] = useState<string>("");
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    fileType: "image" as "image" | "video",
    duration: 0
  });

  const { data: mediaFiles, isLoading } = useQuery({
    queryKey: ["/api/media", playerId],
    retry: false,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const addMediaMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/media", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media", playerId] });
      setIsAddDialogOpen(false);
      resetForm();
      toast({
        title: "Média ajouté",
        description: "Votre fichier a été ajouté à la galerie !",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le média",
        variant: "destructive",
      });
    },
  });

  const deleteMediaMutation = useMutation({
    mutationFn: async (mediaId: string) => {
      await apiRequest("DELETE", `/api/media/${mediaId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media", playerId] });
      toast({
        title: "Média supprimé",
        description: "Le fichier a été supprimé de votre galerie",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le média",
        variant: "destructive",
      });
    },
  });

  const likeMediaMutation = useMutation({
    mutationFn: async (mediaId: string) => {
      const response = await apiRequest("POST", `/api/like-media/${mediaId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/media", playerId] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      fileType: "image",
      duration: 0
    });
    setUploadedFileUrl("");
  };

  const handleGetUploadParameters = async () => {
    try {
      const response = await apiRequest("POST", "/api/objects/upload");
      const data = await response.json();
      return {
        method: 'PUT' as const,
        url: data.uploadURL,
      };
    } catch (error) {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        throw error;
      }
      throw error;
    }
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful.length > 0) {
      const uploadedFile = result.successful[0];
      setUploadedFileUrl(uploadedFile.uploadURL || "");
      
      // Detect file type from mime type
      const mimeType = uploadedFile.meta?.type as string || "";
      const isVideo = mimeType.startsWith("video/");
      setFormData(prev => ({
        ...prev,
        fileType: isVideo ? "video" : "image"
      }));

      toast({
        title: "Fichier téléchargé",
        description: "Remplissez les détails pour ajouter le média à votre galerie",
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!uploadedFileUrl) {
      toast({
        title: "Fichier manquant",
        description: "Veuillez d'abord télécharger un fichier",
        variant: "destructive",
      });
      return;
    }

    if (!formData.title) {
      toast({
        title: "Titre manquant",
        description: "Veuillez donner un titre à votre média",
        variant: "destructive",
      });
      return;
    }

    try {
      // First, set ACL policy for the uploaded file
      await apiRequest("PUT", "/api/media-files", {
        fileURL: uploadedFileUrl
      });

      // Then add the media record
      const mediaData = {
        playerId,
        title: formData.title,
        description: formData.description,
        filePath: uploadedFileUrl,
        fileType: formData.fileType,
        duration: formData.fileType === "video" ? formData.duration : null,
      };

      addMediaMutation.mutate(mediaData);
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de finaliser l'ajout du média",
        variant: "destructive",
      });
    }
  };

  const handleDelete = (mediaId: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer ce média ?")) {
      deleteMediaMutation.mutate(mediaId);
    }
  };

  const handleLike = (mediaId: string) => {
    likeMediaMutation.mutate(mediaId);
  };

  const closeDialog = () => {
    setIsAddDialogOpen(false);
    resetForm();
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border" data-testid="media-loading">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/3"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="space-y-2">
                  <div className="aspect-video bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded"></div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="media-gallery">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-fm-gold flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Galerie Multimédia
        </CardTitle>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-fm-gold hover:bg-fm-gold/90 text-fm-dark font-semibold"
              data-testid="button-add-media"
            >
              <Plus className="w-4 h-4 mr-2" />
              Ajouter un média
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-lg" data-testid="dialog-add-media">
            <DialogHeader>
              <DialogTitle className="text-fm-gold">Ajouter un média</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* File Upload */}
              <div className="space-y-2">
                <Label className="text-white">Fichier</Label>
                {!uploadedFileUrl ? (
                  <ObjectUploader
                    maxNumberOfFiles={1}
                    maxFileSize={52428800} // 50MB
                    onGetUploadParameters={handleGetUploadParameters}
                    onComplete={handleUploadComplete}
                    buttonClassName="w-full bg-fm-green hover:bg-fm-green/90 text-white"
                  >
                    <div className="flex items-center gap-2" data-testid="upload-button">
                      <Upload className="w-4 h-4" />
                      <span>Choisir un fichier</span>
                    </div>
                  </ObjectUploader>
                ) : (
                  <div className="p-4 bg-fm-green/10 border border-fm-green/30 rounded-lg" data-testid="file-uploaded">
                    <div className="flex items-center gap-2 text-fm-green">
                      <Camera className="w-4 h-4" />
                      <span className="text-sm">Fichier téléchargé avec succès</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Form Fields */}
              <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-media">
                <div>
                  <Label htmlFor="title" className="text-white">Titre *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Titre de votre média"
                    className="bg-input border-border text-white"
                    required
                    data-testid="input-title"
                  />
                </div>

                <div>
                  <Label htmlFor="description" className="text-white">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Décrivez votre média..."
                    className="bg-input border-border text-white min-h-[80px]"
                    data-testid="textarea-description"
                  />
                </div>

                {formData.fileType === "video" && (
                  <div>
                    <Label htmlFor="duration" className="text-white">Durée (secondes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="0"
                      value={formData.duration}
                      onChange={(e) => setFormData(prev => ({ ...prev, duration: parseInt(e.target.value) || 0 }))}
                      placeholder="Durée en secondes"
                      className="bg-input border-border text-white"
                      data-testid="input-duration"
                    />
                  </div>
                )}

                <div className="flex justify-end gap-3">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={closeDialog}
                    data-testid="button-cancel-media"
                  >
                    Annuler
                  </Button>
                  <Button 
                    type="submit"
                    disabled={addMediaMutation.isPending || !uploadedFileUrl}
                    className="bg-fm-green hover:bg-fm-green/90 text-white"
                    data-testid="button-save-media"
                  >
                    {addMediaMutation.isPending ? "..." : "Ajouter"}
                  </Button>
                </div>
              </form>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>

      <CardContent>
        {mediaFiles && mediaFiles.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mediaFiles.map((media: MediaFile, index: number) => (
              <Card 
                key={media.id}
                className="bg-card border-border hover:border-fm-gold/50 transition-all group overflow-hidden"
                data-testid={`media-item-${index}`}
              >
                <div className="relative overflow-hidden aspect-video">
                  {media.filePath ? (
                    <img 
                      src={media.filePath} 
                      alt={media.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      data-testid={`img-media-${index}`}
                    />
                  ) : (
                    <div className="w-full h-full bg-muted flex items-center justify-center">
                      <Camera className="w-8 h-8 text-muted-foreground" />
                    </div>
                  )}
                  
                  {/* Overlay icons */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    {media.fileType === "video" ? (
                      <Play className="w-8 h-8 text-white" />
                    ) : (
                      <Camera className="w-8 h-8 text-white" />
                    )}
                  </div>
                  
                  {/* Duration badge for videos */}
                  {media.fileType === "video" && media.duration && (
                    <Badge className="absolute top-2 right-2 bg-black/70 text-white" data-testid={`duration-${index}`}>
                      {Math.floor(media.duration / 60)}:{(media.duration % 60).toString().padStart(2, '0')}
                    </Badge>
                  )}
                  
                  {/* Delete button */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(media.id)}
                    className="absolute top-2 left-2 h-8 w-8 p-0 bg-black/50 hover:bg-red-500/70 opacity-0 group-hover:opacity-100 transition-opacity"
                    data-testid={`button-delete-media-${index}`}
                  >
                    <Trash2 className="w-4 h-4 text-white" />
                  </Button>
                </div>
                
                <CardContent className="p-4">
                  <h3 className="font-semibold text-white mb-2 truncate" data-testid={`title-${index}`}>
                    {media.title}
                  </h3>
                  {media.description && (
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2" data-testid={`description-${index}`}>
                      {media.description}
                    </p>
                  )}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground" data-testid={`date-${index}`}>
                      {new Date(media.createdAt).toLocaleDateString('fr-FR')}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(media.id)}
                      className="h-auto p-1 hover:bg-red-500/20"
                      data-testid={`button-like-media-${index}`}
                    >
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4 text-red-500" />
                        <span className="text-white" data-testid={`likes-${index}`}>{media.likes || 0}</span>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12" data-testid="media-empty">
            <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Aucun média</h3>
            <p className="text-muted-foreground mb-6">
              Commencez par télécharger vos photos et vidéos pour créer votre galerie
            </p>
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-fm-gold hover:bg-fm-gold/90 text-fm-dark font-semibold"
              data-testid="button-add-first-media"
            >
              <Plus className="w-4 h-4 mr-2" />
              Ajouter votre premier média
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
