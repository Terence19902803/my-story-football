import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Plus, X, Trophy, Target, TrendingUp, 
  Calendar, Shield, Check, Sparkles 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CareerEntry {
  id: string;
  club: string;
  season: string;
  matches?: number;
  goals?: number;
  trophies?: string[];
}

export default function CareerTimeline() {
  const [entries, setEntries] = useState<CareerEntry[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newEntry, setNewEntry] = useState<Partial<CareerEntry>>({
    club: "",
    season: "2024-25",
    matches: 0,
    goals: 0
  });
  const { toast } = useToast();
  
  const currentYear = new Date().getFullYear();
  const seasons = Array.from({ length: 10 }, (_, i) => {
    const year = currentYear - i;
    return `${year}-${(year + 1).toString().slice(-2)}`;
  });
  
  const quickTrophies = [
    "🏆 Championnat",
    "🥇 Coupe",
    "⚽ Meilleur buteur",
    "⭐ Joueur du mois",
    "🎯 Meilleur passeur"
  ];
  
  const handleAddEntry = () => {
    if (!newEntry.club) {
      toast({
        title: "Erreur",
        description: "Le nom du club est requis",
        variant: "destructive"
      });
      return;
    }
    
    const entry: CareerEntry = {
      id: Date.now().toString(),
      club: newEntry.club!,
      season: newEntry.season!,
      matches: newEntry.matches || 0,
      goals: newEntry.goals || 0,
      trophies: newEntry.trophies || []
    };
    
    setEntries([entry, ...entries]);
    setNewEntry({ club: "", season: "2024-25", matches: 0, goals: 0 });
    setIsAdding(false);
    
    toast({
      title: "Saison ajoutée !",
      description: `${entry.club} (${entry.season}) a été ajouté à votre carrière`,
    });
  };
  
  const removeEntry = (id: string) => {
    setEntries(entries.filter(e => e.id !== id));
  };
  
  const toggleTrophy = (trophy: string) => {
    setNewEntry({
      ...newEntry,
      trophies: newEntry.trophies?.includes(trophy)
        ? newEntry.trophies.filter(t => t !== trophy)
        : [...(newEntry.trophies || []), trophy]
    });
  };
  
  return (
    <div className="space-y-6">
      {/* Quick Add Button */}
      {!isAdding && (
        <Button
          onClick={() => setIsAdding(true)}
          className="fm-button fm-button-gold w-full group"
          data-testid="button-add-season"
        >
          <Plus className="w-5 h-5 mr-2 group-hover:rotate-90 transition-transform" />
          Ajouter une saison
          <Sparkles className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
        </Button>
      )}
      
      {/* Add Entry Form - Simplified */}
      {isAdding && (
        <Card className="fm-card glass border-fm-gold/30 animate-in slide-in-from-top duration-300">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bebas text-fm-gold">NOUVELLE SAISON</h3>
              <Button
                onClick={() => setIsAdding(false)}
                variant="ghost"
                size="icon"
                className="hover:bg-red-500/20"
                data-testid="button-cancel"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <Label className="text-xs text-gray-400">Club</Label>
                <Input
                  placeholder="Ex: PSG, Real Madrid..."
                  value={newEntry.club}
                  onChange={(e) => setNewEntry({ ...newEntry, club: e.target.value })}
                  className="bg-fm-card border-gray-700 text-white"
                  data-testid="input-club"
                />
              </div>
              
              <div>
                <Label className="text-xs text-gray-400">Saison</Label>
                <select
                  value={newEntry.season}
                  onChange={(e) => setNewEntry({ ...newEntry, season: e.target.value })}
                  className="w-full px-3 py-2 bg-fm-card border border-gray-700 rounded-lg text-white"
                  data-testid="select-season"
                >
                  {seasons.map(season => (
                    <option key={season} value={season}>{season}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <Label className="text-xs text-gray-400">Matchs joués</Label>
                <Input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={newEntry.matches}
                  onChange={(e) => setNewEntry({ ...newEntry, matches: parseInt(e.target.value) || 0 })}
                  className="bg-fm-card border-gray-700 text-white"
                  data-testid="input-matches"
                />
              </div>
              
              <div>
                <Label className="text-xs text-gray-400">Buts marqués</Label>
                <Input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={newEntry.goals}
                  onChange={(e) => setNewEntry({ ...newEntry, goals: parseInt(e.target.value) || 0 })}
                  className="bg-fm-card border-gray-700 text-white"
                  data-testid="input-goals"
                />
              </div>
            </div>
            
            {/* Quick Trophy Selection */}
            <div className="mb-4">
              <Label className="text-xs text-gray-400 mb-2 block">Trophées (optionnel)</Label>
              <div className="flex flex-wrap gap-2">
                {quickTrophies.map(trophy => (
                  <Button
                    key={trophy}
                    onClick={() => toggleTrophy(trophy)}
                    variant="outline"
                    size="sm"
                    className={`
                      border-gray-700 transition-all
                      ${newEntry.trophies?.includes(trophy)
                        ? "bg-fm-gold/20 border-fm-gold text-fm-gold"
                        : "hover:border-fm-gold/50"
                      }
                    `}
                    data-testid={`trophy-${trophy}`}
                  >
                    {trophy}
                  </Button>
                ))}
              </div>
            </div>
            
            <Button
              onClick={handleAddEntry}
              className="fm-button fm-button-gold w-full"
              data-testid="button-save-season"
            >
              <Check className="w-4 h-4 mr-2" />
              Ajouter cette saison
            </Button>
          </CardContent>
        </Card>
      )}
      
      {/* Timeline Display - Modern Cards */}
      <div className="space-y-3">
        {entries.map((entry, index) => (
          <div
            key={entry.id}
            className="fm-card glass p-4 hover:scale-[1.02] transition-all duration-300 relative overflow-hidden group"
            style={{
              animationDelay: `${index * 0.1}s`
            }}
            data-testid={`career-entry-${index}`}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-fm-gold/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <div className="relative">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="w-5 h-5 text-fm-gold" />
                    <h4 className="font-bebas text-xl text-white">{entry.club}</h4>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Calendar className="w-4 h-4" />
                    <span>{entry.season}</span>
                  </div>
                </div>
                
                <Button
                  onClick={() => removeEntry(entry.id)}
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/20"
                  data-testid={`button-remove-${index}`}
                >
                  <X className="w-4 h-4 text-red-400" />
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-3">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-green-500" />
                  <span className="text-sm text-gray-300">
                    <span className="font-bold text-white">{entry.matches}</span> matchs
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-blue-500" />
                  <span className="text-sm text-gray-300">
                    <span className="font-bold text-white">{entry.goals}</span> buts
                  </span>
                </div>
              </div>
              
              {entry.trophies && entry.trophies.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-3 border-t border-gray-800">
                  {entry.trophies.map((trophy, i) => (
                    <span
                      key={i}
                      className="text-xs bg-fm-gold/10 text-fm-gold px-2 py-1 rounded-full"
                    >
                      {trophy}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {/* Empty State */}
      {entries.length === 0 && !isAdding && (
        <Card className="fm-card glass border-dashed border-2 border-gray-700">
          <CardContent className="py-12 text-center">
            <Trophy className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">
              Votre parcours apparaîtra ici
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Commencez par ajouter votre saison actuelle
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}