import { useLocation } from "wouter";
import { useState } from "react";
import { 
  Home, User, BarChart3, Trophy, 
  TrendingUp, Camera, Plus, LogIn,
  Menu, X, ArrowLeft, Clock, Settings,
  FileText, LogOut, Search, Users,
  Video, Heart, Star, Play, Building2,
  MessageSquare
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

interface NavItem {
  icon: any;
  label: string;
  href: string;
  active?: boolean;
}

export default function MobileNavigation() {
  const [location, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  
  const navItems: NavItem[] = isAuthenticated ? [
    {
      icon: Home,
      label: "Accueil",
      href: "/",
      active: location === "/"
    },
    {
      icon: MessageSquare,
      label: "Messages",
      href: "/messages",
      active: location === "/messages"
    },
    {
      icon: User,
      label: "Profil", 
      href: "/profile",
      active: location.startsWith("/profile")
    },
    {
      icon: Trophy,
      label: "Carrière",
      href: "/profile#career",
      active: location.includes("#career")
    },
    {
      icon: LogOut,
      label: "Déconnexion",
      href: "/api/logout",
      active: false
    }
  ] : [
    {
      icon: Home,
      label: "Accueil",
      href: "/",
      active: location === "/"
    },
    {
      icon: User,
      label: "Joueur",
      href: "/player-cv",
      active: location === "/player-cv"
    },
    {
      icon: Users,
      label: "Coach",
      href: "/coach-cv",
      active: location === "/coach-cv"
    },
    {
      icon: Building2,
      label: "Club",
      href: "/club-cv",
      active: location === "/club-cv"
    },
    {
      icon: LogIn,
      label: "Connexion",
      href: "/profile-type-selection",
      active: false
    }
  ];

  const handleNavClick = (href: string) => {
    if (href === "/api/login" || href === "/api/logout") {
      window.location.href = href;
      return;
    }
    if (href.includes("#")) {
      const [path, hash] = href.split("#");
      navigate(path);
      setTimeout(() => {
        const element = document.getElementById(hash);
        element?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } else {
      navigate(href);
    }
  };

  return (
    <>
      {/* Bouton Menu Hamburger */}
      <button
        onClick={() => setMenuOpen(true)}
        className="fixed top-4 right-4 z-40 p-3 bg-fm-darker/90 backdrop-blur-xl rounded-xl border border-fm-gold/20 hover:border-fm-gold/40 transition-all duration-200 shadow-lg"
        data-testid="menu-hamburger"
      >
        <Menu className="w-6 h-6 text-white" />
      </button>

      {/* Bottom Navigation Bar - Style App Native */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-fm-darker/95 backdrop-blur-xl border-t border-fm-gold/20">
        <div className="safe-area-bottom">
          <nav className="flex justify-around items-center px-2 py-2">
            {navItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <button
                  key={index}
                  onClick={() => handleNavClick(item.href)}
                  className={cn(
                    "flex flex-col items-center justify-center p-2 rounded-xl min-w-[60px] transition-all duration-200",
                    item.active 
                      ? "bg-fm-gold/20 text-fm-gold scale-105" 
                      : "text-gray-400 hover:text-white active:scale-95"
                  )}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  <div className={cn(
                    "p-2 rounded-xl mb-1 transition-all duration-200",
                    item.active 
                      ? "bg-fm-gold/10 shadow-lg shadow-fm-gold/20" 
                      : "hover:bg-white/10"
                  )}>
                    <Icon className={cn(
                      "w-5 h-5 transition-all duration-200",
                      item.active ? "text-fm-gold drop-shadow-md" : ""
                    )} />
                  </div>
                  <span className={cn(
                    "text-xs font-bold transition-all duration-200",
                    item.active ? "text-fm-gold font-extrabold" : "text-white/70"
                  )}>
                    {item.label}
                  </span>
                  {item.active && (
                    <div className="absolute -top-0.5 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-fm-gold rounded-full shadow-md" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Floating Action Button - Only for authenticated users */}
      {isAuthenticated && (
        <button 
          onClick={() => navigate("/profile#media")}
          className="fixed bottom-20 right-4 z-50 bg-gradient-to-r from-fm-gold to-yellow-500 text-fm-darker p-4 rounded-full shadow-2xl shadow-fm-gold/30 hover:scale-110 active:scale-95 transition-all duration-200"
          data-testid="fab-add-media"
        >
          <Plus className="w-6 h-6" />
          <div className="absolute inset-0 bg-white/20 rounded-full animate-ping" />
        </button>
      )}

      {/* Spacer pour éviter que le contenu soit caché */}
      <div className="h-20" />

      {/* Menu Overlay */}
      {menuOpen && (
        <div className="fixed inset-0 z-[100]">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => setMenuOpen(false)}
          />
          
          {/* Menu Panel */}
          <div className="absolute right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-gradient-to-b from-fm-darker to-black border-l border-fm-gold/20 overflow-y-auto">
            {/* Menu Header */}
            <div className="sticky top-0 bg-fm-darker/95 backdrop-blur-xl border-b border-fm-gold/20 p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">Menu</h2>
                <button
                  onClick={() => setMenuOpen(false)}
                  className="p-2 text-white/70 hover:text-white transition-colors rounded-lg hover:bg-white/10"
                  data-testid="menu-close"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Menu Content */}
            <div className="p-4 space-y-6">
              {/* Navigation principale */}
              <div>
                <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Navigation</h3>
                <div className="space-y-1">
                  <MenuLink
                    icon={Home}
                    label="Accueil"
                    onClick={() => {
                      navigate("/");
                      setMenuOpen(false);
                    }}
                    active={location === "/"}
                  />
                  <MenuLink
                    icon={TrendingUp}
                    label="Explorer"
                    onClick={() => {
                      navigate("/explore");
                      setMenuOpen(false);
                    }}
                    active={location === "/explore"}
                  />
                  <MenuLink
                    icon={Users}
                    label="Joueurs"
                    onClick={() => {
                      navigate("/search-players");
                      setMenuOpen(false);
                    }}
                    active={location === "/search-players"}
                  />
                  <MenuLink
                    icon={Users}
                    label="Coachs"
                    onClick={() => {
                      navigate("/search-coaches");
                      setMenuOpen(false);
                    }}
                    active={location === "/search-coaches"}
                  />
                  <MenuLink
                    icon={Building2}
                    label="Clubs"
                    onClick={() => {
                      navigate("/search-clubs");
                      setMenuOpen(false);
                    }}
                    active={location === "/search-clubs"}
                  />
                  <MenuLink
                    icon={MessageSquare}
                    label="Messagerie"
                    onClick={() => {
                      navigate("/messages");
                      setMenuOpen(false);
                    }}
                    active={location === "/messages"}
                  />
                  {!isAuthenticated && (
                    <MenuLink
                      icon={Trophy}
                      label="Démo"
                      onClick={() => {
                        navigate("/player-cv");
                        setMenuOpen(false);
                      }}
                      active={location === "/player-cv"}
                    />
                  )}
                </div>
              </div>

              {/* Multimédia Communauté */}
              <div>
                <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Multimédia</h3>
                <div className="space-y-1">
                  <MenuLink
                    icon={Play}
                    label="Vidéos du moment"
                    onClick={() => {
                      navigate("/videos/trending");
                      setMenuOpen(false);
                    }}
                    active={location === "/videos/trending"}
                  />
                  <MenuLink
                    icon={Video}
                    label="Vidéos les plus vues"
                    onClick={() => {
                      navigate("/videos/most-viewed");
                      setMenuOpen(false);
                    }}
                    active={location === "/videos/most-viewed"}
                  />
                </div>
              </div>

              {/* Top 10 */}
              <div>
                <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Top 10</h3>
                <div className="space-y-1">
                  <MenuLink
                    icon={Star}
                    label="Top 10 Profils"
                    onClick={() => {
                      navigate("/top/profiles");
                      setMenuOpen(false);
                    }}
                    active={location === "/top/profiles"}
                  />
                  <MenuLink
                    icon={Camera}
                    label="Top 10 Photos"
                    onClick={() => {
                      navigate("/top/photos");
                      setMenuOpen(false);
                    }}
                    active={location === "/top/photos"}
                  />
                  <MenuLink
                    icon={Video}
                    label="Top 10 Vidéos"
                    onClick={() => {
                      navigate("/top/videos");
                      setMenuOpen(false);
                    }}
                    active={location === "/top/videos"}
                  />
                </div>
              </div>

              {/* Mon profil */}
              {isAuthenticated && (
                <div>
                  <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Mon Profil</h3>
                  <div className="space-y-1">
                    <MenuLink
                      icon={User}
                      label="Mon profil"
                      onClick={() => {
                        navigate("/profile");
                        setMenuOpen(false);
                      }}
                      active={location === "/profile"}
                    />
                    <MenuLink
                      icon={BarChart3}
                      label="Mes statistiques"
                      onClick={() => {
                        navigate("/profile#stats");
                        setMenuOpen(false);
                      }}
                      active={location.includes("#stats")}
                    />
                    <MenuLink
                      icon={Camera}
                      label="Mes médias"
                      onClick={() => {
                        navigate("/profile#media");
                        setMenuOpen(false);
                      }}
                      active={location.includes("#media")}
                    />
                    <MenuLink
                      icon={Trophy}
                      label="Ma carrière"
                      onClick={() => {
                        navigate("/profile#career");
                        setMenuOpen(false);
                      }}
                      active={location.includes("#career")}
                    />
                    <MenuLink
                      icon={Clock}
                      label="Historique"
                      onClick={() => {
                        navigate("/profile#history");
                        setMenuOpen(false);
                      }}
                      active={location.includes("#history")}
                    />
                  </div>
                </div>
              )}

              {/* Paramètres */}
              <div>
                <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Paramètres</h3>
                <div className="space-y-1">
                  {isAuthenticated && (
                    <>
                      <MenuLink
                        icon={Settings}
                        label="Paramètres"
                        onClick={() => {
                          navigate("/settings");
                          setMenuOpen(false);
                        }}
                        active={location === "/settings"}
                      />
                      <MenuLink
                        icon={LogOut}
                        label="Déconnexion"
                        onClick={() => {
                          window.location.href = "/api/logout";
                        }}
                        className="text-red-400 hover:text-red-300"
                      />
                    </>
                  )}
                  {!isAuthenticated && (
                    <MenuLink
                      icon={LogIn}
                      label="Connexion"
                      onClick={() => {
                        window.location.href = "/api/login";
                      }}
                      className="text-fm-gold hover:text-yellow-400"
                    />
                  )}
                  <MenuLink
                    icon={FileText}
                    label="Conditions d'utilisation"
                    onClick={() => {
                      navigate("/terms");
                      setMenuOpen(false);
                    }}
                  />
                </div>
              </div>

              {/* Actions rapides */}
              <div>
                <h3 className="text-xs font-semibold text-fm-gold/70 uppercase tracking-wider mb-3">Actions rapides</h3>
                <div className="space-y-1">
                  <MenuLink
                    icon={ArrowLeft}
                    label="Retour"
                    onClick={() => {
                      window.history.back();
                      setMenuOpen(false);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Composant pour les liens du menu
function MenuLink({ 
  icon: Icon, 
  label, 
  onClick, 
  active = false,
  className = ""
}: {
  icon: any;
  label: string;
  onClick: () => void;
  active?: boolean;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
        "hover:bg-white/10 active:scale-95",
        active && "bg-gradient-to-r from-fm-gold/20 to-yellow-500/20 border border-fm-gold/30",
        className
      )}
      data-testid={`menu-link-${label.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <Icon className={cn(
        "w-5 h-5",
        active ? "text-fm-gold" : "text-white/70",
        className && className.includes("text-") ? "" : ""
      )} />
      <span className={cn(
        "font-medium",
        active ? "text-white font-semibold" : "text-white/80",
        className
      )}>
        {label}
      </span>
    </button>
  );
}