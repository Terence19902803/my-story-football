import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  UserPlus, Image, Trophy, BarChart3, 
  Plus, Upload, Sparkles 
} from "lucide-react";

interface EmptyStateProps {
  type: "profile" | "stats" | "media" | "career" | "achievements";
  onAction?: () => void;
}

export default function EmptyState({ type, onAction }: EmptyStateProps) {
  const states = {
    profile: {
      icon: UserPlus,
      title: "Créez votre profil joueur",
      description: "Commencez par renseigner vos informations de base pour débloquer toutes les fonctionnalités",
      actionText: "Créer mon profil",
      gradient: "from-fm-gold/20 to-transparent"
    },
    stats: {
      icon: BarChart3,
      title: "Définissez vos statistiques",
      description: "Ajoutez vos attributs techniques, physiques et mentaux comme dans Football Manager",
      actionText: "Ajouter mes stats",
      gradient: "from-green-500/20 to-transparent"
    },
    media: {
      icon: Image,
      title: "Aucun média pour le moment",
      description: "Uploadez vos photos et vidéos pour montrer vos meilleurs moments",
      actionText: "Ajouter des médias",
      gradient: "from-blue-500/20 to-transparent"
    },
    career: {
      icon: Trophy,
      title: "Documentez votre carrière",
      description: "Ajoutez vos clubs, saisons et performances pour créer votre historique",
      actionText: "Ajouter une saison",
      gradient: "from-purple-500/20 to-transparent"
    },
    achievements: {
      icon: Trophy,
      title: "Vos trophées apparaîtront ici",
      description: "Ajoutez vos titres, récompenses et accomplissements personnels",
      actionText: "Ajouter un trophée",
      gradient: "from-orange-500/20 to-transparent"
    }
  };
  
  const state = states[type];
  const Icon = state.icon;
  
  return (
    <Card className="fm-card glass border-dashed border-2 border-gray-700 hover:border-fm-gold/50 transition-all duration-300">
      <CardContent className="py-12 text-center">
        <div className={`inline-flex p-6 rounded-full bg-gradient-to-br ${state.gradient} mb-4 animate-pulse`}>
          <Icon className="w-12 h-12 text-gray-400" />
        </div>
        
        <h3 className="text-xl font-bebas text-white mb-2">
          {state.title}
        </h3>
        
        <p className="text-gray-400 text-sm mb-6 max-w-sm mx-auto">
          {state.description}
        </p>
        
        {onAction && (
          <Button 
            onClick={onAction}
            className="fm-button fm-button-gold group"
            data-testid={`button-empty-${type}`}
          >
            <Plus className="w-4 h-4 mr-2 group-hover:rotate-90 transition-transform duration-300" />
            {state.actionText}
            <Sparkles className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
          </Button>
        )}
      </CardContent>
    </Card>
  );
}