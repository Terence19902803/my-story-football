import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Edit3, Save, X, Trophy } from "lucide-react";

interface StatsDisplayProps {
  playerId: string;
}

interface PlayerStats {
  id?: string;
  playerId: string;
  // Technical stats
  dribbling: number;
  finishing: number;
  passing: number;
  crossing: number;
  shooting: number;
  // Physical stats
  pace: number;
  stamina: number;
  strength: number;
  jumping: number;
  // Mental stats
  vision: number;
  leadership: number;
  determination: number;
  composure: number;
  // Goalkeeping stats
  handling: number;
  reflexes: number;
}

const statCategories = {
  technical: {
    name: "Techniques",
    color: "from-blue-500 to-blue-600",
    stats: [
      { key: "dribbling", name: "Dribble" },
      { key: "finishing", name: "Finition" },
      { key: "passing", name: "Passes" },
      { key: "crossing", name: "Centres" },
      { key: "shooting", name: "Tir" },
    ]
  },
  physical: {
    name: "Physiques",
    color: "from-green-500 to-green-600",
    stats: [
      { key: "pace", name: "Vitesse" },
      { key: "stamina", name: "Endurance" },
      { key: "strength", name: "Puissance" },
      { key: "jumping", name: "Détente" },
    ]
  },
  mental: {
    name: "Mentales",
    color: "from-purple-500 to-purple-600",
    stats: [
      { key: "vision", name: "Vision" },
      { key: "leadership", name: "Leadership" },
      { key: "determination", name: "Détermination" },
      { key: "composure", name: "Sang-froid" },
    ]
  },
  goalkeeping: {
    name: "Gardien",
    color: "from-orange-500 to-orange-600",
    stats: [
      { key: "handling", name: "Prise de balle" },
      { key: "reflexes", name: "Réflexes" },
    ]
  }
};

export default function StatsDisplay({ playerId }: StatsDisplayProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [editedStats, setEditedStats] = useState<PlayerStats | null>(null);

  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/player-stats", playerId],
    retry: false,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const updateStatsMutation = useMutation({
    mutationFn: async (statsData: PlayerStats) => {
      const response = await apiRequest("POST", "/api/player-stats", statsData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/player-stats", playerId] });
      setIsEditing(false);
      setEditedStats(null);
      toast({
        title: "Statistiques mises à jour",
        description: "Vos stats ont été enregistrées avec succès !",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session expirée",
          description: "Reconnexion en cours...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour les statistiques",
        variant: "destructive",
      });
    },
  });

  const handleEdit = () => {
    setIsEditing(true);
    setEditedStats(stats || {
      playerId,
      dribbling: 10, finishing: 10, passing: 10, crossing: 10, shooting: 10,
      pace: 10, stamina: 10, strength: 10, jumping: 10,
      vision: 10, leadership: 10, determination: 10, composure: 10,
      handling: 10, reflexes: 10
    });
  };

  const handleSave = () => {
    if (editedStats) {
      updateStatsMutation.mutate(editedStats);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedStats(null);
  };

  const handleStatChange = (statKey: string, value: number) => {
    if (editedStats) {
      setEditedStats({
        ...editedStats,
        [statKey]: Math.max(1, Math.min(20, value))
      });
    }
  };

  const getStatColor = (value: number) => {
    if (value >= 16) return "text-fm-gold";
    if (value >= 13) return "text-green-400";
    if (value >= 10) return "text-yellow-400";
    return "text-red-400";
  };

  const getStatBarWidth = (value: number) => (value / 20) * 100;

  const currentStats = editedStats || stats;

  if (isLoading) {
    return (
      <Card className="bg-card border-border" data-testid="stats-loading">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/3"></div>
            <div className="grid md:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="space-y-3">
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                  {[...Array(4)].map((_, j) => (
                    <div key={j} className="space-y-2">
                      <div className="h-3 bg-muted rounded"></div>
                      <div className="h-2 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="stats-display">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-fm-gold flex items-center gap-2">
          <Trophy className="w-5 h-5" />
          Caractéristiques (Style FM)
        </CardTitle>
        <div className="flex items-center gap-2">
          {!isEditing ? (
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleEdit}
              className="border-fm-gold text-fm-gold hover:bg-fm-gold hover:text-fm-dark"
              data-testid="button-edit-stats"
            >
              <Edit3 className="w-4 h-4 mr-2" />
              Modifier
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <Button 
                size="sm"
                onClick={handleSave}
                disabled={updateStatsMutation.isPending}
                className="bg-fm-green hover:bg-fm-green/90 text-white"
                data-testid="button-save-stats"
              >
                <Save className="w-4 h-4 mr-2" />
                {updateStatsMutation.isPending ? "..." : "Sauvegarder"}
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleCancel}
                data-testid="button-cancel-stats"
              >
                <X className="w-4 h-4 mr-2" />
                Annuler
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="main" className="w-full" data-testid="stats-tabs">
          <TabsList className="grid w-full grid-cols-2 bg-card border-border mb-6">
            <TabsTrigger 
              value="main" 
              className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark"
              data-testid="tab-main-stats"
            >
              Stats Principales
            </TabsTrigger>
            <TabsTrigger 
              value="goalkeeping" 
              className="data-[state=active]:bg-fm-gold data-[state=active]:text-fm-dark"
              data-testid="tab-gk-stats"
            >
              Gardien
            </TabsTrigger>
          </TabsList>

          <TabsContent value="main" className="mt-0">
            <div className="grid md:grid-cols-3 gap-8">
              {Object.entries(statCategories).filter(([key]) => key !== 'goalkeeping').map(([categoryKey, category]) => (
                <div key={categoryKey} data-testid={`stats-category-${categoryKey}`}>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r ${category.color} text-white text-sm font-semibold mb-4`}>
                    {category.name}
                  </div>
                  
                  <div className="space-y-4">
                    {category.stats.map((stat) => {
                      const value = currentStats?.[stat.key as keyof PlayerStats] as number || 10;
                      return (
                        <div key={stat.key} className="space-y-2" data-testid={`stat-${stat.key}`}>
                          <div className="flex items-center justify-between">
                            <Label className="text-muted-foreground text-sm">{stat.name}</Label>
                            {isEditing ? (
                              <Input
                                type="number"
                                min="1"
                                max="20"
                                value={value}
                                onChange={(e) => handleStatChange(stat.key, parseInt(e.target.value) || 1)}
                                className="w-16 h-8 text-center bg-input border-border text-white"
                                data-testid={`input-${stat.key}`}
                              />
                            ) : (
                              <Badge 
                                variant="outline" 
                                className={`${getStatColor(value)} border-current font-bold min-w-[2rem] justify-center`}
                                data-testid={`value-${stat.key}`}
                              >
                                {value}
                              </Badge>
                            )}
                          </div>
                          {!isEditing && (
                            <div className="stat-bar">
                              <div 
                                className="stat-bar-fill" 
                                style={{ width: `${getStatBarWidth(value)}%` }}
                                data-testid={`bar-${stat.key}`}
                              ></div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="goalkeeping" className="mt-0">
            <div className="max-w-md mx-auto">
              <div className={`inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r ${statCategories.goalkeeping.color} text-white text-sm font-semibold mb-6`}>
                {statCategories.goalkeeping.name}
              </div>
              
              <div className="space-y-4">
                {statCategories.goalkeeping.stats.map((stat) => {
                  const value = currentStats?.[stat.key as keyof PlayerStats] as number || 10;
                  return (
                    <div key={stat.key} className="space-y-2" data-testid={`stat-gk-${stat.key}`}>
                      <div className="flex items-center justify-between">
                        <Label className="text-muted-foreground text-sm">{stat.name}</Label>
                        {isEditing ? (
                          <Input
                            type="number"
                            min="1"
                            max="20"
                            value={value}
                            onChange={(e) => handleStatChange(stat.key, parseInt(e.target.value) || 1)}
                            className="w-16 h-8 text-center bg-input border-border text-white"
                            data-testid={`input-gk-${stat.key}`}
                          />
                        ) : (
                          <Badge 
                            variant="outline" 
                            className={`${getStatColor(value)} border-current font-bold min-w-[2rem] justify-center`}
                            data-testid={`value-gk-${stat.key}`}
                          >
                            {value}
                          </Badge>
                        )}
                      </div>
                      {!isEditing && (
                        <div className="stat-bar">
                          <div 
                            className="stat-bar-fill" 
                            style={{ width: `${getStatBarWidth(value)}%` }}
                            data-testid={`bar-gk-${stat.key}`}
                          ></div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {currentStats && !isEditing && (
          <div className="mt-8 p-4 bg-card/50 rounded-lg">
            <h4 className="font-semibold text-white mb-3">Résumé des performances</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-fm-gold" data-testid="overall-technical">
                  {Math.round(
                    (currentStats.dribbling + currentStats.finishing + currentStats.passing + currentStats.crossing + currentStats.shooting) / 5
                  )}
                </div>
                <div className="text-xs text-muted-foreground">Technique</div>
              </div>
              <div>
                <div className="text-lg font-bold text-fm-gold" data-testid="overall-physical">
                  {Math.round(
                    (currentStats.pace + currentStats.stamina + currentStats.strength + currentStats.jumping) / 4
                  )}
                </div>
                <div className="text-xs text-muted-foreground">Physique</div>
              </div>
              <div>
                <div className="text-lg font-bold text-fm-gold" data-testid="overall-mental">
                  {Math.round(
                    (currentStats.vision + currentStats.leadership + currentStats.determination + currentStats.composure) / 4
                  )}
                </div>
                <div className="text-xs text-muted-foreground">Mental</div>
              </div>
              <div>
                <div className="text-lg font-bold text-fm-gold" data-testid="overall-total">
                  {Math.round(
                    (currentStats.dribbling + currentStats.finishing + currentStats.passing + currentStats.crossing + currentStats.shooting +
                     currentStats.pace + currentStats.stamina + currentStats.strength + currentStats.jumping +
                     currentStats.vision + currentStats.leadership + currentStats.determination + currentStats.composure) / 13
                  )}
                </div>
                <div className="text-xs text-muted-foreground">Global</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
