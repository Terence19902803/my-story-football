import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  User, BarChart3, Trophy, MessageSquare, Brain, Target, Camera, Plus, Trash2
} from "lucide-react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { StatSlider } from "./StatSlider";

interface CoachOnboardingProps {
  onComplete: () => void;
}

export default function CoachOnboarding({ onComplete }: CoachOnboardingProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basics");
  
  const [formData, setFormData] = useState({
    name: "",
    dateOfBirth: "",
    nationality: "",
    currentClub: "",
    biography: "",
    philosophy: "",
    strengths: "",
    developmentAreas: ""
  });

  const [stats, setStats] = useState({
    // Coaching attributes
    attacking: 10,
    defending: 10,
    mentalCoaching: 10,
    tacticalKnowledge: 10,
    technicalCoaching: 10,
    
    // Management attributes
    manManagement: 10,
    workingWithYoungsters: 10,
    motivation: 10,
    determination: 10,
    
    // Knowledge attributes
    judgePlayerAbility: 10,
    judgePlayerPotential: 10,
    levelOfDiscipline: 10,
    adaptability: 10
  });

  const [achievements, setAchievements] = useState([
    { title: "", description: "", year: "", type: "trophy" }
  ]);

  const [mediaFiles, setMediaFiles] = useState([
    { title: "", description: "", type: "image" }
  ]);

  const addAchievement = () => {
    setAchievements([...achievements, { title: "", description: "", year: "", type: "trophy" }]);
  };

  const removeAchievement = (index: number) => {
    setAchievements(achievements.filter((_, i) => i !== index));
  };

  const updateAchievement = (index: number, field: string, value: string) => {
    const updated = achievements.map((achievement, i) => 
      i === index ? { ...achievement, [field]: value } : achievement
    );
    setAchievements(updated);
  };

  const addMediaFile = () => {
    setMediaFiles([...mediaFiles, { title: "", description: "", type: "image" }]);
  };

  const removeMediaFile = (index: number) => {
    setMediaFiles(mediaFiles.filter((_, i) => i !== index));
  };

  const updateMediaFile = (index: number, field: string, value: string) => {
    const updated = mediaFiles.map((media, i) => 
      i === index ? { ...media, [field]: value } : media
    );
    setMediaFiles(updated);
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir le nom",
        variant: "destructive"
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/coach", {
        ...formData,
        dateOfBirth: formData.dateOfBirth ? new Date(formData.dateOfBirth) : null,
        stats,
        achievements: achievements.filter(a => a.title),
        mediaFiles: mediaFiles.filter(m => m.title)
      });

      toast({
        title: "Profil créé !",
        description: "Votre profil entraîneur a été créé avec succès",
      });
      
      onComplete();
      navigate("/profile");
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la création",
        variant: "destructive"
      });
    }
  };

  const isFormValid = formData.name;

  const coachingAttributes = [
    { key: 'attacking', label: 'Travail Offensif' },
    { key: 'defending', label: 'Travail Défensif' },
    { key: 'mentalCoaching', label: 'Préparation Mentale' },
    { key: 'tacticalKnowledge', label: 'Connaissances Tactiques' },
    { key: 'technicalCoaching', label: 'Travail Technique' }
  ];

  const managementAttributes = [
    { key: 'manManagement', label: 'Gestion des Hommes' },
    { key: 'workingWithYoungsters', label: 'Travail avec les Jeunes' },
    { key: 'motivation', label: 'Capacité de Motivation' },
    { key: 'determination', label: 'Détermination' }
  ];

  const knowledgeAttributes = [
    { key: 'judgePlayerAbility', label: 'Évaluation des Joueurs' },
    { key: 'judgePlayerPotential', label: 'Évaluation du Potentiel' },
    { key: 'levelOfDiscipline', label: 'Niveau de Discipline' },
    { key: 'adaptability', label: 'Adaptabilité' }
  ];

  return (
    <div className="min-h-screen bg-fm-darker p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-purple-500 mb-2">Créer mon Profil Entraîneur</h1>
          <p className="text-white/70">Complétez les informations par catégories</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6 mb-8 gap-1">
            <TabsTrigger value="basics" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <User className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Infos</span>
            </TabsTrigger>
            <TabsTrigger value="coaching" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <BarChart3 className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Coaching</span>
            </TabsTrigger>
            <TabsTrigger value="management" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Brain className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Management</span>
            </TabsTrigger>
            <TabsTrigger value="philosophy" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <MessageSquare className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Philosophie</span>
            </TabsTrigger>
            <TabsTrigger value="palmares" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Trophy className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Palmarès</span>
            </TabsTrigger>
            <TabsTrigger value="media" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Target className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Média</span>
            </TabsTrigger>
          </TabsList>

          {/* Informations de base */}
          <TabsContent value="basics">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Informations de Base</CardTitle>
                <CardDescription className="text-white/60">
                  Informations personnelles
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white/60">Nom complet *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="bg-fm-dark border-purple-500/20 text-white"
                      placeholder="Votre nom complet"
                      data-testid="input-coach-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dateOfBirth" className="text-white/60">Date de naissance</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
                      className="bg-fm-dark border-purple-500/20 text-white"
                      data-testid="input-coach-birth"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nationality" className="text-white/60">Nationalité</Label>
                    <Input
                      id="nationality"
                      value={formData.nationality}
                      onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                      className="bg-fm-dark border-purple-500/20 text-white"
                      placeholder="France"
                      data-testid="input-coach-nationality"
                    />
                  </div>
                  <div>
                    <Label htmlFor="currentClub" className="text-white/60">Club actuel</Label>
                    <Input
                      id="currentClub"
                      value={formData.currentClub}
                      onChange={(e) => setFormData({...formData, currentClub: e.target.value})}
                      className="bg-fm-dark border-purple-500/20 text-white"
                      placeholder="Ex: PSG, Real Madrid, Sans club..."
                      data-testid="input-coach-club"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="biography" className="text-white/60">Biographie</Label>
                  <Textarea
                    id="biography"
                    value={formData.biography}
                    onChange={(e) => setFormData({...formData, biography: e.target.value})}
                    className="bg-fm-dark border-purple-500/20 text-white min-h-[120px]"
                    placeholder="Parlez de votre parcours d'entraîneur..."
                    data-testid="textarea-coach-biography"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats de Coaching */}
          <TabsContent value="coaching">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Compétences de Coaching</CardTitle>
                <CardDescription className="text-white/60">
                  Évaluez vos compétences techniques (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {coachingAttributes.map(({ key, label }) => (
                    <StatSlider
                      key={key}
                      label={label}
                      value={stats[key as keyof typeof stats]}
                      onChange={(newValue) => setStats({
                        ...stats,
                        [key]: newValue
                      })}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stats de Management */}
          <TabsContent value="management">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Compétences Managériales</CardTitle>
                <CardDescription className="text-white/60">
                  Compétences en management et connaissances (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Management</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {managementAttributes.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Connaissances</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {knowledgeAttributes.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Philosophie */}
          <TabsContent value="philosophy">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Philosophie & Vision</CardTitle>
                <CardDescription className="text-white/60">
                  Votre approche du coaching
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="philosophy" className="text-white/60">Philosophie de jeu</Label>
                  <Textarea
                    id="philosophy"
                    value={formData.philosophy}
                    onChange={(e) => setFormData({...formData, philosophy: e.target.value})}
                    className="bg-fm-dark border-purple-500/20 text-white min-h-[120px]"
                    placeholder="Décrivez votre philosophie de jeu, votre style d'entraînement..."
                    data-testid="textarea-coach-philosophy"
                  />
                </div>
                <div>
                  <Label htmlFor="strengths" className="text-white/60">Points forts</Label>
                  <Textarea
                    id="strengths"
                    value={formData.strengths}
                    onChange={(e) => setFormData({...formData, strengths: e.target.value})}
                    className="bg-fm-dark border-purple-500/20 text-white min-h-[120px]"
                    placeholder="Vos principales forces en tant qu'entraîneur..."
                    data-testid="textarea-coach-strengths"
                  />
                </div>
                <div>
                  <Label htmlFor="developmentAreas" className="text-white/60">Axes de progression</Label>
                  <Textarea
                    id="developmentAreas"
                    value={formData.developmentAreas}
                    onChange={(e) => setFormData({...formData, developmentAreas: e.target.value})}
                    className="bg-fm-dark border-purple-500/20 text-white min-h-[120px]"
                    placeholder="Les domaines sur lesquels vous travaillez pour vous améliorer..."
                    data-testid="textarea-coach-development"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Palmarès */}
          <TabsContent value="palmares">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Palmarès d'Entraîneur</CardTitle>
                <CardDescription className="text-white/60">
                  Trophées et succès remportés
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-purple-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={achievement.title}
                          onChange={(e) => updateAchievement(index, "title", e.target.value)}
                          className="bg-fm-darker border-purple-500/20 text-white"
                          placeholder="Ex: Champion Régional"
                          data-testid={`input-coach-achievement-title-${index}`}
                        />
                      </div>
                      <div>
                        <Label className="text-white/60">Année</Label>
                        <Input
                          type="number"
                          min="1990"
                          max="2024"
                          value={achievement.year}
                          onChange={(e) => updateAchievement(index, "year", e.target.value)}
                          className="bg-fm-darker border-purple-500/20 text-white"
                          placeholder="2023"
                          data-testid={`input-coach-achievement-year-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeAchievement(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={achievement.description}
                        onChange={(e) => updateAchievement(index, "description", e.target.value)}
                        className="bg-fm-darker border-purple-500/20 text-white"
                        placeholder="Détails sur ce succès..."
                        data-testid={`textarea-coach-achievement-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addAchievement}
                  variant="outline"
                  className="w-full border-purple-500/20 text-purple-500 hover:bg-purple-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un trophée
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Média */}
          <TabsContent value="media">
            <Card className="bg-fm-card border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-500">Photos & Vidéos</CardTitle>
                <CardDescription className="text-white/60">
                  Moments forts et séances d'entraînement
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mediaFiles.map((media, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-purple-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={media.title}
                          onChange={(e) => updateMediaFile(index, "title", e.target.value)}
                          className="bg-fm-darker border-purple-500/20 text-white"
                          placeholder="Ex: Séance tactique"
                          data-testid={`input-coach-media-title-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeMediaFile(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={media.description}
                        onChange={(e) => updateMediaFile(index, "description", e.target.value)}
                        className="bg-fm-darker border-purple-500/20 text-white"
                        placeholder="Contexte de cette photo/vidéo..."
                        data-testid={`textarea-coach-media-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addMediaFile}
                  variant="outline"
                  className="w-full border-purple-500/20 text-purple-500 hover:bg-purple-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un média
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Boutons de navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="text-white border-white/20"
          >
            Annuler
          </Button>
          
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-blue-500 hover:to-purple-500"
            data-testid="button-create-coach-profile"
          >
            Créer mon profil
          </Button>
        </div>
      </div>
    </div>
  );
}