import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Building2, BarChart3, Trophy, MessageSquare, Target, Camera, Plus, Trash2
} from "lucide-react";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { StatSlider } from "./StatSlider";

interface ClubOnboardingProps {
  onComplete: () => void;
}

export default function ClubOnboarding({ onComplete }: ClubOnboardingProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("basics");
  
  const [formData, setFormData] = useState({
    name: "",
    foundedYear: "",
    country: "",
    city: "",
    stadium: "",
    stadiumCapacity: "",
    numberOfTeams: "",
    colors: "",
    website: "",
    description: "",
    strengths: "",
    developmentAreas: ""
  });

  const [stats, setStats] = useState({
    // Infrastructure
    infrastructure: 10,
    trainingFacilities: 10,
    youthAcademy: 10,
    
    // Gestion
    finances: 10,
    commercialAppeal: 10,
    businessManagement: 10,
    
    // Sportif
    scouting: 10,
    medicalStaff: 10,
    technicalStaff: 10,
    
    // Communauté
    supporters: 10,
    stadiumAtmosphere: 10,
    mediaPresence: 10,
    
    // Vision
    youthDevelopment: 10,
    projectAmbition: 10,
    internationalReputation: 10
  });

  const [achievements, setAchievements] = useState([
    { title: "", description: "", year: "", type: "championship" }
  ]);

  const [mediaFiles, setMediaFiles] = useState([
    { title: "", description: "", type: "image" }
  ]);

  const addAchievement = () => {
    setAchievements([...achievements, { title: "", description: "", year: "", type: "championship" }]);
  };

  const removeAchievement = (index: number) => {
    setAchievements(achievements.filter((_, i) => i !== index));
  };

  const updateAchievement = (index: number, field: string, value: string) => {
    const updated = achievements.map((achievement, i) => 
      i === index ? { ...achievement, [field]: value } : achievement
    );
    setAchievements(updated);
  };

  const addMediaFile = () => {
    setMediaFiles([...mediaFiles, { title: "", description: "", type: "image" }]);
  };

  const removeMediaFile = (index: number) => {
    setMediaFiles(mediaFiles.filter((_, i) => i !== index));
  };

  const updateMediaFile = (index: number, field: string, value: string) => {
    const updated = mediaFiles.map((media, i) => 
      i === index ? { ...media, [field]: value } : media
    );
    setMediaFiles(updated);
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir le nom du club",
        variant: "destructive"
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/club", {
        ...formData,
        foundedYear: formData.foundedYear ? parseInt(formData.foundedYear) : null,
        stadiumCapacity: formData.stadiumCapacity ? parseInt(formData.stadiumCapacity) : null,
        numberOfTeams: formData.numberOfTeams ? parseInt(formData.numberOfTeams) : null,
        stats,
        achievements: achievements.filter(a => a.title),
        mediaFiles: mediaFiles.filter(m => m.title)
      });

      toast({
        title: "Profil créé !",
        description: "Votre profil club a été créé avec succès",
      });
      
      onComplete();
      navigate("/profile");
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Erreur lors de la création",
        variant: "destructive"
      });
    }
  };

  const isFormValid = formData.name;

  const infrastructureStats = [
    { key: 'infrastructure', label: 'Qualité des Installations' },
    { key: 'trainingFacilities', label: 'Centre d\'Entraînement' },
    { key: 'youthAcademy', label: 'Centre de Formation' }
  ];

  const managementStats = [
    { key: 'finances', label: 'Santé Financière' },
    { key: 'commercialAppeal', label: 'Attractivité Commerciale' },
    { key: 'businessManagement', label: 'Gestion d\'Entreprise' }
  ];

  const sportingStats = [
    { key: 'scouting', label: 'Réseau de Recrutement' },
    { key: 'medicalStaff', label: 'Staff Médical' },
    { key: 'technicalStaff', label: 'Staff Technique' }
  ];

  const communityStats = [
    { key: 'supporters', label: 'Base de Supporters' },
    { key: 'stadiumAtmosphere', label: 'Ambiance au Stade' },
    { key: 'mediaPresence', label: 'Présence Médiatique' }
  ];

  const visionStats = [
    { key: 'youthDevelopment', label: 'Développement des Jeunes' },
    { key: 'projectAmbition', label: 'Ambition du Projet' },
    { key: 'internationalReputation', label: 'Réputation Internationale' }
  ];

  return (
    <div className="min-h-screen bg-fm-darker p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-blue-500 mb-2">Créer mon Profil Club</h1>
          <p className="text-white/70">Complétez les informations par catégories</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6 mb-8 gap-1">
            <TabsTrigger value="basics" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Building2 className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Infos</span>
            </TabsTrigger>
            <TabsTrigger value="infrastructure" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <BarChart3 className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Structure</span>
            </TabsTrigger>
            <TabsTrigger value="management" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Target className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Gestion</span>
            </TabsTrigger>
            <TabsTrigger value="vision" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <MessageSquare className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Vision</span>
            </TabsTrigger>
            <TabsTrigger value="palmares" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Trophy className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Palmarès</span>
            </TabsTrigger>
            <TabsTrigger value="media" className="flex items-center justify-center gap-1 px-2 py-1.5">
              <Camera className="w-4 h-4 flex-shrink-0" />
              <span className="hidden lg:inline text-xs">Média</span>
            </TabsTrigger>
          </TabsList>

          {/* Informations de base */}
          <TabsContent value="basics">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Informations de Base</CardTitle>
                <CardDescription className="text-white/60">
                  Informations générales du club
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white/60">Nom du club *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="Nom du club"
                      data-testid="input-club-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="foundedYear" className="text-white/60">Année de fondation</Label>
                    <Input
                      id="foundedYear"
                      type="number"
                      min="1800"
                      max="2024"
                      value={formData.foundedYear}
                      onChange={(e) => setFormData({...formData, foundedYear: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="1900"
                      data-testid="input-club-founded"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="country" className="text-white/60">Pays</Label>
                    <Input
                      id="country"
                      value={formData.country}
                      onChange={(e) => setFormData({...formData, country: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="France"
                      data-testid="input-club-country"
                    />
                  </div>
                  <div>
                    <Label htmlFor="city" className="text-white/60">Ville</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="Paris"
                      data-testid="input-club-city"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="stadium" className="text-white/60">Stade</Label>
                    <Input
                      id="stadium"
                      value={formData.stadium}
                      onChange={(e) => setFormData({...formData, stadium: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="Nom du stade"
                      data-testid="input-club-stadium"
                    />
                  </div>
                  <div>
                    <Label htmlFor="stadiumCapacity" className="text-white/60">Capacité du stade</Label>
                    <Input
                      id="stadiumCapacity"
                      type="number"
                      min="0"
                      value={formData.stadiumCapacity}
                      onChange={(e) => setFormData({...formData, stadiumCapacity: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="50000"
                      data-testid="input-club-capacity"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="numberOfTeams" className="text-white/60">Nombre d'équipes</Label>
                    <Input
                      id="numberOfTeams"
                      type="number"
                      min="1"
                      value={formData.numberOfTeams}
                      onChange={(e) => setFormData({...formData, numberOfTeams: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="3"
                      data-testid="input-club-teams"
                    />
                  </div>
                  <div>
                    <Label htmlFor="colors" className="text-white/60">Couleurs du club</Label>
                    <Input
                      id="colors"
                      value={formData.colors}
                      onChange={(e) => setFormData({...formData, colors: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="Bleu et Blanc"
                      data-testid="input-club-colors"
                    />
                  </div>
                  <div>
                    <Label htmlFor="website" className="text-white/60">Site web</Label>
                    <Input
                      id="website"
                      value={formData.website}
                      onChange={(e) => setFormData({...formData, website: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white"
                      placeholder="https://www.club.com"
                      data-testid="input-club-website"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description" className="text-white/60">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="bg-fm-dark border-blue-500/20 text-white min-h-[120px]"
                    placeholder="Histoire et présentation du club..."
                    data-testid="textarea-club-description"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="strengths" className="text-white/60">Points Forts</Label>
                    <Textarea
                      id="strengths"
                      value={formData.strengths}
                      onChange={(e) => setFormData({...formData, strengths: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white min-h-[100px]"
                      placeholder="Infrastructure moderne, centre de formation, supporters fidèles..."
                      data-testid="textarea-club-strengths"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="developmentAreas" className="text-white/60">Axes de Développement</Label>
                    <Textarea
                      id="developmentAreas"
                      value={formData.developmentAreas}
                      onChange={(e) => setFormData({...formData, developmentAreas: e.target.value})}
                      className="bg-fm-dark border-blue-500/20 text-white min-h-[100px]"
                      placeholder="Développement international, modernisation du stade, recrutement..."
                      data-testid="textarea-club-development"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Infrastructure */}
          <TabsContent value="infrastructure">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Infrastructure & Sportif</CardTitle>
                <CardDescription className="text-white/60">
                  Qualité des installations et staff (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Infrastructure</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {infrastructureStats.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Aspect Sportif</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {sportingStats.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Management */}
          <TabsContent value="management">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Gestion & Communauté</CardTitle>
                <CardDescription className="text-white/60">
                  Aspects financiers et communautaires (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Gestion</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {managementStats.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">Communauté</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {communityStats.map(({ key, label }) => (
                        <StatSlider
                          key={key}
                          label={label}
                          value={stats[key as keyof typeof stats]}
                          onChange={(newValue) => setStats({
                            ...stats,
                            [key]: newValue
                          })}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vision */}
          <TabsContent value="vision">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Vision & Ambitions</CardTitle>
                <CardDescription className="text-white/60">
                  Projet et réputation du club (1-20)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {visionStats.map(({ key, label }) => (
                    <StatSlider
                      key={key}
                      label={label}
                      value={stats[key as keyof typeof stats]}
                      onChange={(newValue) => setStats({
                        ...stats,
                        [key]: newValue
                      })}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Palmarès */}
          <TabsContent value="palmares">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Palmarès du Club</CardTitle>
                <CardDescription className="text-white/60">
                  Trophées et titres remportés
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-blue-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={achievement.title}
                          onChange={(e) => updateAchievement(index, "title", e.target.value)}
                          className="bg-fm-darker border-blue-500/20 text-white"
                          placeholder="Ex: Champion Régional"
                          data-testid={`input-club-achievement-title-${index}`}
                        />
                      </div>
                      <div>
                        <Label className="text-white/60">Année</Label>
                        <Input
                          type="number"
                          min="1990"
                          max="2024"
                          value={achievement.year}
                          onChange={(e) => updateAchievement(index, "year", e.target.value)}
                          className="bg-fm-darker border-blue-500/20 text-white"
                          placeholder="2023"
                          data-testid={`input-club-achievement-year-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeAchievement(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={achievement.description}
                        onChange={(e) => updateAchievement(index, "description", e.target.value)}
                        className="bg-fm-darker border-blue-500/20 text-white"
                        placeholder="Détails sur ce titre..."
                        data-testid={`textarea-club-achievement-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addAchievement}
                  variant="outline"
                  className="w-full border-blue-500/20 text-blue-500 hover:bg-blue-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un trophée
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Média */}
          <TabsContent value="media">
            <Card className="bg-fm-card border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-blue-500">Photos & Vidéos</CardTitle>
                <CardDescription className="text-white/60">
                  Images du club et moments forts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mediaFiles.map((media, index) => (
                  <div key={index} className="p-4 bg-fm-dark rounded-lg border border-blue-500/20">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white/60">Titre *</Label>
                        <Input
                          value={media.title}
                          onChange={(e) => updateMediaFile(index, "title", e.target.value)}
                          className="bg-fm-darker border-blue-500/20 text-white"
                          placeholder="Ex: Notre stade"
                          data-testid={`input-club-media-title-${index}`}
                        />
                      </div>
                      <div className="flex items-end">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeMediaFile(index)}
                          className="border-red-500/20 text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-white/60">Description</Label>
                      <Textarea
                        value={media.description}
                        onChange={(e) => updateMediaFile(index, "description", e.target.value)}
                        className="bg-fm-darker border-blue-500/20 text-white"
                        placeholder="Description de cette image/vidéo..."
                        data-testid={`textarea-club-media-desc-${index}`}
                      />
                    </div>
                  </div>
                ))}
                <Button
                  onClick={addMediaFile}
                  variant="outline"
                  className="w-full border-blue-500/20 text-blue-500 hover:bg-blue-500/10"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un média
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Boutons de navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="text-white border-white/20"
          >
            Annuler
          </Button>
          
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-green-500 hover:to-blue-500"
            data-testid="button-create-club-profile"
          >
            Créer mon profil
          </Button>
        </div>
      </div>
    </div>
  );
}