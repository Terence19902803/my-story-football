import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Star, Menu, User, Trophy, TrendingUp, CreditCard, FileText, Shield, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Header() {
  const { user, isAuthenticated } = useAuth() as any;
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigation = [
    { name: "Accueil", href: "/", icon: Star },
    { name: "Mon Profil", href: "/profile", icon: User, authRequired: true },
    { name: "Classements", href: "/rankings", icon: Trophy },
  ];

  const filteredNavigation = navigation.filter(item => 
    !item.authRequired || isAuthenticated
  );

  const NavLink = ({ item, mobile = false }: { item: any; mobile?: boolean }) => (
    <Link href={item.href}>
      <a 
        className={`${
          mobile ? 'flex items-center gap-3 px-3 py-2 rounded-lg' : ''
        } text-foreground hover:text-fm-gold transition-colors ${
          location === item.href ? 'text-fm-gold' : ''
        }`}
        onClick={() => mobile && setIsMobileMenuOpen(false)}
        data-testid={`nav-link-${item.name.toLowerCase().replace(' ', '-')}`}
      >
        {mobile && <item.icon className="w-5 h-5" />}
        {item.name}
      </a>
    </Link>
  );

  // Masquer le header pour les utilisateurs authentifiés (navigation mobile native)
  if (isAuthenticated) {
    return null;
  }

  return (
    <header className="sticky top-0 z-50 fm-mobile-header safe-area-top" data-testid="header">
      <div className="container mx-auto px-4 py-3">
        <nav className="flex items-center justify-center">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center" data-testid="logo">
              <img 
                src="/logo-msf.png" 
                alt="My Story Football" 
                className="h-10 w-auto brightness-0 invert"
              />
            </a>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {filteredNavigation.map((item) => (
              <NavLink key={item.name} item={item} />
            ))}
          </div>
          
          {/* Desktop Auth */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="user-menu">
                    <Avatar className="h-10 w-10 border-2 border-fm-gold">
                      <AvatarImage src={user?.profileImageUrl} alt="Profile" />
                      <AvatarFallback className="bg-fm-gold text-fm-dark">
                        {user?.firstName?.charAt(0) || user?.email?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-card border-border" align="end">
                  <div className="flex items-center justify-start gap-2 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                      <p className="font-medium text-white" data-testid="user-name">
                        {user?.firstName} {user?.lastName}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid="user-email">
                        {user?.email}
                      </p>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <a className="flex items-center gap-2 w-full" data-testid="menu-profile">
                        <User className="w-4 h-4" />
                        Mon Profil
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/rankings">
                      <a className="flex items-center gap-2 w-full" data-testid="menu-rankings">
                        <TrendingUp className="w-4 h-4" />
                        Classements
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/legal">
                      <a className="flex items-center gap-2 w-full" data-testid="menu-legal">
                        <FileText className="w-4 h-4" />
                        Mentions légales
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/privacy">
                      <a className="flex items-center gap-2 w-full" data-testid="menu-privacy">
                        <Shield className="w-4 h-4" />
                        Confidentialité
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a 
                      href="/api/logout" 
                      className="flex items-center gap-2 w-full text-red-500 hover:text-red-400"
                      data-testid="menu-logout"
                    >
                      <LogOut className="w-4 h-4" />
                      Déconnexion
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button 
                  variant="ghost" 
                  asChild
                  data-testid="button-login"
                >
                  <a href="/api/login">Connexion</a>
                </Button>
                <Button 
                  className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-black font-semibold"
                  asChild
                  data-testid="button-create-profile"
                >
                  <a href="/api/login">Créer mon profil</a>
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" data-testid="mobile-menu-trigger">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-card border-border">
                <div className="flex flex-col space-y-4 mt-8">
                  {/* User Info */}
                  {isAuthenticated && (
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-fm-gold/10 border border-fm-gold/20">
                      <Avatar className="h-10 w-10 border-2 border-fm-gold">
                        <AvatarImage src={user.profileImageUrl} alt="Profile" />
                        <AvatarFallback className="bg-fm-gold text-fm-dark">
                          {user.firstName?.charAt(0) || user.email?.charAt(0) || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-white text-sm">
                          {user.firstName} {user.lastName}
                        </p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                  )}

                  {/* Navigation */}
                  <div className="space-y-2">
                    {filteredNavigation.map((item) => (
                      <NavLink key={item.name} item={item} mobile />
                    ))}
                  </div>

                  {/* Auth Actions */}
                  {isAuthenticated ? (
                    <div className="space-y-2 pt-4 border-t border-border">
                      <Link href="/legal">
                        <a 
                          className="flex items-center gap-3 px-3 py-2 rounded-lg text-foreground hover:text-fm-gold transition-colors"
                          onClick={() => setIsMobileMenuOpen(false)}
                          data-testid="mobile-link-legal"
                        >
                          <FileText className="w-5 h-5" />
                          Mentions légales
                        </a>
                      </Link>
                      <Link href="/privacy">
                        <a 
                          className="flex items-center gap-3 px-3 py-2 rounded-lg text-foreground hover:text-fm-gold transition-colors"
                          onClick={() => setIsMobileMenuOpen(false)}
                          data-testid="mobile-link-privacy"
                        >
                          <Shield className="w-5 h-5" />
                          Confidentialité
                        </a>
                      </Link>
                      <a 
                        href="/api/logout"
                        className="flex items-center gap-3 px-3 py-2 rounded-lg text-red-500 hover:text-red-400 transition-colors"
                        data-testid="mobile-link-logout"
                      >
                        <LogOut className="w-5 h-5" />
                        Déconnexion
                      </a>
                    </div>
                  ) : (
                    <div className="space-y-2 pt-4 border-t border-border">
                      <Button 
                        variant="outline" 
                        className="w-full border-fm-gold text-fm-gold hover:bg-fm-gold hover:text-fm-dark"
                        asChild
                        data-testid="mobile-button-login"
                      >
                        <a href="/api/login">Connexion</a>
                      </Button>
                      <Button 
                        className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white"
                        asChild
                        data-testid="mobile-button-create-profile"
                      >
                        <a href="/api/login">Créer mon profil</a>
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>
    </header>
  );
}
