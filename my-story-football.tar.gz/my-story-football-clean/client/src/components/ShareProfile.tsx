import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Share2, Copy, MessageCircle, Twitter, Facebook, Link } from "lucide-react";

interface ShareProfileProps {
  profileId: string;
  playerName: string;
}

export default function ShareProfile({ profileId, playerName }: ShareProfileProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  
  const profileUrl = `${window.location.origin}/profile/${profileId}`;
  const shareText = `Découvrez mon profil FootManager IRL : ${playerName}`;
  
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(profileUrl);
      toast({
        title: "Lien copié !",
        description: "Le lien du profil a été copié dans le presse-papiers",
      });
    } catch (err) {
      toast({
        title: "Erreur",
        description: "Impossible de copier le lien",
        variant: "destructive",
      });
    }
  };
  
  const shareOnWhatsApp = () => {
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText + " " + profileUrl)}`, "_blank");
  };
  
  const shareOnTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(profileUrl)}`, "_blank");
  };
  
  const shareOnFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(profileUrl)}`, "_blank");
  };
  
  return (
    <>
      <Button 
        onClick={() => setOpen(true)}
        className="fm-button fm-button-gold"
        data-testid="button-share-profile"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Partager mon profil
      </Button>
      
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="fm-card max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bebas text-fm-gold">
              PARTAGER MON PROFIL
            </DialogTitle>
            <DialogDescription>
              Partagez votre profil avec vos contacts et sur les réseaux sociaux
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-400 text-sm">Lien du profil</Label>
              <div className="flex gap-2 mt-2">
                <Input 
                  value={profileUrl} 
                  readOnly 
                  className="bg-fm-card border-gray-700 text-white"
                  data-testid="input-profile-url"
                />
                <Button
                  onClick={copyToClipboard}
                  className="fm-button"
                  data-testid="button-copy-link"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <Label className="text-gray-400 text-sm mb-3 block">Partager sur</Label>
              <div className="grid grid-cols-3 gap-3">
                <Button
                  onClick={shareOnWhatsApp}
                  className="fm-button bg-green-600 hover:bg-green-700"
                  data-testid="button-share-whatsapp"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="sr-only">WhatsApp</span>
                </Button>
                
                <Button
                  onClick={shareOnTwitter}
                  className="fm-button bg-blue-500 hover:bg-blue-600"
                  data-testid="button-share-twitter"
                >
                  <Twitter className="w-5 h-5" />
                  <span className="sr-only">Twitter</span>
                </Button>
                
                <Button
                  onClick={shareOnFacebook}
                  className="fm-button bg-blue-700 hover:bg-blue-800"
                  data-testid="button-share-facebook"
                >
                  <Facebook className="w-5 h-5" />
                  <span className="sr-only">Facebook</span>
                </Button>
              </div>
            </div>
            
            <div className="pt-2">
              <Button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: `Profil de ${playerName}`,
                      text: shareText,
                      url: profileUrl,
                    }).catch(() => {});
                  }
                }}
                className="fm-button fm-button-gold w-full"
                data-testid="button-native-share"
              >
                <Link className="w-4 h-4 mr-2" />
                Autres options de partage
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}