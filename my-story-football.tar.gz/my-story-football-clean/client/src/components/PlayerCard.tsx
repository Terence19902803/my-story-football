import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MapPin, Users, Calendar } from "lucide-react";

interface PlayerCardProps {
  player: {
    id: string;
    name: string;
    currentClub?: string;
    nationality?: string;
    position?: string;
    totalLikes: number;
    profileImagePath?: string;
    dateOfBirth?: string;
  };
  rank: number;
}

export default function PlayerCard({ player, rank }: PlayerCardProps) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  const likeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/like-player/${player.id}`);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/rankings/players"] });
      toast({
        title: data.liked ? "Joueur liké !" : "Like retiré",
        description: data.liked ? "Vous avez liké ce joueur" : "Vous avez retiré votre like",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Connexion requise",
          description: "Vous devez être connecté pour liker un joueur",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erreur",
        description: "Impossible de liker ce joueur",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    if (!isAuthenticated) {
      toast({
        title: "Connexion requise",
        description: "Vous devez être connecté pour liker un joueur",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
    likeMutation.mutate();
  };

  const getAge = (dateOfBirth?: string) => {
    if (!dateOfBirth) return null;
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <Card 
      className="bg-card border-border hover:border-fm-gold/50 transition-all group"
      data-testid={`player-card-${rank}`}
    >
      <CardContent className="p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className={`text-2xl font-bold ${rank <= 3 ? 'text-fm-gold' : 'text-muted-foreground'}`} data-testid={`rank-${rank}`}>
            #{rank}
          </div>
          <Avatar className={`w-12 h-12 border-2 ${rank === 1 ? 'border-fm-gold' : 'border-muted'}`} data-testid={`avatar-${rank}`}>
            <AvatarImage src={player.profileImagePath} alt={player.name} />
            <AvatarFallback className="bg-fm-gold text-fm-dark">
              {player.name?.charAt(0) || "P"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-white truncate" data-testid={`name-${rank}`}>
              {player.name}
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              {player.currentClub && (
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span data-testid={`club-${rank}`}>{player.currentClub}</span>
                </div>
              )}
              {player.nationality && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  <span data-testid={`nationality-${rank}`}>{player.nationality}</span>
                </div>
              )}
              {getAge(player.dateOfBirth) && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  <span data-testid={`age-${rank}`}>{getAge(player.dateOfBirth)} ans</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          {player.position && (
            <Badge variant="outline" className="border-fm-gold/30 text-fm-gold" data-testid={`position-${rank}`}>
              {player.position}
            </Badge>
          )}
          
          <div className="flex items-center gap-4">
            <div className="text-center">
              <div className="text-lg font-bold text-white" data-testid={`likes-${rank}`}>
                {player.totalLikes || 0}
              </div>
              <div className="text-xs text-muted-foreground">Likes</div>
            </div>
            
            <Button 
              size="sm" 
              variant="outline"
              className="border-fm-green text-fm-green hover:bg-fm-green hover:text-white"
              onClick={handleLike}
              disabled={likeMutation.isPending}
              data-testid={`like-button-${rank}`}
            >
              <Heart className={`w-4 h-4 mr-1 ${likeMutation.isPending ? 'animate-pulse' : ''}`} />
              {likeMutation.isPending ? "..." : "Liker"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
