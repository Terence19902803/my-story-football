import { useEffect, useState } from "react";
import { Trophy } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [animationStep, setAnimationStep] = useState(0);

  useEffect(() => {
    const steps = [
      () => setAnimationStep(1), // Logo appear
      () => setAnimationStep(2), // Pulsing 
      () => setAnimationStep(3), // Final
      () => {
        setIsVisible(false);
        setTimeout(onComplete, 100); // Délai pour l'animation de sortie
      }
    ];

    const timeouts = [
      setTimeout(steps[0], 50),
      setTimeout(steps[1], 300), 
      setTimeout(steps[2], 600),
      setTimeout(steps[3], 800)
    ];

    return () => {
      timeouts.forEach(clearTimeout);
    };
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div className={`
      fixed inset-0 z-[9999] flex items-center justify-center
      bg-gradient-to-br from-fm-darker via-fm-dark to-fm-card
      transition-all duration-300
      ${!isVisible ? 'opacity-0 scale-110' : 'opacity-100 scale-100'}
    `}>
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-fm-gold/5 to-transparent animate-pulse" />
      
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-fm-gold/10 to-transparent rotate-12 animate-spin-slow" />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-purple-500/10 to-transparent -rotate-12 animate-spin-slow" style={{ animationDelay: '1s' }} />
      </div>

      {/* Main Content */}
      <div className="relative flex flex-col items-center space-y-8">
        {/* Logo Container */}
        <div className={`
          relative transition-all duration-1000 ease-out
          ${animationStep >= 1 
            ? 'opacity-100 scale-100 translate-y-0' 
            : 'opacity-0 scale-50 translate-y-10'
          }
        `}>
          <div className={`
            relative p-8 rounded-3xl 
            bg-gradient-to-br from-fm-gold/20 to-purple-500/20
            backdrop-blur-xl border border-fm-gold/30
            shadow-2xl shadow-fm-gold/20
            transition-all duration-1000
            ${animationStep >= 2 
              ? 'shadow-3xl shadow-fm-gold/40 scale-110' 
              : ''
            }
          `}>
            {/* Pulsing Ring */}
            <div className={`
              absolute inset-0 rounded-3xl border-2 border-fm-gold
              transition-all duration-2000
              ${animationStep >= 2 
                ? 'animate-ping opacity-75' 
                : 'opacity-0'
              }
            `} />
            
            {/* Logo Icon */}
            <img 
              src="/logo-msf.png" 
              alt="My Story Football" 
              className={`
                h-20 w-auto brightness-0 invert
                transition-all duration-1000
                ${animationStep >= 2 
                  ? 'animate-pulse drop-shadow-2xl' 
                  : ''
                }
              `}
            />
            
            {/* Sparkle Effects */}
            <div className={`
              absolute -top-2 -right-2 w-4 h-4 bg-fm-gold rounded-full
              transition-all duration-500
              ${animationStep >= 2 ? 'animate-bounce' : 'opacity-0'}
            `} style={{ animationDelay: '0.2s' }} />
            <div className={`
              absolute -bottom-2 -left-2 w-3 h-3 bg-purple-400 rounded-full
              transition-all duration-500
              ${animationStep >= 2 ? 'animate-bounce' : 'opacity-0'}
            `} style={{ animationDelay: '0.4s' }} />
          </div>
        </div>

        {/* App Name */}
        <div className={`
          text-center space-y-2
          transition-all duration-1000 ease-out delay-300
          ${animationStep >= 1 
            ? 'opacity-100 translate-y-0' 
            : 'opacity-0 translate-y-5'
          }
        `}>
          <h1 className="text-4xl font-bebas tracking-wider text-white">
            MY STORY
            <span className="text-fm-gold ml-2 drop-shadow-lg">FOOTBALL</span>
          </h1>
          <p className="text-gray-300 text-lg font-light">
            Votre carrière football
          </p>
        </div>

        {/* Loading Indicator */}
        <div className={`
          transition-all duration-500 delay-700
          ${animationStep >= 2 
            ? 'opacity-100' 
            : 'opacity-0'
          }
        `}>
          <div className="flex space-x-2">
            <div className="w-2 h-2 bg-fm-gold rounded-full animate-bounce" />
            <div className="w-2 h-2 bg-fm-gold rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
            <div className="w-2 h-2 bg-fm-gold rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
          </div>
        </div>

        {/* Version */}
        <div className={`
          absolute bottom-8 text-xs text-gray-500
          transition-all duration-500 delay-1000
          ${animationStep >= 3 
            ? 'opacity-100' 
            : 'opacity-0'
          }
        `}>
          v2.0 - Business Edition
        </div>
      </div>
    </div>
  );
}