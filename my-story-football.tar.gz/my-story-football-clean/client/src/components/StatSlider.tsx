import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";

interface StatSliderProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  disabled?: boolean;
}

export function StatSlider({
  label,
  value,
  onChange,
  min = 1,
  max = 20,
  disabled = false,
}: StatSliderProps) {
  const handleDecrease = () => {
    if (value > min) {
      onChange(value - 1);
    }
  };

  const handleIncrease = () => {
    if (value < max) {
      onChange(value + 1);
    }
  };

  const percentage = ((value - min) / (max - min)) * 100;
  
  // Couleur basée sur la valeur
  const getColor = () => {
    if (value <= 7) return "bg-red-500";
    if (value <= 13) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-sm font-medium text-gray-300">
          {label}
        </label>
        <span className="text-lg font-bold text-white">{value}</span>
      </div>
      
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-8 w-8 rounded-full bg-fm-card border-gray-700 hover:bg-red-500/20 hover:border-red-500"
          onClick={handleDecrease}
          disabled={disabled || value <= min}
          data-testid={`button-decrease-${label.toLowerCase().replace(/\s+/g, '-')}`}
        >
          <Minus className="h-4 w-4" />
        </Button>

        <div className="flex-1 relative">
          {/* Barre de progression visuelle */}
          <div className="h-10 bg-gray-800 rounded-lg overflow-hidden relative">
            <div 
              className={`h-full transition-all duration-200 ${getColor()}`}
              style={{ width: `${percentage}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-white font-bold text-lg drop-shadow-lg">
                {value}
              </span>
            </div>
          </div>
        </div>

        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-8 w-8 rounded-full bg-fm-card border-gray-700 hover:bg-green-500/20 hover:border-green-500"
          onClick={handleIncrease}
          disabled={disabled || value >= max}
          data-testid={`button-increase-${label.toLowerCase().replace(/\s+/g, '-')}`}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}