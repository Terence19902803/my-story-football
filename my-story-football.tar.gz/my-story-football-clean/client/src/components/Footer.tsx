import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-fm-darker border-t border-white/10 mt-auto">
      <div className="container mx-auto px-4 py-8">
        {/* Main footer content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand section */}
          <div className="md:col-span-1">
            <h3 className="font-bebas text-2xl text-fm-gold mb-4">MY STORY FOOTBALL</h3>
            <p className="text-sm text-white/60 mb-4">
              "De l'amateur au pro, Montre qui tu es"
            </p>
            <p className="text-xs text-white/40">
              © {new Date().getFullYear()} Terence Desrues<br />
              Tous droits réservés
            </p>
          </div>

          {/* Legal links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Légal</h4>
            <div className="space-y-2">
              <Link href="/legal-notice">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Mentions légales
                </span>
              </Link>
              <Link href="/terms-of-service">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Conditions d'utilisation
                </span>
              </Link>
              <Link href="/privacy-policy">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Politique de confidentialité
                </span>
              </Link>
              <Link href="/cookie-policy">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Politique des cookies
                </span>
              </Link>
            </div>
          </div>

          {/* Community & Safety */}
          <div>
            <h4 className="font-semibold text-white mb-4">Communauté</h4>
            <div className="space-y-2">
              <Link href="/content-policy">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Règles de la communauté
                </span>
              </Link>
              <Link href="/age-policy">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Protection des mineurs
                </span>
              </Link>
              <Link href="/refund-policy">
                <span className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block">
                  Politique de remboursement
                </span>
              </Link>
              <a 
                href="mailto:contact@mystoryfootball.com" 
                className="text-sm text-white/60 hover:text-fm-gold transition-colors cursor-pointer block"
              >
                Nous contacter
              </a>
            </div>
          </div>

          {/* App Info */}
          <div>
            <h4 className="font-semibold text-white mb-4">Application</h4>
            <div className="space-y-2">
              <p className="text-sm text-white/60">Version 1.0.0</p>
              <p className="text-sm text-white/60">Progressive Web App</p>
              <p className="text-sm text-white/60">Compatible iOS/Android</p>
              <div className="pt-2">
                <span className="text-xs text-white/40">
                  Hébergé par Replit<br />
                  Paiements sécurisés par Stripe
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-white/10 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center text-xs text-white/40">
            <div className="mb-4 md:mb-0">
              <p>
                Application développée avec ❤️ pour la communauté football française
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Link href="/privacy-policy">
                <span className="hover:text-fm-gold transition-colors cursor-pointer">
                  Confidentialité
                </span>
              </Link>
              <Link href="/terms-of-service">
                <span className="hover:text-fm-gold transition-colors cursor-pointer">
                  CGU
                </span>
              </Link>
              <Link href="/content-policy">
                <span className="hover:text-fm-gold transition-colors cursor-pointer">
                  Règles
                </span>
              </Link>
            </div>
          </div>
        </div>

        {/* Emergency contact for minors */}
        <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4 mt-6">
          <div className="flex items-center gap-3">
            <div className="text-blue-400">🛡️</div>
            <div>
              <h5 className="text-sm font-semibold text-white">Protection des mineurs</h5>
              <p className="text-xs text-white/60">
                Signalement d'urgence : 
                <a 
                  href="mailto:urgence@mystoryfootball.com" 
                  className="text-blue-400 hover:text-blue-300 ml-1"
                >
                  urgence@mystoryfootball.com
                </a>
                {" "}• Numéro national : 3020
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}