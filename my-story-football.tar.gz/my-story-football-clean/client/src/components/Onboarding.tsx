import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  ChevronRight, ChevronLeft, User, BarChart3, Trophy, 
  Camera, CheckCircle2, Sparkles
} from "lucide-react";
import { useLocation } from "wouter";

interface OnboardingProps {
  onComplete: () => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [, navigate] = useLocation();

  const steps = [
    {
      icon: <Sparkles className="w-12 h-12 text-fm-gold mb-4" />,
      title: "Bienvenue sur FootManager IRL",
      description: "Créez votre profil de footballeur professionnel en quelques minutes",
      content: (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-fm-gold/20 to-transparent p-4 rounded-lg">
            <p className="text-white">✨ Profil complet style Football Manager</p>
          </div>
          <div className="bg-gradient-to-r from-green-500/20 to-transparent p-4 rounded-lg">
            <p className="text-white">📊 Statistiques sur 20 points</p>
          </div>
          <div className="bg-gradient-to-r from-blue-500/20 to-transparent p-4 rounded-lg">
            <p className="text-white">🏆 Historique de carrière détaillé</p>
          </div>
        </div>
      ),
      action: null
    },
    {
      icon: <User className="w-12 h-12 text-fm-gold mb-4" />,
      title: "Informations personnelles",
      description: "Commencez par vos informations de base",
      content: (
        <div className="space-y-4 text-center">
          <div className="p-8 bg-fm-card/50 rounded-2xl">
            <User className="w-20 h-20 text-fm-gold mx-auto mb-4" />
            <p className="text-gray-300">
              Renseignez votre nom, position, club actuel et biographie
            </p>
          </div>
        </div>
      ),
      action: "profile"
    },
    {
      icon: <BarChart3 className="w-12 h-12 text-fm-gold mb-4" />,
      title: "Vos statistiques FM",
      description: "Définissez vos attributs comme dans Football Manager",
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-fm-card/50 rounded-xl">
              <div className="text-2xl font-bold text-fm-gold">150</div>
              <div className="text-xs text-gray-400">Points technique</div>
            </div>
            <div className="text-center p-4 bg-fm-card/50 rounded-xl">
              <div className="text-2xl font-bold text-green-500">150</div>
              <div className="text-xs text-gray-400">Points mental</div>
            </div>
            <div className="text-center p-4 bg-fm-card/50 rounded-xl">
              <div className="text-2xl font-bold text-blue-500">150</div>
              <div className="text-xs text-gray-400">Points physique</div>
            </div>
          </div>
          <p className="text-center text-gray-300 text-sm">
            Répartissez vos points pour créer votre profil unique
          </p>
        </div>
      ),
      action: "stats"
    },
    {
      icon: <Trophy className="w-12 h-12 text-fm-gold mb-4" />,
      title: "Vos saisons",
      description: "Construisez votre palmarès",
      content: (
        <div className="space-y-4 text-center">
          <div className="p-6 bg-fm-card/50 rounded-2xl">
            <Trophy className="w-16 h-16 text-fm-gold mx-auto mb-4" />
            <p className="text-gray-300">
              Ajoutez vos clubs et performances saison par saison
            </p>
          </div>
        </div>
      ),
      action: "career"
    },
    {
      icon: <Camera className="w-12 h-12 text-fm-gold mb-4" />,
      title: "Photos et vidéos",
      description: "Montrez vos meilleurs moments",
      content: (
        <div className="space-y-4 text-center">
          <div className="p-6 bg-fm-card/50 rounded-2xl">
            <Camera className="w-16 h-16 text-fm-gold mx-auto mb-4" />
            <p className="text-gray-300">
              Uploadez photos et vidéos de vos exploits
            </p>
          </div>
        </div>
      ),
      action: "media"
    },
    {
      icon: <CheckCircle2 className="w-12 h-12 text-green-500 mb-4" />,
      title: "Profil créé !",
      description: "Votre profil FootManager IRL est prêt",
      content: (
        <div className="space-y-4 text-center">
          <div className="p-8 bg-gradient-to-br from-green-500/20 to-transparent rounded-2xl">
            <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-4 animate-pulse" />
            <p className="text-white font-semibold mb-2">Félicitations !</p>
            <p className="text-gray-300 text-sm">
              Votre profil est maintenant accessible et partageable
            </p>
          </div>
        </div>
      ),
      action: "complete"
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleAction = () => {
    const action = steps[currentStep].action;
    if (action === "profile") {
      navigate("/profile");
    } else if (action === "stats") {
      navigate("/profile");
    } else if (action === "career") {
      navigate("/profile");
    } else if (action === "media") {
      navigate("/profile");
    } else if (action === "complete") {
      onComplete();
      navigate("/home");
    } else {
      handleNext();
    }
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-lg z-50 flex items-center justify-center p-4">
      <Card className="fm-card max-w-2xl w-full mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
        <CardHeader>
          <Progress value={progress} className="mb-4 h-2" />
          <div className="flex justify-center">
            {steps[currentStep].icon}
          </div>
          <CardTitle className="text-2xl font-bold text-center text-white">
            {steps[currentStep].title}
          </CardTitle>
          <CardDescription className="text-center">
            {steps[currentStep].description}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {steps[currentStep].content}
          
          <div className="flex justify-between items-center pt-4">
            <Button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              variant="outline"
              className="fm-button"
              data-testid="button-previous"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Précédent
            </Button>
            
            <div className="flex gap-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentStep 
                      ? "w-8 bg-fm-gold" 
                      : index < currentStep 
                      ? "bg-green-500" 
                      : "bg-gray-600"
                  }`}
                />
              ))}
            </div>
            
            <Button
              onClick={steps[currentStep].action ? handleAction : handleNext}
              className="fm-button fm-button-gold"
              data-testid="button-next"
            >
              {steps[currentStep].action === "complete" ? (
                <>
                  Commencer
                  <Sparkles className="w-4 h-4 ml-2" />
                </>
              ) : steps[currentStep].action ? (
                <>
                  Configurer
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Suivant
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}