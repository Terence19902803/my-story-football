// Ligues disponibles pour l'historique de carrière
export const LEAGUES = {
  france: [
    { value: 'ligue1', label: 'Ligue 1', level: 1 },
    { value: 'ligue2', label: 'Ligue 2', level: 2 },
    { value: 'national', label: 'National', level: 3 },
    { value: 'national2', label: 'National 2', level: 4 },
    { value: 'national3', label: 'National 3', level: 5 },
    { value: 'r1', label: 'Régional 1', level: 6 },
    { value: 'r2', label: 'Régional 2', level: 7 },
    { value: 'r3', label: 'Régional 3', level: 8 },
    { value: 'd1', label: 'Départemental 1', level: 9 },
    { value: 'd2', label: 'Départemental 2', level: 10 },
    { value: 'd3', label: 'Départemental 3', level: 11 },
    { value: 'd4', label: 'Départemental 4', level: 12 },
    { value: 'd5', label: 'Départemental 5', level: 13 },
    { value: 'd6', label: 'Départemental 6', level: 14 }
  ],
  international: [
    { value: 'premier_league', label: 'Premier League (Angleterre)', country: 'england', level: 1 },
    { value: 'championship', label: 'Championship (Angleterre)', country: 'england', level: 2 },
    { value: 'league_one', label: 'League One (Angleterre)', country: 'england', level: 3 },
    { value: 'league_two', label: 'League Two (Angleterre)', country: 'england', level: 4 },
    
    { value: 'la_liga', label: 'La Liga (Espagne)', country: 'spain', level: 1 },
    { value: 'segunda_division', label: 'Segunda División (Espagne)', country: 'spain', level: 2 },
    { value: 'primera_federacion', label: 'Primera Federación (Espagne)', country: 'spain', level: 3 },
    { value: 'segunda_federacion', label: 'Segunda Federación (Espagne)', country: 'spain', level: 4 },
    
    { value: 'bundesliga', label: 'Bundesliga (Allemagne)', country: 'germany', level: 1 },
    { value: 'bundesliga2', label: '2. Bundesliga (Allemagne)', country: 'germany', level: 2 },
    { value: 'liga3', label: '3. Liga (Allemagne)', country: 'germany', level: 3 },
    { value: 'regionalliga', label: 'Regionalliga (Allemagne)', country: 'germany', level: 4 },
    
    { value: 'serie_a', label: 'Serie A (Italie)', country: 'italy', level: 1 },
    { value: 'serie_b', label: 'Serie B (Italie)', country: 'italy', level: 2 },
    { value: 'serie_c', label: 'Serie C (Italie)', country: 'italy', level: 3 },
    { value: 'serie_d', label: 'Serie D (Italie)', country: 'italy', level: 4 },
    
    { value: 'primeira_liga', label: 'Primeira Liga (Portugal)', country: 'portugal', level: 1 },
    { value: 'liga_portugal2', label: 'Liga Portugal 2 (Portugal)', country: 'portugal', level: 2 },
    { value: 'liga3_portugal', label: 'Liga 3 (Portugal)', country: 'portugal', level: 3 },
    { value: 'campeonato_portugal', label: 'Campeonato de Portugal', country: 'portugal', level: 4 },
    
    { value: 'eredivisie', label: 'Eredivisie (Pays-Bas)', country: 'netherlands', level: 1 },
    { value: 'eerste_divisie', label: 'Eerste Divisie (Pays-Bas)', country: 'netherlands', level: 2 },
    { value: 'tweede_divisie', label: 'Tweede Divisie (Pays-Bas)', country: 'netherlands', level: 3 },
    { value: 'derde_divisie', label: 'Derde Divisie (Pays-Bas)', country: 'netherlands', level: 4 },
    
    { value: 'pro_league', label: 'Pro League (Belgique)', country: 'belgium', level: 1 },
    { value: 'challenger_pro', label: 'Challenger Pro League (Belgique)', country: 'belgium', level: 2 },
    { value: 'division1_amateur', label: 'Division 1 Amateur (Belgique)', country: 'belgium', level: 3 },
    { value: 'division2_amateur', label: 'Division 2 Amateur (Belgique)', country: 'belgium', level: 4 }
  ]
};

// Positions de joueurs
export const PLAYER_POSITIONS = [
  { value: 'GK', label: 'Gardien de but' },
  { value: 'DC', label: 'Défenseur Central' },
  { value: 'DG', label: 'Défenseur Gauche' },
  { value: 'DD', label: 'Défenseur Droit' },
  { value: 'MDC', label: 'Milieu Défensif' },
  { value: 'MC', label: 'Milieu Central' },
  { value: 'MG', label: 'Milieu Gauche' },
  { value: 'MD', label: 'Milieu Droit' },
  { value: 'MOC', label: 'Milieu Offensif' },
  { value: 'AG', label: 'Ailier Gauche' },
  { value: 'AD', label: 'Ailier Droit' },
  { value: 'BU', label: 'Buteur' },
  { value: 'ATT', label: 'Attaquant' }
];

// Clubs français prédéfinis (Pro et Amateurs)
export const FRENCH_CLUBS = [
  // Ligue 1 (2024-2025)
  { id: 'psg', name: 'Paris Saint-Germain', city: 'Paris', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'om', name: 'Olympique de Marseille', city: 'Marseille', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'ol', name: 'Olympique Lyonnais', city: 'Lyon', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'asse', name: 'AS Saint-Étienne', city: 'Saint-Étienne', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'losc', name: 'LOSC Lille', city: 'Lille', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'ogcn', name: 'OGC Nice', city: 'Nice', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'asm', name: 'AS Monaco', city: 'Monaco', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'rennes', name: 'Stade Rennais', city: 'Rennes', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'lens', name: 'RC Lens', city: 'Lens', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'nantes', name: 'FC Nantes', city: 'Nantes', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'montpellier', name: 'Montpellier HSC', city: 'Montpellier', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'strasbourg', name: 'RC Strasbourg', city: 'Strasbourg', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'brest', name: 'Stade Brestois', city: 'Brest', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'reims', name: 'Stade de Reims', city: 'Reims', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'toulouse', name: 'Toulouse FC', city: 'Toulouse', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'auxerre', name: 'AJ Auxerre', city: 'Auxerre', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'angers', name: 'SCO Angers', city: 'Angers', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },
  { id: 'lehavre', name: 'Le Havre AC', city: 'Le Havre', league: 'Ligue 1', level: 'pro', registeredPlayers: 0 },

  // Ligue 2 (2024-2025)
  { id: 'metz', name: 'FC Metz', city: 'Metz', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'lorient', name: 'FC Lorient', city: 'Lorient', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'guingamp', name: 'EA Guingamp', city: 'Guingamp', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'caen', name: 'SM Caen', city: 'Caen', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'laval', name: 'Stade Lavallois', city: 'Laval', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'grenoble', name: 'Grenoble Foot 38', city: 'Grenoble', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'ajaccio', name: 'AC Ajaccio', city: 'Ajaccio', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'bastia', name: 'SC Bastia', city: 'Bastia', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'clermont', name: 'Clermont Foot', city: 'Clermont-Ferrand', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'troyes', name: 'ESTAC Troyes', city: 'Troyes', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'amiens', name: 'Amiens SC', city: 'Amiens', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'pau', name: 'Pau FC', city: 'Pau', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'rodez', name: 'Rodez AF', city: 'Rodez', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'dunkerque', name: 'USL Dunkerque', city: 'Dunkerque', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'paris-fc', name: 'Paris FC', city: 'Paris', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'martigues', name: 'FC Martigues', city: 'Martigues', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },
  { id: 'red-star', name: 'Red Star', city: 'Saint-Ouen', league: 'Ligue 2', level: 'pro', registeredPlayers: 0 },

  // National
  { id: 'concarneau', name: 'US Concarneau', city: 'Concarneau', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'orleans', name: 'US Orléans', city: 'Orléans', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'sochaux', name: 'FC Sochaux', city: 'Sochaux', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'nancy', name: 'AS Nancy', city: 'Nancy', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'versailles', name: 'FC Versailles', city: 'Versailles', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'dijon', name: 'Dijon FCO', city: 'Dijon', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'valenciennes', name: 'Valenciennes FC', city: 'Valenciennes', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'nimes', name: 'Nîmes Olympique', city: 'Nîmes', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'villefranche', name: 'FC Villefranche', city: 'Villefranche', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'chateauroux', name: 'La Berrichonne', city: 'Châteauroux', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'rouen', name: 'FC Rouen', city: 'Rouen', league: 'National', level: 'semi-pro', registeredPlayers: 0 },
  { id: 'boulogne', name: 'US Boulogne', city: 'Boulogne-sur-Mer', league: 'National', level: 'semi-pro', registeredPlayers: 0 },

  // National 2 - Groupe A
  { id: 'beauvais', name: 'AS Beauvais', city: 'Beauvais', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'fleury', name: 'FC Fleury', city: 'Fleury-Mérogis', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'sedan', name: 'CS Sedan', city: 'Sedan', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'sainte-genevieve', name: 'Sainte-Geneviève Sports', city: 'Sainte-Geneviève', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  
  // National 2 - Groupe B
  { id: 'poissy', name: 'AS Poissy', city: 'Poissy', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'saint-malo', name: 'US Saint-Malo', city: 'Saint-Malo', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'vannes', name: 'Vannes OC', city: 'Vannes', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'blois', name: 'Blois Foot', city: 'Blois', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  
  // National 2 - Groupe C
  { id: 'chatellerault', name: 'SO Châtellerault', city: 'Châtellerault', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'angouleme', name: 'Angoulême Charente FC', city: 'Angoulême', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'bergerac', name: 'Bergerac Périgord', city: 'Bergerac', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'limoges', name: 'Limoges FC', city: 'Limoges', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  
  // National 2 - Groupe D
  { id: 'bourg-peronnas', name: 'Bourg-en-Bresse Péronnas', city: 'Bourg-en-Bresse', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'andrézieux', name: 'Andrézieux-Bouthéon', city: 'Andrézieux', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'thonon', name: 'Thonon Evian', city: 'Thonon', league: 'National 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'rumilly', name: 'GFA Rumilly', city: 'Rumilly', league: 'National 2', level: 'amateur', registeredPlayers: 0 },

  // National 3 - Clubs populaires
  { id: 'créteil', name: 'US Créteil', city: 'Créteil', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'epinal', name: 'SAS Épinal', city: 'Épinal', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'bobigny', name: 'AF Bobigny', city: 'Bobigny', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'avranches', name: 'US Avranches', city: 'Avranches', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'cannes', name: 'AS Cannes', city: 'Cannes', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'toulon', name: 'SC Toulon', city: 'Toulon', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'béziers', name: 'AS Béziers', city: 'Béziers', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'belfort', name: 'ASM Belfort', city: 'Belfort', league: 'National 3', level: 'amateur', registeredPlayers: 0 },
  
  // Régional 1 - Clubs emblématiques
  { id: 'sannois', name: "AS Saint-Ouen l'Aumône", city: "Saint-Ouen-l'Aumône", league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'mantes', name: 'FC Mantois', city: 'Mantes-la-Jolie', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'drancy', name: 'JA Drancy', city: 'Drancy', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'meaux', name: 'CS Meaux', city: 'Meaux', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'torcy', name: 'US Torcy', city: 'Torcy', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'vitry', name: 'CAL Vitry', city: 'Vitry-sur-Seine', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'gobelins', name: 'FC Gobelins', city: 'Paris 13e', league: 'Régional 1', level: 'amateur', registeredPlayers: 0 },
  
  // Départemental - Clubs locaux
  { id: 'garenne-colombes', name: 'Racing Garenne-Colombes', city: 'La Garenne-Colombes', league: 'Départemental 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'asnières', name: 'FC Asnières', city: 'Asnières-sur-Seine', league: 'Départemental 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'levallois', name: 'Levallois FC', city: 'Levallois-Perret', league: 'Départemental 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'puteaux', name: 'US Puteaux', city: 'Puteaux', league: 'Départemental 1', level: 'amateur', registeredPlayers: 0 },
  { id: 'sèvres', name: 'FC Sèvres', city: 'Sèvres', league: 'Départemental 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'chaville', name: 'FC Chaville', city: 'Chaville', league: 'Départemental 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'montrouge', name: 'CA Montrouge', city: 'Montrouge', league: 'Départemental 2', level: 'amateur', registeredPlayers: 0 },
  { id: 'clamart', name: 'JS Clamart', city: 'Clamart', league: 'Départemental 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'bagneux', name: 'AS Bagneux', city: 'Bagneux', league: 'Départemental 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'antony', name: 'AS Antony', city: 'Antony', league: 'Départemental 3', level: 'amateur', registeredPlayers: 0 },
  { id: 'fontenay', name: 'USM Fontenay', city: 'Fontenay-aux-Roses', league: 'Départemental 4', level: 'amateur', registeredPlayers: 0 },
  { id: 'chatillon', name: 'FC Châtillon', city: 'Châtillon', league: 'Départemental 4', level: 'amateur', registeredPlayers: 0 },
  { id: 'plessis-robinson', name: 'FC Plessis-Robinson', city: 'Le Plessis-Robinson', league: 'Départemental 5', level: 'amateur', registeredPlayers: 0 },
  { id: 'sceaux', name: 'FC Sceaux', city: 'Sceaux', league: 'Départemental 5', level: 'amateur', registeredPlayers: 0 },
  { id: 'bourg-la-reine', name: 'AS Bourg-la-Reine', city: 'Bourg-la-Reine', league: 'Départemental 6', level: 'amateur', registeredPlayers: 0 }
];

// Nationalités courantes
export const NATIONALITIES = [
  { value: 'FR', label: 'France' },
  { value: 'ES', label: 'Espagne' },
  { value: 'EN', label: 'Angleterre' },
  { value: 'DE', label: 'Allemagne' },
  { value: 'IT', label: 'Italie' },
  { value: 'PT', label: 'Portugal' },
  { value: 'BR', label: 'Brésil' },
  { value: 'AR', label: 'Argentine' },
  { value: 'BE', label: 'Belgique' },
  { value: 'NL', label: 'Pays-Bas' },
  { value: 'MA', label: 'Maroc' },
  { value: 'DZ', label: 'Algérie' },
  { value: 'TN', label: 'Tunisie' },
  { value: 'SN', label: 'Sénégal' },
  { value: 'CM', label: 'Cameroun' },
  { value: 'CI', label: 'Côte d\'Ivoire' }
];

// Types de trophées
export const TROPHY_TYPES = {
  player: [
    { value: 'league', label: 'Champion de Ligue' },
    { value: 'cup', label: 'Vainqueur de Coupe' },
    { value: 'supercup', label: 'Super Coupe' },
    { value: 'european', label: 'Compétition Européenne' },
    { value: 'top_scorer', label: 'Meilleur Buteur' },
    { value: 'best_player', label: 'Meilleur Joueur' },
    { value: 'team_of_year', label: 'Équipe de l\'Année' }
  ],
  coach: [
    { value: 'league', label: 'Champion de Ligue' },
    { value: 'cup', label: 'Vainqueur de Coupe' },
    { value: 'promotion', label: 'Montée' },
    { value: 'best_coach', label: 'Meilleur Entraîneur' },
    { value: 'european', label: 'Compétition Européenne' }
  ],
  club: [
    { value: 'league', label: 'Champion de Ligue' },
    { value: 'cup', label: 'Vainqueur de Coupe' },
    { value: 'supercup', label: 'Super Coupe' },
    { value: 'european', label: 'Compétition Européenne' },
    { value: 'promotion', label: 'Montée' },
    { value: 'youth_cup', label: 'Coupe Jeunes' }
  ]
};