import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  real,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  profileType: varchar("profile_type"), // player, coach, club - no default, must be chosen
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  isSubscribed: boolean("is_subscribed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Player profiles
export const playerProfiles = pgTable("player_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name").notNull(),
  dateOfBirth: timestamp("date_of_birth"),
  nationality: varchar("nationality"),
  position: varchar("position"),
  currentClub: varchar("current_club"),
  biography: text("biography"),
  profileImagePath: varchar("profile_image_path"),
  totalLikes: integer("total_likes").default(0),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Player statistics (FM style - out of 20)
export const playerStats = pgTable("player_stats", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: uuid("player_id").references(() => playerProfiles.id).notNull(),
  
  // Technical stats
  dribbling: integer("dribbling").default(10),
  finishing: integer("finishing").default(10),
  passing: integer("passing").default(10),
  crossing: integer("crossing").default(10),
  shooting: integer("shooting").default(10),
  
  // Physical stats
  pace: integer("pace").default(10),
  stamina: integer("stamina").default(10),
  strength: integer("strength").default(10),
  jumping: integer("jumping").default(10),
  
  // Mental stats
  vision: integer("vision").default(10),
  leadership: integer("leadership").default(10),
  determination: integer("determination").default(10),
  composure: integer("composure").default(10),
  
  // Goalkeeping stats (if applicable)
  handling: integer("handling").default(10),
  reflexes: integer("reflexes").default(10),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Career history
export const careerHistory = pgTable("career_history", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: uuid("player_id").references(() => playerProfiles.id).notNull(),
  season: varchar("season").notNull(), // e.g., "2023-24"
  club: varchar("club").notNull(),
  league: varchar("league"),
  matches: integer("matches").default(0),
  goals: integer("goals").default(0),
  assists: integer("assists").default(0),
  yellowCards: integer("yellow_cards").default(0),
  redCards: integer("red_cards").default(0),
  averageRating: real("average_rating"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Player achievements/trophies
export const achievements = pgTable("achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: uuid("player_id").references(() => playerProfiles.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  year: integer("year"),
  type: varchar("type"), // trophy, individual_award, team_achievement
  createdAt: timestamp("created_at").defaultNow(),
});

// Media files (photos/videos)
export const mediaFiles = pgTable("media_files", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: uuid("player_id").references(() => playerProfiles.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  filePath: varchar("file_path").notNull(),
  fileType: varchar("file_type").notNull(), // image, video
  mimeType: varchar("mime_type"),
  fileSize: integer("file_size"),
  duration: integer("duration"), // for videos in seconds
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Player likes (social feature)
export const playerLikes = pgTable("player_likes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  playerId: uuid("player_id").references(() => playerProfiles.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Media likes
export const mediaLikes = pgTable("media_likes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  mediaId: uuid("media_id").references(() => mediaFiles.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Coach profiles
export const coachProfiles = pgTable("coach_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name").notNull(),
  dateOfBirth: timestamp("date_of_birth"),
  nationality: varchar("nationality"),
  currentClub: varchar("current_club"),
  biography: text("biography"),
  profileImagePath: varchar("profile_image_path"),
  philosophy: text("philosophy"), // Philosophie de jeu
  strengths: text("strengths"), // Points forts
  developmentAreas: text("development_areas"), // Axes de progression
  totalLikes: integer("total_likes").default(0),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Coach statistics (FM style coaching attributes - out of 20)
export const coachStats = pgTable("coach_stats", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: uuid("coach_id").references(() => coachProfiles.id).notNull(),
  
  // Coaching attributes
  attacking: integer("attacking").default(10), // Travail offensif
  defending: integer("defending").default(10), // Travail défensif
  mentalCoaching: integer("mental_coaching").default(10), // Préparation mentale
  tacticalKnowledge: integer("tactical_knowledge").default(10), // Connaissances tactiques
  technicalCoaching: integer("technical_coaching").default(10), // Travail technique
  
  // Management attributes
  manManagement: integer("man_management").default(10), // Gestion des hommes
  workingWithYoungsters: integer("working_with_youngsters").default(10), // Travail avec les jeunes
  motivation: integer("motivation").default(10), // Capacité de motivation
  determination: integer("determination").default(10), // Détermination
  
  // Knowledge attributes
  judgePlayerAbility: integer("judge_player_ability").default(10), // Évaluation des joueurs
  judgePlayerPotential: integer("judge_player_potential").default(10), // Évaluation du potentiel
  levelOfDiscipline: integer("level_of_discipline").default(10), // Niveau de discipline
  adaptability: integer("adaptability").default(10), // Adaptabilité
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Coach career history
export const coachCareerHistory = pgTable("coach_career_history", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: uuid("coach_id").references(() => coachProfiles.id).notNull(),
  season: varchar("season").notNull(),
  club: varchar("club").notNull(),
  position: varchar("position"), // Entraîneur principal, adjoint, formateur, etc.
  league: varchar("league"),
  matches: integer("matches").default(0),
  wins: integer("wins").default(0),
  draws: integer("draws").default(0),
  losses: integer("losses").default(0),
  trophies: text("trophies"), // Trophées gagnés cette saison
  createdAt: timestamp("created_at").defaultNow(),
});

// Club profiles
export const clubProfiles = pgTable("club_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name").notNull(),
  foundedYear: integer("founded_year"),
  country: varchar("country"),
  city: varchar("city"),
  stadium: varchar("stadium"),
  stadiumCapacity: integer("stadium_capacity"),
  stadiumImagePath: varchar("stadium_image_path"),
  logoPath: varchar("logo_path"),
  numberOfTeams: integer("number_of_teams"), // Nombre d'équipes (pro, réserve, jeunes, etc.)
  colors: varchar("colors"), // Couleurs du club
  website: varchar("website"),
  description: text("description"),
  totalLikes: integer("total_likes").default(0),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Club stats - Compétences du club notées sur 20
export const clubStats = pgTable("club_stats", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  clubId: uuid("club_id").references(() => clubProfiles.id).notNull().unique(),
  
  // Infrastructure
  infrastructure: integer("infrastructure").default(10), // Qualité des installations
  trainingFacilities: integer("training_facilities").default(10), // Centre d'entraînement
  youthAcademy: integer("youth_academy").default(10), // Centre de formation
  
  // Gestion
  finances: integer("finances").default(10), // Santé financière
  commercialAppeal: integer("commercial_appeal").default(10), // Attractivité commerciale
  businessManagement: integer("business_management").default(10), // Gestion d'entreprise
  
  // Sportif
  scouting: integer("scouting").default(10), // Réseau de recrutement
  medicalStaff: integer("medical_staff").default(10), // Staff médical
  technicalStaff: integer("technical_staff").default(10), // Staff technique
  
  // Communauté
  supporters: integer("supporters").default(10), // Base de supporters
  stadiumAtmosphere: integer("stadium_atmosphere").default(10), // Ambiance au stade
  mediaPresence: integer("media_presence").default(10), // Présence médiatique
  
  // Vision
  youthDevelopment: integer("youth_development").default(10), // Développement des jeunes
  projectAmbition: integer("project_ambition").default(10), // Ambition du projet
  internationalReputation: integer("international_reputation").default(10), // Réputation internationale
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Club achievements
export const clubAchievements = pgTable("club_achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  clubId: uuid("club_id").references(() => clubProfiles.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  year: integer("year"),
  type: varchar("type"), // championship, cup, european_trophy, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

// Club media (photos/videos specific to clubs)
export const clubMediaFiles = pgTable("club_media_files", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  clubId: uuid("club_id").references(() => clubProfiles.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  filePath: varchar("file_path").notNull(),
  fileType: varchar("file_type").notNull(), // image, video
  mimeType: varchar("mime_type"),
  fileSize: integer("file_size"),
  duration: integer("duration"), // for videos in seconds
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Coach media (videos/photos for coaches)
export const coachMediaFiles = pgTable("coach_media_files", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  coachId: uuid("coach_id").references(() => coachProfiles.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  filePath: varchar("file_path").notNull(),
  fileType: varchar("file_type").notNull(), // image, video
  mimeType: varchar("mime_type"),
  fileSize: integer("file_size"),
  duration: integer("duration"), // for videos in seconds
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Coach likes
export const coachLikes = pgTable("coach_likes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  coachId: uuid("coach_id").references(() => coachProfiles.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Club likes
export const clubLikes = pgTable("club_likes", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  clubId: uuid("club_id").references(() => clubProfiles.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Profile Follows - Système de suivi mutuel entre profils
export const profileFollows = pgTable("profile_follows", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  followerId: varchar("follower_id").references(() => users.id).notNull(),
  followingId: varchar("following_id").references(() => users.id).notNull(),
  status: varchar("status").default("pending"), // pending, accepted, blocked
  createdAt: timestamp("created_at").defaultNow(),
});

// Messages - Système de messagerie entre profils qui se suivent
export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  recipientId: varchar("recipient_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Message Requests - Demandes de contact
export const messageRequests = pgTable("message_requests", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  recipientId: varchar("recipient_id").references(() => users.id).notNull(),
  message: text("message"), // Message initial de présentation
  status: varchar("status").default("pending"), // pending, accepted, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

// Export types
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;

export type PlayerProfile = typeof playerProfiles.$inferSelect;
export type InsertPlayerProfile = typeof playerProfiles.$inferInsert;

export type PlayerStats = typeof playerStats.$inferSelect;
export type InsertPlayerStats = typeof playerStats.$inferInsert;

export type CareerHistory = typeof careerHistory.$inferSelect;
export type InsertCareerHistory = typeof careerHistory.$inferInsert;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = typeof achievements.$inferInsert;

export type MediaFile = typeof mediaFiles.$inferSelect;
export type InsertMediaFile = typeof mediaFiles.$inferInsert;

export type PlayerLike = typeof playerLikes.$inferSelect;
export type MediaLike = typeof mediaLikes.$inferSelect;

// Zod schemas
export const insertPlayerProfileSchema = createInsertSchema(playerProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPlayerStatsSchema = createInsertSchema(playerStats).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCareerHistorySchema = createInsertSchema(careerHistory).omit({
  id: true,
  createdAt: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  createdAt: true,
});

export const insertMediaFileSchema = createInsertSchema(mediaFiles).omit({
  id: true,
  createdAt: true,
});

// Coach types
export type CoachProfile = typeof coachProfiles.$inferSelect;
export type InsertCoachProfile = typeof coachProfiles.$inferInsert;

export type CoachStats = typeof coachStats.$inferSelect;
export type InsertCoachStats = typeof coachStats.$inferInsert;

export type CoachCareerHistory = typeof coachCareerHistory.$inferSelect;
export type InsertCoachCareerHistory = typeof coachCareerHistory.$inferInsert;

export type CoachMediaFile = typeof coachMediaFiles.$inferSelect;
export type InsertCoachMediaFile = typeof coachMediaFiles.$inferInsert;

// Club types
export type ClubProfile = typeof clubProfiles.$inferSelect;
export type InsertClubProfile = typeof clubProfiles.$inferInsert;

export type ClubAchievement = typeof clubAchievements.$inferSelect;
export type InsertClubAchievement = typeof clubAchievements.$inferInsert;

export type ClubMediaFile = typeof clubMediaFiles.$inferSelect;
export type InsertClubMediaFile = typeof clubMediaFiles.$inferInsert;

export type ProfileFollow = typeof profileFollows.$inferSelect;
export type InsertProfileFollow = typeof profileFollows.$inferInsert;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

export type MessageRequest = typeof messageRequests.$inferSelect;
export type InsertMessageRequest = typeof messageRequests.$inferInsert;

// Zod schemas for coaches
export const insertCoachProfileSchema = createInsertSchema(coachProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCoachStatsSchema = createInsertSchema(coachStats).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCoachCareerHistorySchema = createInsertSchema(coachCareerHistory).omit({
  id: true,
  createdAt: true,
});

export const insertCoachMediaFileSchema = createInsertSchema(coachMediaFiles).omit({
  id: true,
  createdAt: true,
});

// Zod schemas for clubs
export const insertClubProfileSchema = createInsertSchema(clubProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertClubAchievementSchema = createInsertSchema(clubAchievements).omit({
  id: true,
  createdAt: true,
});

export const insertClubMediaFileSchema = createInsertSchema(clubMediaFiles).omit({
  id: true,
  createdAt: true,
});
